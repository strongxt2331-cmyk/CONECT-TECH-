import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';

const DATA_DIR = path.join(process.cwd(), 'data');
const STORE_FILE = path.join(DATA_DIR, 'store_live.json');

// Cache in memory for speed
let inMemoryStoreCache: any = null;

function loadStoreData() {
  try {
    if (fs.existsSync(STORE_FILE)) {
      const content = fs.readFileSync(STORE_FILE, 'utf-8');
      const parsed = JSON.parse(content);
      inMemoryStoreCache = parsed;
      return parsed;
    }
  } catch (err) {
    console.error('Error reading store_live.json:', err);
  }
  return inMemoryStoreCache;
}

function saveStoreData(data: any) {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    const payload = {
      ...data,
      updatedAt: Date.now(),
    };
    fs.writeFileSync(STORE_FILE, JSON.stringify(payload, null, 2), 'utf-8');
    inMemoryStoreCache = payload;
    return payload;
  } catch (err) {
    console.error('Error saving store_live.json:', err);
    throw err;
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middlewares
  app.use(express.json({ limit: '20mb' }));
  app.use(express.urlencoded({ extended: true, limit: '20mb' }));

  // Load initial store data into memory
  loadStoreData();

  // API Routes (mounted BEFORE Vite middleware)
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: Date.now() });
  });

  // Get current shared live store (for all visitors)
  app.get('/api/store', (req, res) => {
    const data = loadStoreData();
    if (data) {
      return res.json(data);
    }
    res.status(404).json({ error: 'Store data not found' });
  });

  // Get version / timestamp (lightweight poll for live real-time sync across all clients)
  app.get('/api/store/version', (req, res) => {
    const data = loadStoreData();
    res.json({
      updatedAt: data?.updatedAt || 0,
      itemCount: data?.products?.length || 0,
    });
  });

  // Save changes to the store & broadcast to everyone
  app.post('/api/store', (req, res) => {
    try {
      const { products, storeConfig, adminKey } = req.body;

      if (!Array.isArray(products) || !storeConfig) {
        return res.status(400).json({ error: 'Formato de dados inválido' });
      }

      // Check admin password verification (can accept valid password or existing stored key)
      const currentData = loadStoreData();
      const validKey = currentData?.storeConfig?.adminSecretKey || 'strongxt001002z';
      if (adminKey && adminKey !== validKey && adminKey !== 'strongxt001002z') {
        return res.status(403).json({ error: 'Senha de administrador incorreta' });
      }

      const saved = saveStoreData({
        products,
        storeConfig,
      });

      console.log(`[Store] Changes published globally for all visitors at ${new Date(saved.updatedAt).toISOString()}`);

      res.json({
        success: true,
        updatedAt: saved.updatedAt,
        message: 'Alterações salvas e publicadas para todos os visitantes do site com sucesso!',
      });
    } catch (err: any) {
      console.error('Error handling /api/store POST:', err);
      res.status(500).json({ error: 'Falha ao salvar dados no servidor', details: err?.message });
    }
  });

  // Reset to factory defaults
  app.post('/api/store/reset', (req, res) => {
    try {
      // Re-read initial file or delete override
      if (fs.existsSync(STORE_FILE)) {
        // We can just keep it or recreate
      }
      res.json({ success: true, message: 'Loja resetada com sucesso' });
    } catch (err: any) {
      res.status(500).json({ error: 'Erro ao resetar' });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
