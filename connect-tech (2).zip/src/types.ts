export type ProductCategory =
  | 'todos'
  | 'celular'
  | 'carregadores'
  | 'cabos'
  | 'fones'
  | 'adaptadores'
  | 'smart'
  | 'computador'
  | 'ofertas';

export interface ProductSpecification {
  label: string;
  value: string;
}

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  categoryName: string;
  price: number;
  originalPrice?: number;
  discountPercentage?: number;
  rating: number; // e.g. 4.8
  reviewCount: number; // For demonstration display
  image: string;
  gallery: string[];
  description: string;
  shortDescription: string;
  features: string[];
  specs: ProductSpecification[];
  isFeatured?: boolean;
  isOfferOfTheWeek?: boolean;
  inStock: boolean;
  stockCount: number;
  badge?: string;
  colors?: string[];
  tag?: string;
  slug?: string;
  // Custom QR Code & Payment Link fields
  customQrCodeImage?: string;
  customPixCode?: string;
  paymentLink?: string;
  customPaymentValue?: number;
  paymentInstructions?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedColor?: string;
}

export interface CategoryInfo {
  id: ProductCategory;
  name: string;
  iconName: string;
  description: string;
  itemCount: number;
  image: string;
}

export interface CustomerInfo {
  fullName: string;
  cpf: string;
  phone: string;
  email: string;
  cep: string;
  street: string;
  number: string;
  complement?: string;
  neighborhood: string;
  city: string;
  state: string;
}

export type PaymentMethod = 'pix' | 'credit' | 'debit';

export interface Order {
  orderId: string;
  createdAt: string;
  customer: CustomerInfo;
  items: CartItem[];
  subtotal: number;
  shipping: number;
  discount: number;
  total: number;
  paymentMethod: PaymentMethod;
  installments?: number;
  status: 'pending' | 'confirmed' | 'shipped';
}
