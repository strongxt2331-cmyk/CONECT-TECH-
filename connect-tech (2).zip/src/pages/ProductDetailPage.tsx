import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Star,
  ShoppingCart,
  Zap,
  ShieldCheck,
  MessageCircle,
  Check,
  Plus,
  Minus,
  Share2,
  Info,
  RotateCcw,
  MapPin,
} from 'lucide-react';
import { Product } from '../types';
import { useCart } from '../context/CartContext';
import { getProductWhatsAppUrl, STORE_CONFIG } from '../config';
import { ProductCard } from '../components/ProductCard';
import { useStore } from '../context/StoreContext';

interface ProductDetailPageProps {
  product: Product;
  onBack: () => void;
  onSelectRelatedProduct: (product: Product) => void;
  onProceedToCheckout: () => void;
}

export const ProductDetailPage: React.FC<ProductDetailPageProps> = ({
  product,
  onBack,
  onSelectRelatedProduct,
  onProceedToCheckout,
}) => {
  const { addItem } = useCart();
  const { products } = useStore();
  const currentProduct = products.find((p) => p.id === product.id) || product;

  const [selectedImage, setSelectedImage] = useState(
    currentProduct.gallery[0] || currentProduct.image
  );
  const [quantity, setQuantity] = useState(1);
  const [selectedColor, setSelectedColor] = useState(
    currentProduct.colors && currentProduct.colors.length > 0 ? currentProduct.colors[0] : undefined
  );

  // Sync image if product changes or is updated in admin
  useEffect(() => {
    setSelectedImage(currentProduct.gallery[0] || currentProduct.image);
  }, [currentProduct.id, currentProduct.image, currentProduct.gallery]);

  // Shipping simulator state
  const [cepInput, setCepInput] = useState('');
  const [shippingCalculated, setShippingCalculated] = useState(false);
  const [shippingLoading, setShippingLoading] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const formattedPrice = currentProduct.price.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });

  const relatedProducts = products
    .filter((p) => p.id !== currentProduct.id && (p.category === currentProduct.category || p.isFeatured))
    .slice(0, 4);

  const handleAddToCart = () => {
    addItem(currentProduct, quantity, selectedColor);
  };

  const handleBuyNow = () => {
    addItem(currentProduct, quantity, selectedColor);
    onProceedToCheckout();
  };

  const handleSimulateShipping = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = cepInput.replace(/\D/g, '');
    if (clean.length === 8) {
      setShippingLoading(true);
      setTimeout(() => {
        setShippingLoading(false);
        setShippingCalculated(true);
      }, 400);
    }
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  return (
    <div className="py-8 bg-[#030712] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button & Breadcrumbs */}
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={onBack}
            className="inline-flex items-center gap-2 text-sm text-slate-400 hover:text-white px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Voltar ao catálogo</span>
          </button>
          <button
            onClick={handleShare}
            className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-cyan-300 p-2 rounded-lg bg-slate-900 border border-slate-800 transition-colors cursor-pointer"
            title="Copiar link do produto"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>{copiedLink ? 'Link copiado!' : 'Compartilhar'}</span>
          </button>
        </div>

        {/* Main Product Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 mb-16">
          {/* Left Column: Image Gallery */}
          <div className="lg:col-span-6 flex flex-col gap-4">
            {/* Main Featured Image */}
            <div className="relative aspect-square w-full rounded-3xl overflow-hidden bg-[#070D1E] border border-blue-900/40 flex items-center justify-center p-2 shadow-2xl">
              <img
                src={selectedImage}
                alt={product.name}
                className="w-full h-full object-cover rounded-2xl transition-all duration-300"
              />
              {currentProduct.badge && (
                <div className="absolute top-4 right-4 px-3 py-1 rounded-xl bg-blue-600/90 text-white font-bold text-xs uppercase tracking-wider backdrop-blur-md border border-blue-400/40">
                  {currentProduct.badge}
                </div>
              )}
            </div>

            {/* Thumbnails list */}
            {currentProduct.gallery && currentProduct.gallery.length > 1 && (
              <div className="flex items-center gap-3 overflow-x-auto pb-2">
                {currentProduct.gallery.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(img)}
                    className={`relative w-20 h-20 rounded-xl overflow-hidden border-2 transition-all shrink-0 bg-slate-900 cursor-pointer ${
                      selectedImage === img
                        ? 'border-cyan-400 scale-105 shadow-md shadow-cyan-500/20'
                        : 'border-slate-800 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt={`Foto ${idx + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right Column: Details, Pricing, & Action CTAs */}
          <div className="lg:col-span-6 flex flex-col justify-between">
            <div>
              {/* Category & Rating */}
              <div className="flex items-center justify-between gap-4 mb-2">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
                  {currentProduct.categoryName}
                </span>
                <div
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-xs"
                  title="Classificação dos clientes"
                >
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  <span className="font-bold text-white">{currentProduct.rating}</span>
                  <span className="text-slate-500">({currentProduct.reviewCount} avaliações)</span>
                </div>
              </div>

              {/* Product Title */}
              <h1 className="font-tech text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight leading-tight mb-3">
                {currentProduct.name}
              </h1>

              {/* Short description */}
              <p className="text-slate-300 text-sm leading-relaxed mb-6">
                {currentProduct.description}
              </p>

              {/* Pricing Block */}
              <div className="p-5 rounded-2xl bg-[#081126] border border-blue-500/30 mb-6 shadow-inner">
                {currentProduct.originalPrice && (
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-base text-slate-400 line-through">
                      De {currentProduct.originalPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-lg bg-rose-500/20 text-rose-300 border border-rose-500/40 text-xs font-black">
                      {currentProduct.discountPercentage ? `-${currentProduct.discountPercentage}% OFF` : 'OFERTA'}
                    </span>
                    <span className="text-xs text-emerald-400 font-bold">
                      Economize {(currentProduct.originalPrice - currentProduct.price).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    </span>
                  </div>
                )}
                <div className="flex items-baseline gap-3 mb-1">
                  <span className="text-3xl sm:text-4xl font-black text-white font-tech text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-cyan-300">
                    {formattedPrice}
                  </span>
                </div>
                <div className="text-xs text-slate-300 space-y-1">
                  <p className="text-emerald-400 font-bold flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    Pagamento exclusivo e facilitado via PIX com QR Code e aprovação imediata!
                  </p>
                </div>
              </div>

              {/* Color selection if available */}
              {currentProduct.colors && currentProduct.colors.length > 0 && (
                <div className="mb-6">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-2">
                    Opção de Cor: <span className="text-cyan-400 font-semibold">{selectedColor}</span>
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {currentProduct.colors.map((color) => (
                      <button
                        key={color}
                        onClick={() => setSelectedColor(color)}
                        className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all border cursor-pointer ${
                          selectedColor === color
                            ? 'bg-blue-600/30 border-cyan-400 text-white shadow-sm shadow-cyan-500/30'
                            : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'
                        }`}
                      >
                        {color}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Quantity Selector & Stock Info */}
              <div className="flex items-center gap-6 mb-6">
                <div>
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-2">
                    Quantidade
                  </span>
                  <div className="flex items-center rounded-xl bg-slate-900 border border-slate-700 p-1">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="p-2 text-slate-400 hover:text-white transition-colors cursor-pointer"
                      disabled={quantity <= 1}
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="px-4 text-sm font-bold text-white font-tech">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity(Math.min(currentProduct.stockCount, quantity + 1))}
                      className="p-2 text-slate-400 hover:text-white transition-colors cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div>
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-2">
                    Disponibilidade Local
                  </span>
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 bg-emerald-950/40 border border-emerald-500/40 px-3 py-2 rounded-xl shadow-sm">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span>{currentProduct.stockCount} em estoque em Santana do Livramento</span>
                  </div>
                </div>
              </div>

              {/* Notice Banner about Santana do Livramento Exclusivity & WhatsApp */}
              <div className="p-3.5 rounded-xl bg-cyan-950/40 border border-cyan-500/40 mb-5 flex items-start gap-2.5 text-xs text-slate-200">
                <MapPin className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-cyan-300 block mb-0.5">Exclusivo Santana do Livramento - RS:</strong>
                  Atendimento e entrega rápida na cidade. Ao finalizar, combinamos a entrega via motoboy ou retirada em mãos pelo WhatsApp ({STORE_CONFIG.whatsapp.displayNumber}).
                </div>
              </div>

              {/* Action Buttons: Add to Cart, Buy Now, Buy with WhatsApp */}
              <div className="space-y-3 mb-8">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    id="btn-product-add-cart"
                    onClick={handleAddToCart}
                    className="py-4 px-6 rounded-xl bg-slate-900 border border-blue-500/60 hover:bg-blue-900/30 text-cyan-300 font-bold text-sm uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-md active:scale-98 cursor-pointer"
                  >
                    <ShoppingCart className="w-4 h-4" />
                    <span>Adicionar ao carrinho</span>
                  </button>
                  <button
                    id="btn-product-buy-now"
                    onClick={handleBuyNow}
                    className="py-4 px-6 rounded-xl bg-gradient-to-r from-blue-600 via-blue-500 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-extrabold text-sm uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-xl shadow-blue-600/30 active:scale-98 cursor-pointer"
                  >
                    <Zap className="w-4 h-4" />
                    <span>Comprar agora</span>
                  </button>
                </div>

                {/* WhatsApp Purchase Button */}
                <a
                  href={getProductWhatsAppUrl(product.name, product.price)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3.5 px-6 rounded-xl bg-emerald-600/20 border border-emerald-500/40 hover:bg-emerald-600/30 text-emerald-300 font-bold text-xs sm:text-sm uppercase tracking-wider flex items-center justify-center gap-2 transition-all"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-400" />
                  <span>Comprar pelo WhatsApp</span>
                </a>
              </div>

              {/* Shipping Simulator */}
              <div className="p-4 rounded-2xl bg-[#060C1D] border border-slate-800 mb-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                    Entrega Local (Santana do Livramento - RS)
                  </span>
                  <span className="text-[10px] text-cyan-400 font-semibold flex items-center gap-1">
                    <MapPin className="w-3 h-3" />
                    Apenas Santana do Livramento
                  </span>
                </div>
                <form onSubmit={handleSimulateShipping} className="flex gap-2 mb-3">
                  <input
                    type="text"
                    placeholder="Digite seu CEP (ex: 97573-000)"
                    value={cepInput}
                    onChange={(e) => setCepInput(e.target.value)}
                    maxLength={9}
                    className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition-colors cursor-pointer"
                  >
                    {shippingLoading ? 'Consultando...' : 'Consultar'}
                  </button>
                </form>

                {shippingCalculated && (
                  <div className="space-y-2 pt-2 border-t border-slate-800 text-xs">
                    <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-900/80 border border-emerald-500/30">
                      <div>
                        <span className="text-slate-200 font-medium block">🛵 Motoboy / Entrega Rápida</span>
                        <span className="text-[11px] text-slate-400">Entrega hoje ou em até 24h em Santana do Livramento</span>
                      </div>
                      <span className="font-bold text-emerald-400 text-xs uppercase">Grátis</span>
                    </div>
                    <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-900/80 border border-cyan-500/20">
                      <div>
                        <span className="text-slate-200 font-medium block">🤝 Retirada em Mãos</span>
                        <span className="text-[11px] text-slate-400">Ponto de encontro combinado no Centro / Livramento</span>
                      </div>
                      <span className="font-bold text-emerald-400 text-xs uppercase">Grátis</span>
                    </div>
                    <p className="text-[10px] text-cyan-300/80 italic mt-1">
                      * Entregas realizadas exclusivamente na cidade de Santana do Livramento - RS.
                    </p>
                  </div>
                )}
              </div>

              {/* Guarantees Trust Badges */}
              <div className="grid grid-cols-2 gap-3 text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-cyan-400" />
                  <span>Garantia de 12 meses Connect Tech</span>
                </div>
                <div className="flex items-center gap-2">
                  <RotateCcw className="w-4 h-4 text-cyan-400" />
                  <span>7 dias para troca ou devolução</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Detailed Technical Specifications */}
        <div className="mb-16 p-6 sm:p-8 rounded-3xl bg-[#060C1D] border border-slate-800">
          <h2 className="font-tech text-xl sm:text-2xl font-bold text-white mb-6 flex items-center gap-2">
            <Info className="w-5 h-5 text-cyan-400" />
            Especificações Técnicas
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-4">
            {product.specs.map((spec, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between py-2.5 border-b border-slate-800/80 text-xs sm:text-sm"
              >
                <span className="text-slate-400 font-medium">{spec.label}</span>
                <span className="text-white font-semibold text-right">{spec.value}</span>
              </div>
            ))}
          </div>

          <div className="mt-8 pt-6 border-t border-slate-800">
            <h4 className="text-sm font-bold text-white mb-3">Destaques do Produto</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300">
              {product.features.map((feat, idx) => (
                <div key={idx} className="flex items-start gap-2">
                  <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                  <span>{feat}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Section: "Você também pode gostar" (Related Products) */}
        <div>
          <div className="flex items-center justify-between mb-8">
            <h2 className="font-tech text-xl sm:text-2xl font-bold text-white">
              VOCÊ TAMBÉM PODE GOSTAR
            </h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {relatedProducts.map((p) => (
              <ProductCard
                key={p.id}
                product={p}
                onViewDetails={onSelectRelatedProduct}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
