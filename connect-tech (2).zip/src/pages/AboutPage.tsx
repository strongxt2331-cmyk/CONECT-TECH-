import React from 'react';
import {
  Zap,
  ShieldCheck,
  HeartHandshake,
  Target,
  Award,
  MapPin,
} from 'lucide-react';
import { STORE_CONFIG } from '../config';

interface AboutPageProps {
  onExploreProducts: () => void;
  onContact: () => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ onExploreProducts, onContact }) => {
  const pillars = [
    {
      icon: Target,
      title: 'Nossa Missão',
      desc: 'Aproximar as pessoas da tecnologia através de produtos úteis para o dia a dia e de um atendimento próximo, ético e confiável em Santana do Livramento - RS.',
    },
    {
      icon: ShieldCheck,
      title: 'Qualidade Rigorosa',
      desc: 'Cada modelo de carregador turbo passa por testes rigorosos de condutividade, aquecimento e durabilidade antes de ser entregue aos nossos clientes.',
    },
    {
      icon: HeartHandshake,
      title: 'Atendimento Humanizado',
      desc: 'Nada de robôs genéricos. Atendimento direto e ágil via WhatsApp pelo proprietário para tirar qualquer dúvida e combinar a entrega local.',
    },
    {
      icon: MapPin,
      title: 'Pronta Entrega Local',
      desc: 'Exclusivo para Santana do Livramento - RS: entrega expressa no mesmo dia via motoboy ou retirada rápida em mãos sem taxa de frete.',
    },
  ];

  return (
    <div className="py-12 bg-[#030712] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-slate-500 mb-6 font-medium">
          <span>Início</span>
          <span>/</span>
          <span className="text-cyan-400">Institucional</span>
        </div>

        {/* Hero About */}
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-[#071128] via-[#0b1b3d] to-[#081024] border border-blue-500/30 p-8 sm:p-12 lg:p-16 mb-16 shadow-2xl">
          <div className="max-w-3xl">
            <div className="flex flex-wrap items-center gap-2 mb-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-950/80 border border-blue-500/40 text-cyan-400 text-xs font-bold uppercase tracking-wider">
                <Zap className="w-3.5 h-3.5 fill-cyan-400" />
                IDENTIDADE & PROPÓSITO
              </div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs font-semibold">
                <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                Exclusivo Santana do Livramento - RS
              </div>
            </div>

            <h1 className="font-tech text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight mb-6">
              SOBRE A CONNECT TECH
            </h1>

            {/* Exact required mission statement */}
            <div className="p-6 rounded-2xl bg-[#030816]/80 border-l-4 border-cyan-400 border-t border-r border-b border-slate-800 text-slate-200 text-base sm:text-lg leading-relaxed mb-6 font-medium">
              "{STORE_CONFIG.aboutText}"
            </div>

            <p className="text-slate-400 text-sm sm:text-base leading-relaxed mb-8">
              Em um mundo hiperconectado, sabemos o quanto um cabo quebrado ou um carregador lento pode atrapalhar o seu trabalho, estudo ou entretenimento. Por isso, selecionamos apenas acessórios eletrônicos com componentes de alta qualidade, garantindo recargas rápidas, proteção contra surtos elétricos e conectividade sem falhas.
            </p>

            <div className="flex flex-wrap gap-4">
              <button
                onClick={onExploreProducts}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg hover:opacity-90 transition-opacity cursor-pointer"
              >
                Conhecer Produtos
              </button>
              <button
                onClick={onContact}
                className="px-6 py-3 rounded-xl bg-slate-900 border border-slate-700 hover:border-cyan-400 text-slate-200 font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer"
              >
                Fale Conosco
              </button>
            </div>
          </div>
        </div>

        {/* 4 Pillars Section */}
        <div className="mb-16">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest block mb-2">
              Nossos Pilares Fundamentais
            </span>
            <h2 className="font-tech text-2xl sm:text-3xl font-extrabold text-white">
              COMPROMISSO COM A EXCELÊNCIA TECNOLÓGICA
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {pillars.map((pil, idx) => {
              const Icon = pil.icon;
              return (
                <div
                  key={idx}
                  className="p-6 rounded-2xl bg-[#060C1D] border border-slate-800 hover:border-blue-500/50 transition-all duration-300 flex flex-col justify-between group"
                >
                  <div>
                    <div className="w-12 h-12 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-cyan-400 mb-4 group-hover:scale-110 transition-transform">
                      <Icon className="w-6 h-6" />
                    </div>
                    <h3 className="font-tech font-bold text-white text-lg mb-2 group-hover:text-cyan-300 transition-colors">
                      {pil.title}
                    </h3>
                    <p className="text-slate-400 text-xs sm:text-sm leading-relaxed">
                      {pil.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Quality Assurance Strip */}
        <div className="p-8 rounded-3xl bg-[#050B1B] border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="space-y-2">
            <h3 className="font-tech font-bold text-white text-xl">
              Transparência e Suporte ao Cliente
            </h3>
            <p className="text-slate-400 text-xs sm:text-sm max-w-2xl leading-relaxed">
              Todos os nossos produtos são despachados com nota fiscal e garantia expressa. Você tem total segurança desde o primeiro clique até o recebimento do seu pedido em mãos.
            </p>
          </div>
          <button
            onClick={onContact}
            className="px-6 py-3.5 rounded-xl bg-slate-900 border border-cyan-400 text-cyan-300 font-bold text-xs uppercase tracking-wider hover:bg-slate-850 shrink-0 cursor-pointer"
          >
            Entrar em contato
          </button>
        </div>
      </div>
    </div>
  );
};
