import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  SlidersHorizontal,
  ArrowUpDown,
  X,
  Key,
  Users,
  MapPin,
  Settings,
} from 'lucide-react';
import { Product, ProductCategory } from '../types';
import { ProductCard } from '../components/ProductCard';
import { useStore } from '../context/StoreContext';

interface ProductsPageProps {
  initialCategory?: ProductCategory;
  initialSearchQuery?: string;
  onViewProductDetails: (product: Product) => void;
  onOpenBuyersDashboard?: () => void;
  onOpenAdminEditor?: () => void;
}

type SortOption = 'featured' | 'price-asc' | 'price-desc' | 'newest' | 'rating';

export const ProductsPage: React.FC<ProductsPageProps> = ({
  initialCategory = 'todos',
  initialSearchQuery = '',
  onViewProductDetails,
  onOpenBuyersDashboard,
  onOpenAdminEditor,
}) => {
  const { products, verifyAdminPassword, setIsAdminOpen } = useStore();
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory>(initialCategory);
  const [searchQuery, setSearchQuery] = useState(initialSearchQuery);
  const [sortBy, setSortBy] = useState<SortOption>('featured');
  const [priceMax, setPriceMax] = useState<number>(200);
  const [onlyInStock, setOnlyInStock] = useState<boolean>(false);
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  const isAdminKey = verifyAdminPassword(searchQuery);

  // Filter & Sort Pipeline
  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      // Category filter
      if (selectedCategory !== 'todos' && product.category !== selectedCategory) {
        return false;
      }
      // Price filter
      if (product.price > priceMax) {
        return false;
      }
      // Stock filter
      if (onlyInStock && !product.inStock) {
        return false;
      }
      // Search Query filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchName = product.name.toLowerCase().includes(query);
        const matchDesc = product.shortDescription.toLowerCase().includes(query);
        const matchCat = product.categoryName.toLowerCase().includes(query);
        const matchSpecs = product.specs.some(
          (s) => s.value.toLowerCase().includes(query) || s.label.toLowerCase().includes(query)
        );
        if (!matchName && !matchDesc && !matchCat && !matchSpecs) return false;
      }
      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'newest') return (b.reviewCount || 0) - (a.reviewCount || 0);
      return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
    });
  }, [selectedCategory, searchQuery, sortBy, priceMax, onlyInStock]);

  const categoriesList: { id: ProductCategory; label: string }[] = [
    { id: 'todos', label: 'Todos os Produtos' },
    { id: 'carregadores', label: 'Carregadores & Power Banks' },
    { id: 'celular', label: 'Acessórios para Celular' },
    { id: 'cabos', label: 'Cabos' },
    { id: 'fones', label: 'Fones de Ouvido' },
    { id: 'adaptadores', label: 'Adaptadores' },
    { id: 'smart', label: 'Smart & Wearables' },
  ];

  return (
    <div className="py-10 bg-[#030712] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Page Title & Breadcrumb */}
        <div className="mb-8">
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-2 font-medium">
            <span>Início</span>
            <span>/</span>
            <span className="text-cyan-400">Catálogo Completo</span>
          </div>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-tech tracking-tight">
                TODOS OS PRODUTOS
              </h1>
              <p className="text-slate-400 text-sm mt-1">
                Conheça nossos acessórios de alta tecnologia com estoque e entrega exclusiva em <strong>Santana do Livramento - RS</strong>.
              </p>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs text-cyan-300 font-semibold bg-cyan-950/60 border border-cyan-500/40 px-3 py-1.5 rounded-lg flex items-center gap-1.5 self-start md:self-auto">
                <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                Entrega em Santana do Livramento - RS
              </span>
              <span className="text-xs text-slate-400 font-semibold bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg self-start md:self-auto">
                <strong>{filteredProducts.length}</strong> {filteredProducts.length === 1 ? 'disponível' : 'disponíveis'}
              </span>
            </div>
          </div>
        </div>

        {/* Filter & Search Bar Row */}
        <div className="bg-[#060C1D] border border-slate-800 p-4 rounded-2xl mb-8 flex flex-col lg:flex-row gap-4 items-stretch lg:items-center justify-between shadow-lg">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Pesquisar por nome, tipo de cabo, carregador..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-slate-900/90 border border-slate-700/80 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Sort & Mobile Filter Toggle */}
          <div className="flex items-center gap-3">
            {/* Mobile Filter Button */}
            <button
              onClick={() => setMobileFilterOpen(!mobileFilterOpen)}
              className="lg:hidden flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-slate-900 border border-slate-700 text-slate-200 text-sm font-semibold cursor-pointer"
            >
              <SlidersHorizontal className="w-4 h-4 text-cyan-400" />
              <span>Filtros</span>
            </button>

            {/* Sorting Dropdown */}
            <div className="relative flex-1 sm:flex-initial">
              <div className="flex items-center gap-2 bg-slate-900/90 border border-slate-700/80 rounded-xl px-3 py-2.5 text-xs sm:text-sm text-slate-200">
                <ArrowUpDown className="w-4 h-4 text-cyan-400 shrink-0" />
                <span className="text-slate-400 hidden sm:inline text-xs">Ordenar:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as SortOption)}
                  aria-label="Ordenar produtos"
                  className="bg-transparent text-white font-medium focus:outline-none cursor-pointer pr-4"
                >
                  <option value="featured" className="bg-slate-900">Mais Relevantes</option>
                  <option value="price-asc" className="bg-slate-900">Menor Preço</option>
                  <option value="price-desc" className="bg-slate-900">Maior Preço</option>
                  <option value="newest" className="bg-slate-900">Novidades</option>
                  <option value="rating" className="bg-slate-900">Melhores Avaliados</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Secret Admin Banner when admin password is typed */}
        {isAdminKey && (
          <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-950/80 via-[#061d15] to-[#08182b] border-2 border-emerald-500/80 mb-8 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-2xl animate-in fade-in slide-in-from-top-2">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/20 border border-emerald-400/50 flex items-center justify-center text-emerald-400 shrink-0">
                <Key className="w-6 h-6" />
              </div>
              <div>
                <span className="font-tech font-bold text-white text-base block text-emerald-300">
                  MODO ADMINISTRADOR ATIVADO
                </span>
                <p className="text-xs text-slate-300 mt-0.5">
                  Acesso liberado para alterar fotos dos produtos, preços, estoque e visualizar os compradores.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3 shrink-0">
              <button
                type="button"
                onClick={() => {
                  if (onOpenAdminEditor) {
                    onOpenAdminEditor();
                  } else {
                    setIsAdminOpen(true);
                  }
                }}
                className="px-5 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-tech font-black text-xs uppercase tracking-wider flex items-center gap-2 shadow-xl shadow-emerald-950/50 transition-all hover:scale-105 active:scale-95 cursor-pointer"
              >
                <Settings className="w-4 h-4" />
                <span>Mudar Fotos & Preços</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  if (onOpenBuyersDashboard) {
                    onOpenBuyersDashboard();
                  }
                }}
                className="px-5 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 font-tech font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer"
              >
                <Users className="w-4 h-4 text-cyan-400" />
                <span>Ver Pedidos</span>
              </button>
            </div>
          </div>
        )}

        {/* Main Content Layout: Sidebar Filters + Products Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Desktop Left Sidebar Filters */}
          <aside className={`lg:col-span-3 ${mobileFilterOpen ? 'block' : 'hidden lg:block'}`}>
            <div className="p-5 rounded-2xl bg-[#060C1D] border border-slate-800 space-y-6 sticky top-28">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <span className="font-tech font-bold text-white text-base flex items-center gap-2">
                  <Filter className="w-4 h-4 text-cyan-400" />
                  Filtrar Catálogo
                </span>
                {(selectedCategory !== 'todos' || searchQuery || priceMax < 200) && (
                  <button
                    onClick={() => {
                      setSelectedCategory('todos');
                      setSearchQuery('');
                      setPriceMax(200);
                      setOnlyInStock(false);
                    }}
                    className="text-[11px] text-cyan-400 hover:underline font-semibold cursor-pointer"
                  >
                    Limpar
                  </button>
                )}
              </div>

              {/* Category Filter */}
              <div>
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">
                  Categorias
                </h4>
                <div className="space-y-1">
                  {categoriesList.map((cat) => {
                    const isActive = selectedCategory === cat.id;
                    return (
                      <button
                        key={cat.id}
                        onClick={() => setSelectedCategory(cat.id)}
                        className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-colors cursor-pointer ${
                          isActive
                            ? 'bg-blue-600/20 text-cyan-300 border border-blue-500/40 font-bold'
                            : 'text-slate-400 hover:text-white hover:bg-slate-850'
                        }`}
                      >
                        <span>{cat.label}</span>
                        {cat.id === 'ofertas' && (
                          <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Price Filter Slider */}
              <div className="pt-3 border-t border-slate-800">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                    Preço Máximo
                  </h4>
                  <span className="text-xs font-bold text-cyan-400 font-tech">
                    até {priceMax.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="200"
                  step="5"
                  value={priceMax}
                  onChange={(e) => setPriceMax(Number(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                  <span>R$ 20</span>
                  <span>R$ 100</span>
                  <span>R$ 200+</span>
                </div>
              </div>

              {/* Availability */}
              <div className="pt-3 border-t border-slate-800">
                <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                  <input
                    type="checkbox"
                    checked={onlyInStock}
                    onChange={(e) => setOnlyInStock(e.target.checked)}
                    className="rounded border-slate-700 bg-slate-900 text-cyan-500 focus:ring-0 cursor-pointer"
                  />
                  <span>Apenas produtos em pronta entrega</span>
                </label>
              </div>
            </div>
          </aside>

          {/* Right Area: Products Grid */}
          <main className="lg:col-span-9">
            {filteredProducts.length === 0 ? (
              <div className="py-16 text-center rounded-2xl bg-[#060C1D] border border-slate-800 p-8">
                <div className="w-16 h-16 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-500 mx-auto mb-4">
                  <Search className="w-8 h-8" />
                </div>
                <h3 className="text-white font-tech font-bold text-lg mb-2">
                  Nenhum produto encontrado
                </h3>
                <p className="text-slate-400 text-xs sm:text-sm max-w-md mx-auto mb-6">
                  Tente alterar os filtros de categoria, faixa de preço ou termo pesquisado para encontrar o que procura.
                </p>
                <button
                  onClick={() => {
                    setSelectedCategory('todos');
                    setSearchQuery('');
                    setPriceMax(200);
                  }}
                  className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer"
                >
                  Restaurar Filtros
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onViewDetails={onViewProductDetails}
                  />
                ))}
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
};
