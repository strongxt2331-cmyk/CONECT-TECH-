import React, { useState, useEffect } from 'react';
import {
  Lock,
  QrCode,
  Truck,
  ArrowLeft,
  CheckCircle2,
  Copy,
  Check,
  Smartphone,
  ShieldCheck,
  MapPin,
  ExternalLink,
} from 'lucide-react';
import QRCode from 'qrcode';
import { useCart } from '../context/CartContext';
import { useStore } from '../context/StoreContext';
import { CustomerInfo, Order } from '../types';
import { STORE_CONFIG, getWhatsAppUrl } from '../config';

interface CheckoutPageProps {
  onBackToCart: () => void;
  onOrderSuccess: (order: Order) => void;
}

export const CheckoutPage: React.FC<CheckoutPageProps> = ({
  onBackToCart,
  onOrderSuccess,
}) => {
  const { items, subtotal, discount, shippingCost, finalTotal, clearCart } = useCart();
  const { products, storeConfig } = useStore();

  // Find primary product and check for per-product payment configuration
  const primaryItem = items[0]?.product;
  const livePrimaryProduct = products.find((p) => p.id === primaryItem?.id) || primaryItem;

  const productHasCustomPayment = Boolean(
    livePrimaryProduct?.customQrCodeImage ||
    livePrimaryProduct?.customPixCode ||
    livePrimaryProduct?.paymentLink ||
    (livePrimaryProduct?.customPaymentValue !== undefined && livePrimaryProduct.customPaymentValue > 0)
  );

  const activePaymentLink = livePrimaryProduct?.paymentLink;
  const customChargeValue = livePrimaryProduct?.customPaymentValue;
  const activePixCode = livePrimaryProduct?.customPixCode || storeConfig.pix.code;
  const activeReceiver = storeConfig.pix.receiver;
  const activeCity = storeConfig.locationDisplay || STORE_CONFIG.pix.city;

  // Customer Form State (Defaulted and locked to Santana do Livramento - RS)
  const [formData, setFormData] = useState<CustomerInfo>({
    fullName: '',
    cpf: '',
    phone: '',
    email: '',
    cep: '',
    street: '',
    number: '',
    complement: '',
    neighborhood: '',
    city: 'Santana do Livramento',
    state: 'RS',
  });

  const [deliveryMethod, setDeliveryMethod] = useState<'motoboy' | 'retirada'>('motoboy');
  const [formErrors, setFormErrors] = useState<Partial<Record<keyof CustomerInfo, string>>>({});
  const [copiedPix, setCopiedPix] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>(
    livePrimaryProduct?.customQrCodeImage || storeConfig.pix.qrCodeImage
  );

  // Generate dynamic QR code data URL (respects product custom QR / link / PIX)
  useEffect(() => {
    // 1. If product has uploaded custom QR code image, use it directly!
    if (livePrimaryProduct?.customQrCodeImage) {
      setQrCodeDataUrl(livePrimaryProduct.customQrCodeImage);
      return;
    }

    // 2. Otherwise generate QR code from customPixCode, paymentLink, or store pix code
    const textToEncode =
      livePrimaryProduct?.customPixCode ||
      livePrimaryProduct?.paymentLink ||
      storeConfig.pix.code;

    QRCode.toDataURL(textToEncode, {
      width: 400,
      margin: 2,
      color: {
        dark: '#000000',
        light: '#ffffff',
      },
    })
      .then((url) => setQrCodeDataUrl(url))
      .catch((err) => {
        console.error('Error generating PIX QR Code:', err);
        setQrCodeDataUrl(storeConfig.pix.qrCodeImage);
      });
  }, [livePrimaryProduct, storeConfig]);

  const effectiveTotal = finalTotal;

  // Auto-fill address simulation for CEP ensuring Santana do Livramento - RS
  const handleCepBlur = () => {
    const cleanCep = formData.cep.replace(/\D/g, '');
    if (cleanCep.length === 8 && !formData.street) {
      setFormData((prev) => ({
        ...prev,
        street: prev.street || 'Rua dos Andradas',
        neighborhood: prev.neighborhood || 'Centro',
        city: 'Santana do Livramento',
        state: 'RS',
      }));
    }
  };

  const validateForm = (): boolean => {
    const errors: Partial<Record<keyof CustomerInfo, string>> = {};
    if (!formData.fullName.trim()) errors.fullName = 'Informe seu nome completo';
    if (!formData.cpf.trim() || formData.cpf.replace(/\D/g, '').length < 11) errors.cpf = 'CPF inválido (11 dígitos)';
    if (!formData.phone.trim()) errors.phone = 'Telefone para contato é obrigatório';
    if (!formData.email.trim() || !formData.email.includes('@')) errors.email = 'E-mail válido obrigatório';
    if (!formData.cep.trim()) errors.cep = 'Informe o CEP';
    if (!formData.street.trim()) errors.street = 'Endereço obrigatório';
    if (!formData.number.trim()) errors.number = 'Número obrigatório';
    if (!formData.neighborhood.trim()) errors.neighborhood = 'Bairro obrigatório';

    const normalizedCity = formData.city.trim().toLowerCase();
    const isLivramento = normalizedCity.includes('santana do livramento') || normalizedCity.includes('livramento');

    if (!formData.city.trim()) {
      errors.city = 'Cidade obrigatória';
    } else if (!isLivramento) {
      errors.city = 'Entrega disponível EXCLUSIVAMENTE para Santana do Livramento - RS';
    }

    if (!formData.state.trim()) {
      errors.state = 'UF obrigatória';
    } else if (formData.state.trim().toUpperCase() !== 'RS') {
      errors.state = 'Apenas RS (Santana do Livramento)';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      const newOrder: Order = {
        orderId: `CT-${Math.floor(100000 + Math.random() * 900000)}`,
        createdAt: new Date().toISOString(),
        customer: formData,
        items: [...items],
        subtotal,
        shipping: shippingCost,
        discount,
        total: effectiveTotal,
        paymentMethod: 'pix',
        status: 'confirmed',
      };

      // Save order to localStorage for Admin / Secret Key viewing
      try {
        const existing = localStorage.getItem('connect_tech_orders');
        const list = existing ? JSON.parse(existing) : [];
        list.unshift(newOrder);
        localStorage.setItem('connect_tech_orders', JSON.stringify(list));
      } catch (err) {
        console.error('Error saving order', err);
      }

      // Build WhatsApp message for store with full buyer, product and payment proof
      const totalQty = items.reduce((a, b) => a + b.quantity, 0);
      const itemsListText = items.map((i) => `${i.product.name} (Qtd: ${i.quantity})`).join('\n• ');
      const deliveryText = deliveryMethod === 'motoboy' ? 'Entrega Local / Motoboy (Santana do Livramento)' : 'Retirada em Mãos (Santana do Livramento)';
      const finalPayAmount = customChargeValue ?? effectiveTotal;
      const formattedTotal = finalPayAmount.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
      
      const customPaymentNote = activePaymentLink
        ? `🔗 *Link de Cobrança Usado:* ${activePaymentLink}\n`
        : '';

      const message =
        `*NOVO PEDIDO & COMPROVANTE PIX - CONNECT TECH*\n` +
        `📦 *Pedido:* #${newOrder.orderId}\n` +
        `⚡ *Itens Comprados (Total: ${totalQty}):*\n• ${itemsListText}\n` +
        `💰 *Valor Total Pago:* ${formattedTotal}\n` +
        `💳 *Método:* PIX / Link de Cobrança\n` +
        `🏦 *Beneficiário:* ${activeReceiver}\n` +
        customPaymentNote +
        `\n*DADOS DE ENTREGA LOCAL (SANTANA DO LIVRAMENTO - RS):*\n` +
        `👤 *Nome:* ${formData.fullName}\n` +
        `📄 *CPF:* ${formData.cpf}\n` +
        `📱 *Telefone:* ${formData.phone}\n` +
        `📧 *E-mail:* ${formData.email}\n` +
        `🛵 *Modalidade:* ${deliveryText}\n` +
        `📍 *Endereço:* ${formData.street}, Nº ${formData.number}${formData.complement ? ` (${formData.complement})` : ''}\n` +
        `🏙️ *Bairro:* ${formData.neighborhood}\n` +
        `🌆 *Cidade/UF:* ${formData.city} - ${formData.state} (Exclusivo Santana do Livramento)\n` +
        `📮 *CEP:* ${formData.cep}\n\n` +
        `Olá! Realizei o pagamento no valor de ${formattedTotal} para ${activeReceiver}. Segue em anexo o comprovante da transação para liberação e entrega em Santana do Livramento!`;

      // Redirect user directly to WhatsApp
      const waUrl = getWhatsAppUrl(message);
      window.open(waUrl, '_blank');

      clearCart();
      setIsSubmitting(false);
      onOrderSuccess(newOrder);
    }, 800);
  };

  const copyPixToClipboard = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(activePixCode);
      setCopiedPix(true);
      setTimeout(() => setCopiedPix(false), 3000);
    }
  };

  if (items.length === 0) {
    return (
      <div className="py-20 bg-[#030712] min-h-screen text-center px-4">
        <div className="max-w-md mx-auto p-8 rounded-2xl bg-[#060C1D] border border-slate-800">
          <h2 className="text-xl font-bold text-white mb-2">Não há itens no checkout</h2>
          <p className="text-slate-400 text-xs mb-6">
            Adicione produtos ao carrinho antes de prosseguir para a finalização da compra.
          </p>
          <button
            onClick={onBackToCart}
            className="px-6 py-3 rounded-xl bg-blue-600 text-white text-xs font-bold uppercase tracking-wider cursor-pointer"
          >
            Voltar à loja
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="py-10 bg-[#030712] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Breadcrumb */}
        <div className="flex items-center justify-between mb-8 pb-4 border-b border-slate-800">
          <button
            onClick={onBackToCart}
            className="inline-flex items-center gap-2 text-xs text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Voltar ao carrinho</span>
          </button>
          <div className="flex items-center gap-2 text-xs text-emerald-400">
            <Lock className="w-3.5 h-3.5" />
            <span>Checkout Seguro SSL 256-bit</span>
          </div>
        </div>

        <form onSubmit={handleSubmitOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Left Column: Customer and Payment Forms (7 cols) */}
          <div className="lg:col-span-7 space-y-8">
            {/* 1. Dados Pessoais */}
            <div className="p-6 rounded-2xl bg-[#060C1D] border border-slate-800">
              <h2 className="text-lg font-bold text-white font-tech mb-4 flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-blue-600/30 border border-blue-400/40 text-cyan-400 text-xs flex items-center justify-center font-bold">1</span>
                Dados Pessoais
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="sm:col-span-2">
                  <label className="block text-slate-300 font-semibold mb-1">Nome Completo *</label>
                  <input
                    type="text"
                    required
                    placeholder="Ex: João da Silva Santos"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                  {formErrors.fullName && <span className="text-red-400 text-[11px] mt-1 block">{formErrors.fullName}</span>}
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">CPF *</label>
                  <input
                    type="text"
                    required
                    placeholder="000.000.000-00"
                    value={formData.cpf}
                    onChange={(e) => setFormData({ ...formData, cpf: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                  {formErrors.cpf && <span className="text-red-400 text-[11px] mt-1 block">{formErrors.cpf}</span>}
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Telefone / WhatsApp *</label>
                  <input
                    type="tel"
                    required
                    placeholder="(11) 99999-9999"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                  {formErrors.phone && <span className="text-red-400 text-[11px] mt-1 block">{formErrors.phone}</span>}
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-slate-300 font-semibold mb-1">E-mail para confirmação e rastreio *</label>
                  <input
                    type="email"
                    required
                    placeholder="seu.email@exemplo.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                  {formErrors.email && <span className="text-red-400 text-[11px] mt-1 block">{formErrors.email}</span>}
                </div>
              </div>
            </div>

            {/* 2. Endereço e Opções de Entrega (Exclusivo Santana do Livramento - RS) */}
            <div className="p-6 rounded-2xl bg-[#060C1D] border border-cyan-500/30">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-bold text-white font-tech flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-cyan-600/30 border border-cyan-400/40 text-cyan-400 text-xs flex items-center justify-center font-bold">2</span>
                  Entrega em Santana do Livramento - RS
                </h2>
                <span className="text-[11px] font-bold text-cyan-300 bg-cyan-950/80 border border-cyan-500/40 px-3 py-1 rounded-full flex items-center gap-1.5">
                  <MapPin className="w-3 h-3 text-cyan-400" />
                  Entrega 100% Local
                </span>
              </div>

              {/* Exclusive Location Banner */}
              <div className="p-3.5 mb-5 rounded-xl bg-cyan-950/40 border border-cyan-500/50 flex items-start gap-2.5 text-xs text-slate-200">
                <MapPin className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-cyan-300 block mb-0.5">Atendimento Exclusivo para Santana do Livramento - RS:</strong>
                  A Connect Tech opera exclusivamente em <strong>Santana do Livramento - RS</strong>. Pedidos para outras cidades não são aceitos.
                </div>
              </div>

              {/* Delivery Method Selection */}
              <div className="mb-5">
                <label className="block text-slate-300 font-semibold text-xs mb-2">Forma de Recebimento *</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <label
                    onClick={() => setDeliveryMethod('motoboy')}
                    className={`p-3.5 rounded-xl border flex items-start gap-3 cursor-pointer transition-all ${
                      deliveryMethod === 'motoboy'
                        ? 'bg-blue-950/50 border-cyan-400 shadow-md shadow-cyan-950/30'
                        : 'bg-slate-900 border-slate-700 hover:border-slate-600'
                    }`}
                  >
                    <input
                      type="radio"
                      name="deliveryMethod"
                      checked={deliveryMethod === 'motoboy'}
                      onChange={() => setDeliveryMethod('motoboy')}
                      className="mt-0.5 text-cyan-500 focus:ring-0"
                    />
                    <div>
                      <span className="font-bold text-white block">🛵 Entrega Rápida via Motoboy</span>
                      <span className="text-slate-400 text-[11px]">Direto no seu endereço em Livramento (Hoje ou até 24h)</span>
                      <span className="text-emerald-400 font-bold block text-[11px] mt-1">Frete Grátis</span>
                    </div>
                  </label>

                  <label
                    onClick={() => setDeliveryMethod('retirada')}
                    className={`p-3.5 rounded-xl border flex items-start gap-3 cursor-pointer transition-all ${
                      deliveryMethod === 'retirada'
                        ? 'bg-blue-950/50 border-cyan-400 shadow-md shadow-cyan-950/30'
                        : 'bg-slate-900 border-slate-700 hover:border-slate-600'
                    }`}
                  >
                    <input
                      type="radio"
                      name="deliveryMethod"
                      checked={deliveryMethod === 'retirada'}
                      onChange={() => setDeliveryMethod('retirada')}
                      className="mt-0.5 text-cyan-500 focus:ring-0"
                    />
                    <div>
                      <span className="font-bold text-white block">🤝 Retirada em Mãos</span>
                      <span className="text-slate-400 text-[11px]">Combinar ponto de encontro em Santana do Livramento</span>
                      <span className="text-emerald-400 font-bold block text-[11px] mt-1">Grátis</span>
                    </div>
                  </label>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">CEP (Santana do Livramento) *</label>
                  <input
                    type="text"
                    required
                    placeholder="97573-000"
                    value={formData.cep}
                    onChange={(e) => setFormData({ ...formData, cep: e.target.value })}
                    onBlur={handleCepBlur}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                  {formErrors.cep && <span className="text-red-400 text-[11px] mt-1 block">{formErrors.cep}</span>}
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-slate-300 font-semibold mb-1">Logradouro / Rua *</label>
                  <input
                    type="text"
                    required
                    placeholder="Rua dos Andradas, Av. Tamandaré..."
                    value={formData.street}
                    onChange={(e) => setFormData({ ...formData, street: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                  {formErrors.street && <span className="text-red-400 text-[11px] mt-1 block">{formErrors.street}</span>}
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Número *</label>
                  <input
                    type="text"
                    required
                    placeholder="123"
                    value={formData.number}
                    onChange={(e) => setFormData({ ...formData, number: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                  {formErrors.number && <span className="text-red-400 text-[11px] mt-1 block">{formErrors.number}</span>}
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-slate-300 font-semibold mb-1">Complemento (opcional)</label>
                  <input
                    type="text"
                    placeholder="Apto 42, Casa, etc."
                    value={formData.complement}
                    onChange={(e) => setFormData({ ...formData, complement: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Bairro em Livramento *</label>
                  <input
                    type="text"
                    required
                    placeholder="Centro, Armour, Prado..."
                    value={formData.neighborhood}
                    onChange={(e) => setFormData({ ...formData, neighborhood: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                  {formErrors.neighborhood && <span className="text-red-400 text-[11px] mt-1 block">{formErrors.neighborhood}</span>}
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Cidade (Exclusiva) *</label>
                  <input
                    type="text"
                    required
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900/90 border border-cyan-500/50 text-cyan-300 font-bold focus:outline-none focus:border-cyan-400"
                  />
                  {formErrors.city && <span className="text-red-400 text-[11px] mt-1 block font-semibold">{formErrors.city}</span>}
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Estado (UF) *</label>
                  <input
                    type="text"
                    required
                    maxLength={2}
                    value={formData.state}
                    onChange={(e) => setFormData({ ...formData, state: e.target.value.toUpperCase() })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900/90 border border-cyan-500/50 text-cyan-300 font-bold focus:outline-none focus:border-cyan-400 uppercase"
                  />
                  {formErrors.state && <span className="text-red-400 text-[11px] mt-1 block font-semibold">{formErrors.state}</span>}
                </div>
              </div>
            </div>

            {/* 3. Forma de Pagamento Exclusiva: PIX ou Link Direto */}
            <div className="p-6 rounded-2xl bg-[#060C1D] border border-emerald-500/40 shadow-xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4 pb-3 border-b border-slate-800">
                <h2 className="text-lg font-bold text-white font-tech flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-emerald-500/20 border border-emerald-400 text-emerald-400 text-xs flex items-center justify-center font-bold">3</span>
                  Forma de Pagamento (PIX / Link Direto)
                </h2>
                <span className="text-xs font-bold text-emerald-400 bg-emerald-950/70 border border-emerald-500/40 px-3 py-1 rounded-full flex items-center gap-1.5 shadow-sm w-fit">
                  <QrCode className="w-3.5 h-3.5 text-emerald-400" />
                  {productHasCustomPayment ? 'QR Code Exclusivo do Produto' : 'QR Code & Chave Oficial'}
                </span>
              </div>

              {/* Product Custom Payment Badge (if active on product) */}
              {productHasCustomPayment && livePrimaryProduct && (
                <div className="mb-4 p-3.5 rounded-xl bg-gradient-to-r from-blue-950/70 via-[#071d2b] to-emerald-950/60 border border-cyan-500/40 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-lg bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 shrink-0">
                      <QrCode className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-white block">
                        Cobrança Exclusiva: {livePrimaryProduct.name}
                      </span>
                      {livePrimaryProduct.paymentInstructions && (
                        <span className="text-[11px] text-cyan-300 block">
                          {livePrimaryProduct.paymentInstructions}
                        </span>
                      )}
                    </div>
                  </div>
                  {customChargeValue && (
                    <span className="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 font-tech font-bold text-xs border border-emerald-500/30 w-fit">
                      Valor do QR: {customChargeValue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    </span>
                  )}
                </div>
              )}

              {/* Direct Payment Link Action Button (Mercado Pago, PagBank, InfinitePay, Nubank, etc.) */}
              {activePaymentLink && (
                <div className="mb-6 p-4 rounded-2xl bg-gradient-to-r from-blue-950/80 via-[#091e36] to-cyan-950/80 border-2 border-cyan-400/50 shadow-xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-cyan-300 flex items-center gap-1.5 uppercase tracking-wide">
                      <ExternalLink className="w-4 h-4 text-cyan-400" />
                      Link de Pagamento Direto Deste Produto
                    </span>
                    {customChargeValue && (
                      <span className="text-sm font-black text-emerald-400 font-tech">
                        {customChargeValue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </span>
                    )}
                  </div>
                  <a
                    href={activePaymentLink.startsWith('http') ? activePaymentLink : `https://${activePaymentLink}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-blue-600 via-cyan-600 to-emerald-600 hover:from-blue-500 hover:to-emerald-500 text-white font-tech font-extrabold text-xs sm:text-sm uppercase tracking-wider flex items-center justify-center gap-2.5 shadow-xl shadow-cyan-950/60 transition-all hover:scale-[1.01] active:scale-[0.99] text-center cursor-pointer"
                  >
                    <ExternalLink className="w-4 h-4 shrink-0" />
                    <span>Abrir Link de Cobrança / Pagar Agora</span>
                  </a>
                  <p className="text-[10px] text-slate-300 text-center">
                    Toque no botão acima para abrir a página de pagamento no Mercado Pago, InfinitePay ou banco configurado.
                  </p>
                </div>
              )}

              {/* PIX Box with QR Code & Copia e Cola */}
              <div className="p-5 sm:p-6 rounded-2xl bg-[#081226] border border-emerald-500/30 space-y-6">
                <div className="flex flex-col md:flex-row items-center gap-6">
                  {/* High contrast QR Code Box */}
                  <div className="bg-white p-3.5 rounded-2xl shadow-2xl border-4 border-emerald-500/30 shrink-0 text-center">
                    <img
                      src={qrCodeDataUrl}
                      alt={`QR Code - ${activeReceiver}`}
                      className="w-48 h-48 sm:w-52 sm:h-52 mx-auto object-contain"
                    />
                    <span className="block text-[11px] font-black text-slate-900 mt-1 uppercase tracking-wider">
                      Aponte a câmera do seu banco
                    </span>
                  </div>

                  {/* PIX Details & Step-by-Step */}
                  <div className="space-y-3 flex-1 text-xs w-full">
                    <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                      <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                        <span className="text-[11px] text-slate-400 uppercase font-semibold">Beneficiário</span>
                        <span className="text-white font-bold text-xs sm:text-sm text-cyan-300">
                          {activeReceiver}
                        </span>
                      </div>
                      <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                        <span className="text-[11px] text-slate-400 uppercase font-semibold">Cidade / Praça</span>
                        <span className="text-slate-200 font-semibold text-xs">
                          {activeCity}
                        </span>
                      </div>
                      <div className="flex items-center justify-between pt-1">
                        <div>
                          <span className="text-[11px] text-slate-400 uppercase font-semibold block">
                            {customChargeValue ? 'Valor da Cobrança do Produto' : 'Valor a Pagar'}
                          </span>
                          {customChargeValue && customChargeValue !== effectiveTotal && (
                            <span className="text-[10px] text-cyan-400 font-medium">
                              (Valor customizado do QR Code)
                            </span>
                          )}
                        </div>
                        <span className="text-xl sm:text-2xl font-black text-emerald-400 font-tech">
                          {(customChargeValue ?? effectiveTotal).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        </span>
                      </div>
                    </div>

                    <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 text-slate-300 space-y-1.5">
                      <p className="font-bold text-slate-200 flex items-center gap-1.5 text-xs">
                        <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
                        Passo a passo rápido:
                      </p>
                      <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-300">
                        <li>Abra o aplicativo do seu banco (qualquer banco)</li>
                        <li>Escolha a opção <strong>PIX</strong> e aponte para o <strong>QR Code</strong></li>
                        <li>Ou use o botão <strong>Copiar Código Pix</strong> abaixo</li>
                        <li>Após pagar, clique em <strong>Confirmar e Enviar Comprovante</strong></li>
                      </ol>
                    </div>
                  </div>
                </div>

                {/* Pix Copia e Cola Code with Copy Button */}
                <div className="space-y-2 pt-3 border-t border-slate-800">
                  <div className="flex items-center justify-between text-xs">
                    <label className="text-slate-300 font-bold flex items-center gap-1.5">
                      <Copy className="w-3.5 h-3.5 text-cyan-400" />
                      Código Pix Copia e Cola:
                    </label>
                    <span className="text-[11px] text-emerald-400 font-medium">Toque para copiar</span>
                  </div>
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 p-2 rounded-xl bg-slate-950 border border-slate-800">
                    <input
                      type="text"
                      readOnly
                      value={activePixCode}
                      onClick={copyPixToClipboard}
                      className="w-full bg-transparent text-slate-300 font-mono text-xs px-3 py-2 outline-none select-all truncate cursor-pointer"
                    />
                    <button
                      type="button"
                      onClick={copyPixToClipboard}
                      className={`px-5 py-3 rounded-xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shrink-0 cursor-pointer ${
                        copiedPix
                          ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/40'
                          : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md'
                      }`}
                    >
                      {copiedPix ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                      <span>{copiedPix ? 'CÓDIGO COPIADO!' : 'COPIAR CÓDIGO PIX'}</span>
                    </button>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30 flex items-center gap-2.5 text-[11px] text-emerald-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>
                    Chave PIX e dados de cobrança conferidos para liberação rápida da entrega em Santana do Livramento.
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Order Summary (5 cols) */}
          <div className="lg:col-span-5">
            <div className="p-6 rounded-2xl bg-[#060C1D] border border-slate-800 sticky top-28 space-y-6">
              <h2 className="font-tech font-bold text-white text-lg pb-3 border-b border-slate-800">
                Resumo do Pedido ({items.length} {items.length === 1 ? 'item' : 'itens'})
              </h2>

              {/* Items Mini List */}
              <div className="divide-y divide-slate-800/80 max-h-60 overflow-y-auto pr-1">
                {items.map((it) => (
                  <div key={`${it.product.id}-${it.selectedColor}`} className="py-3 flex items-center gap-3">
                    <img
                      src={it.product.image}
                      alt={it.product.name}
                      className="w-12 h-12 rounded-lg object-cover bg-slate-900 border border-slate-800 shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-semibold text-white truncate">
                        {it.product.name}
                      </h4>
                      <span className="text-[11px] text-slate-400 block">
                        Qtd: {it.quantity} {it.selectedColor && ` | ${it.selectedColor}`}
                      </span>
                    </div>
                    <span className="text-xs font-bold text-white font-tech shrink-0">
                      {(it.product.price * it.quantity).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    </span>
                  </div>
                ))}
              </div>

              {/* Pricing Breakdown */}
              <div className="space-y-2 text-xs pt-2 border-t border-slate-800">
                <div className="flex justify-between text-slate-400">
                  <span>Subtotal</span>
                  <span className="text-slate-200 font-semibold">
                    {subtotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span className="flex items-center gap-1">
                    <Truck className="w-3.5 h-3.5 text-cyan-400" />
                    Frete para seu endereço
                  </span>
                  <span className="font-semibold text-slate-200">
                    {shippingCost === 0 ? (
                      <span className="text-emerald-400 font-bold uppercase text-[11px]">Grátis</span>
                    ) : (
                      shippingCost.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
                    )}
                  </span>
                </div>
                <div className="flex justify-between items-baseline text-lg font-bold text-white pt-3 border-t border-slate-800 font-tech">
                  <div>
                    <span>Total</span>
                    <span className="block text-[10px] text-emerald-400 font-sans font-semibold uppercase">Pagamento Exclusivo PIX</span>
                  </div>
                  <span className="text-cyan-300 text-2xl font-black">
                    {effectiveTotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </span>
                </div>
              </div>

              {/* Important WhatsApp Notice required by user */}
              <div className="p-4 rounded-2xl bg-[#091B16] border-2 border-emerald-500/70 shadow-lg shadow-emerald-950/40 animate-pulse">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  </div>
                  <div>
                    <span className="font-tech font-bold text-white text-xs sm:text-sm block text-emerald-300">
                      AVISO IMPORTANTE ANTES DO PAGAMENTO:
                    </span>
                    <p className="text-white font-semibold text-xs leading-relaxed mt-1">
                      Você será redirecionado para o WhatsApp (<span className="text-emerald-300 font-bold">{STORE_CONFIG.whatsapp.displayNumber}</span>) para enviar o comprovante da compra e confirmar o envio imediato!
                    </p>
                  </div>
                </div>
              </div>

              {/* Submit Order Button */}
              <button
                type="submit"
                id="btn-confirm-order"
                disabled={isSubmitting}
                className="w-full py-4 rounded-xl bg-gradient-to-r from-emerald-600 via-blue-600 to-cyan-500 hover:from-emerald-500 hover:to-cyan-400 text-white font-black text-sm uppercase tracking-wider shadow-xl shadow-emerald-950/40 flex items-center justify-center gap-2 active:scale-98 transition-all disabled:opacity-75 cursor-pointer"
              >
                {isSubmitting ? (
                  <span>Processando e Redirecionando...</span>
                ) : (
                  <>
                    <Lock className="w-4 h-4" />
                    <span>CONFIRMAR E ENVIAR COMPROVANTE</span>
                  </>
                )}
              </button>

              <div className="flex items-center justify-center gap-2 text-[10px] text-slate-400">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Garantia de Entrega e Suporte Humano Connect Tech</span>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
