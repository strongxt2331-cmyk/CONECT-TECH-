import React, { useState } from 'react';
import {
  Mail,
  Clock,
  Send,
  MessageCircle,
  Instagram,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  ShieldCheck,
  MapPin,
} from 'lucide-react';
import { STORE_CONFIG, getWhatsAppUrl } from '../config';

export const ContactPage: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const faqs = [
    {
      question: 'Qual a região atendida e como funciona a entrega?',
      answer:
        'A Connect Tech atende EXCLUSIVAMENTE a cidade de Santana do Livramento - RS! Todos os nossos produtos têm estoque local pronta entrega. Oferecemos entrega expressa via motoboy no mesmo dia ou retirada em mãos previamente combinada pelo WhatsApp.',
    },
    {
      question: 'Qual o período de garantia dos produtos Connect Tech?',
      answer:
        'Todos os nossos carregadores, cabos reforçados e acessórios possuem garantia de até 12 meses contra defeitos de fabricação, com suporte e troca direta na cidade de Santana do Livramento - RS.',
    },
    {
      question: 'Os produtos são compatíveis com os aparelhos mais novos?',
      answer:
        'Sim! Nosso Carregador Turbo iPhone 20W PD é compatível do iPhone 8 até o iPhone 14, e nosso novo Power Bank Carregador Sem Fio Basike é compatível com qualquer celular com tecnologia Qi (iPhone, Samsung Galaxy, Xiaomi e outros).',
    },
    {
      question: 'Como funciona o pagamento via PIX?',
      answer:
        'O pagamento é realizado de forma rápida e segura via QR Code oficial ou Chave Copia e Cola com o valor exato do seu pedido. Após o pagamento, o comprovante é enviado diretamente pelo WhatsApp para combinarmos a entrega expressa ou retirada em Santana do Livramento.',
    },
  ];

  return (
    <div className="py-12 bg-[#030712] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-slate-500 mb-6 font-medium">
          <span>Início</span>
          <span>/</span>
          <span className="text-cyan-400">Atendimento ao Cliente</span>
        </div>

        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/60 border border-cyan-500/40 text-cyan-300 text-xs font-semibold mb-3">
            <MapPin className="w-3.5 h-3.5 text-cyan-400" />
            Atendimento Exclusivo em Santana do Livramento - RS
          </div>
          <h1 className="font-tech text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            ENTRE EM CONTATO
          </h1>
          <p className="text-slate-400 text-sm mt-2">
            Estamos prontos para atender você em Santana do Livramento. Escolha seu canal preferido ou envie uma mensagem direta abaixo.
          </p>
        </div>

        {/* Quick Contact Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-16">
          {/* WhatsApp Card */}
          <a
            href={getWhatsAppUrl()}
            target="_blank"
            rel="noopener noreferrer"
            className="p-6 rounded-2xl bg-gradient-to-b from-[#061814] to-[#040E0C] border border-emerald-500/40 hover:border-emerald-400 transition-all duration-300 group shadow-lg flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-xl bg-emerald-600/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mb-4 group-hover:scale-110 transition-transform">
                <MessageCircle className="w-6 h-6" />
              </div>
              <h3 className="font-tech font-bold text-white text-lg mb-1 group-hover:text-emerald-300">
                WhatsApp Oficial
              </h3>
              <p className="text-slate-400 text-xs mb-3">
                Atendimento ágil para tirar dúvidas técnicas e fazer pedidos.
              </p>
            </div>
            <span className="text-sm font-bold text-emerald-400 flex items-center gap-1">
              {STORE_CONFIG.whatsapp.displayNumber}
            </span>
          </a>

          {/* Email Card */}
          <a
            href={`mailto:${STORE_CONFIG.contact.email}`}
            className="p-6 rounded-2xl bg-[#060C1D] border border-blue-500/40 hover:border-cyan-400 transition-all duration-300 group shadow-lg flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-cyan-400 mb-4 group-hover:scale-110 transition-transform">
                <Mail className="w-6 h-6" />
              </div>
              <h3 className="font-tech font-bold text-white text-lg mb-1 group-hover:text-cyan-300">
                E-mail Corporativo
              </h3>
              <p className="text-slate-400 text-xs mb-3">
                Envie suas dúvidas, propostas ou solicitações de garantia.
              </p>
            </div>
            <span className="text-sm font-bold text-cyan-400 truncate">
              {STORE_CONFIG.contact.email}
            </span>
          </a>

          {/* Instagram Card */}
          <a
            href={STORE_CONFIG.social.instagram}
            target="_blank"
            rel="noopener noreferrer"
            className="p-6 rounded-2xl bg-[#080718] border border-purple-500/30 hover:border-pink-500/60 transition-all duration-300 group shadow-lg flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-xl bg-pink-600/20 border border-pink-500/30 flex items-center justify-center text-pink-400 mb-4 group-hover:scale-110 transition-transform">
                <Instagram className="w-6 h-6" />
              </div>
              <h3 className="font-tech font-bold text-white text-lg mb-1 group-hover:text-pink-300">
                Instagram
              </h3>
              <p className="text-slate-400 text-xs mb-3">
                Novidades diárias, demonstrações em vídeo e cupons especiais.
              </p>
            </div>
            <span className="text-sm font-bold text-pink-400">
              @connecttech.oficial
            </span>
          </a>
        </div>

        {/* Contact Form & Hours Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 mb-16 items-start">
          {/* Form */}
          <div className="lg:col-span-7 p-6 sm:p-8 rounded-3xl bg-[#060C1D] border border-slate-800 shadow-xl">
            <h2 className="font-tech font-bold text-white text-xl mb-2">
              Envie uma Mensagem
            </h2>
            <p className="text-slate-400 text-xs sm:text-sm mb-6">
              Preencha o formulário e responderemos em até poucas horas no seu e-mail ou WhatsApp.
            </p>

            {submitted ? (
              <div className="p-6 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-center space-y-3 animate-in fade-in">
                <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center">
                  <CheckCircle2 className="w-7 h-7" />
                </div>
                <h3 className="font-tech font-bold text-white text-lg">Mensagem enviada com sucesso!</h3>
                <p className="text-slate-300 text-xs max-w-sm mx-auto">
                  Agradecemos seu contato. Nossa equipe técnica entrará em contato com você o mais breve possível.
                </p>
                <button
                  onClick={() => {
                    setSubmitted(false);
                    setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 text-xs font-bold cursor-pointer"
                >
                  Enviar outra mensagem
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4 text-xs">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Nome Completo *</label>
                  <input
                    type="text"
                    required
                    placeholder="Seu nome"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">E-mail *</label>
                    <input
                      type="email"
                      required
                      placeholder="seu.email@exemplo.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Telefone / WhatsApp *</label>
                    <input
                      type="tel"
                      required
                      placeholder="(11) 99999-9999"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Assunto *</label>
                  <input
                    type="text"
                    required
                    placeholder="Ex: Dúvida sobre compatibilidade de cabo / Status de entrega"
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Mensagem *</label>
                  <textarea
                    required
                    rows={4}
                    placeholder="Descreva detalhadamente como podemos te ajudar..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  ></textarea>
                </div>
                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-blue-600 via-blue-500 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-bold text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30 transition-all active:scale-98 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>Enviar Mensagem</span>
                </button>
              </form>
            )}
          </div>

          {/* Working Hours & Support Info */}
          <div className="lg:col-span-5 space-y-6">
            <div className="p-6 rounded-3xl bg-[#060C1D] border border-slate-800">
              <h3 className="font-tech font-bold text-white text-lg mb-4 flex items-center gap-2">
                <Clock className="w-5 h-5 text-cyan-400" />
                Horário de Atendimento
              </h3>
              <p className="text-slate-300 text-xs sm:text-sm leading-relaxed mb-4">
                Nossa central de atendimento técnico e suporte comercial opera nos seguintes horários:
              </p>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-2 border-b border-slate-800">
                  <span className="text-slate-400">Segunda a Sexta</span>
                  <span className="font-bold text-white">08:00 às 19:00</span>
                </div>
                <div className="flex justify-between py-2 border-b border-slate-800">
                  <span className="text-slate-400">Sábados</span>
                  <span className="font-bold text-white">09:00 às 14:00</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-slate-400">Domingos e Feriados</span>
                  <span className="text-slate-500">Plantão via WhatsApp</span>
                </div>
              </div>
            </div>

            <div className="p-6 rounded-3xl bg-[#060C1D] border border-slate-800">
              <h3 className="font-tech font-bold text-white text-lg mb-3 flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                Atendimento Seguro
              </h3>
              <p className="text-slate-400 text-xs leading-relaxed">
                Nunca solicitamos senhas, dados de cartão de crédito por mensagens ou senhas bancárias. Todas as compras são realizadas diretamente através do nosso ambiente seguro certificado.
              </p>
            </div>
          </div>
        </div>

        {/* FAQ Accordion Section */}
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="font-tech text-2xl sm:text-3xl font-bold text-white">
              PERGUNTAS FREQUENTES (FAQ)
            </h2>
            <p className="text-slate-400 text-xs sm:text-sm mt-1">
              Respostas rápidas para as dúvidas mais comuns sobre compras e produtos.
            </p>
          </div>

          <div className="space-y-3">
            {faqs.map((faq, idx) => {
              const isOpen = openFaqIndex === idx;
              return (
                <div
                  key={idx}
                  className="rounded-2xl bg-[#060C1D] border border-slate-800 overflow-hidden transition-colors"
                >
                  <button
                    onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                    className="w-full p-5 text-left flex items-center justify-between gap-4 font-tech font-bold text-sm sm:text-base text-white hover:text-cyan-300 transition-colors cursor-pointer"
                  >
                    <span>{faq.question}</span>
                    {isOpen ? (
                      <ChevronUp className="w-5 h-5 text-cyan-400 shrink-0" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-slate-400 shrink-0" />
                    )}
                  </button>
                  {isOpen && (
                    <div className="px-5 pb-5 text-xs sm:text-sm text-slate-300 leading-relaxed border-t border-slate-800/80 pt-3">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
