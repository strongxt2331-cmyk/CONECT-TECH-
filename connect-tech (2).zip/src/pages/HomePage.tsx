import React from 'react';
import { Hero } from '../components/Hero';
import { BenefitsBar } from '../components/BenefitsBar';
import { ProductCard } from '../components/ProductCard';
import { Product, ProductCategory } from '../types';
import { Zap, MapPin } from 'lucide-react';
import { STORE_CONFIG } from '../config';
import { useStore } from '../context/StoreContext';

interface HomePageProps {
  onViewProductDetails: (product: Product) => void;
  onNavigate: (view: string, categoryId?: string) => void;
  onSelectCategory: (category: ProductCategory) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onViewProductDetails,
  onNavigate,
  onSelectCategory,
}) => {
  const { products } = useStore();
  const featuredProducts = products;

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <Hero
        onExploreProducts={() => onNavigate('products')}
        onExploreOffers={() => onNavigate('products')}
        onSelectCategory={onSelectCategory}
      />

      {/* Benefits Bar */}
      <BenefitsBar />

      {/* Featured Products & Special Promotions Section */}
      <section id="featured-products-section" className="py-16 bg-[#030712] relative">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4 border-b border-blue-900/30 pb-6">
            <div>
              <div className="flex items-center gap-2 text-cyan-400 text-xs font-bold uppercase tracking-widest mb-2">
                <MapPin className="w-4 h-4 text-cyan-400" />
                Exclusivo para Santana do Livramento - RS
              </div>
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white font-tech tracking-tight">
                PRODUTOS & PROMOÇÕES ESPECIAIS
              </h2>
            </div>
            <div className="px-4 py-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold text-xs flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>Estoque pronta entrega na cidade</span>
            </div>
          </div>

          {/* Responsive Products Presentation */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {featuredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onViewDetails={onViewProductDetails}
              />
            ))}
          </div>
        </div>
      </section>

      {/* WhatsApp Order & Proof Banner */}
      <section className="py-12 bg-[#050B1B] border-t border-slate-800/80">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="p-8 rounded-3xl bg-gradient-to-r from-[#07161b] via-[#09152b] to-[#061124] border border-emerald-500/40 flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left shadow-2xl">
            <div>
              <span className="px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 font-bold text-[11px] uppercase tracking-wider mb-3 inline-block">
                Entrega Rápida em Santana do Livramento
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-white font-tech mb-2">
                Garanta o seu produto com entrega local hoje
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
                Após preencher seus dados, você será redirecionado para o WhatsApp ({STORE_CONFIG.whatsapp.displayNumber}) para enviar o comprovante e combinarmos a entrega expressa via motoboy ou retirada em mãos em Santana do Livramento.
              </p>
            </div>
            <button
              onClick={() => onNavigate('products')}
              className="px-8 py-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase tracking-wider shadow-lg shadow-emerald-950/50 shrink-0 transition-all hover:scale-105 cursor-pointer"
            >
              Ver Catálogo Completo
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
