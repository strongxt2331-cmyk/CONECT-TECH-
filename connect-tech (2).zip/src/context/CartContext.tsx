import React, { createContext, useContext, useState, useEffect } from 'react';
import { CartItem, Product } from '../types';
import { STORE_CONFIG } from '../config';

interface CartContextType {
  items: CartItem[];
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  addItem: (product: Product, quantity?: number, color?: string) => void;
  removeItem: (productId: string, color?: string) => void;
  updateQuantity: (productId: string, quantity: number, color?: string) => void;
  clearCart: () => void;
  totalItemsCount: number;
  subtotal: number;
  discount: number;
  couponCode: string;
  appliedCoupon: string | null;
  applyCoupon: (code: string) => boolean;
  removeCoupon: () => void;
  couponError: string | null;
  shippingCost: number;
  shippingOption: 'standard' | 'express' | 'free';
  setShippingOption: (option: 'standard' | 'express' | 'free') => void;
  cep: string;
  setCep: (cep: string) => void;
  calculateShippingByCep: (userCep: string) => void;
  finalTotal: number;
  notification: string | null;
}

const CartContext = createContext<CartContextType | undefined>(undefined);
const CART_STORAGE_KEY = 'connect_tech_cart_v1';

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(CART_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isOpen, setIsOpen] = useState(false);
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);
  const [couponCode, setCouponCode] = useState('');
  const [couponError, setCouponError] = useState<string | null>(null);
  const [cep, setCep] = useState('');
  const [shippingOption, setShippingOption] = useState<'standard' | 'express' | 'free'>('standard');
  const [notification, setNotification] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items));
    } catch (e) {
      console.warn('Failed to persist cart:', e);
    }
  }, [items]);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification((prev) => (prev === msg ? null : prev));
    }, 3200);
  };

  const addItem = (product: Product, quantity = 1, color?: string) => {
    setItems((prev) => {
      const targetColor = color || (product.colors ? product.colors[0] : undefined);
      const existingIndex = prev.findIndex(
        (item) => item.product.id === product.id && item.selectedColor === targetColor
      );

      if (existingIndex > -1) {
        const updated = [...prev];
        const newQty = updated[existingIndex].quantity + quantity;
        updated[existingIndex] = {
          ...updated[existingIndex],
          quantity: Math.min(newQty, product.stockCount || 99),
        };
        return updated;
      } else {
        return [
          ...prev,
          {
            product,
            quantity: Math.min(quantity, product.stockCount || 99),
            selectedColor: targetColor,
          },
        ];
      }
    });
    showNotification(`"${product.name}" adicionado ao carrinho!`);
  };

  const removeItem = (productId: string, color?: string) => {
    setItems((prev) =>
      prev.filter(
        (item) => !(item.product.id === productId && (!color || item.selectedColor === color))
      )
    );
  };

  const updateQuantity = (productId: string, quantity: number, color?: string) => {
    if (quantity <= 0) {
      removeItem(productId, color);
      return;
    }
    setItems((prev) =>
      prev.map((item) => {
        if (item.product.id === productId && (!color || item.selectedColor === color)) {
          return {
            ...item,
            quantity: Math.min(quantity, item.product.stockCount || 99),
          };
        }
        return item;
      })
    );
  };

  const clearCart = () => {
    setItems([]);
    setAppliedCoupon(null);
  };

  const totalItemsCount = items.reduce((acc, curr) => acc + curr.quantity, 0);

  const subtotal = items.reduce(
    (acc, curr) => acc + curr.product.price * curr.quantity,
    0
  );

  const isFreeShippingEligible = subtotal >= STORE_CONFIG.shipping.freeShippingThreshold;

  const calculateShippingByCep = (inputCep: string) => {
    setCep(inputCep);
    if (inputCep.replace(/\D/g, '').length === 8) {
      if (isFreeShippingEligible) {
        setShippingOption('free');
      } else {
        setShippingOption('standard');
      }
    }
  };

  let shippingCost = 0;
  if (items.length === 0) {
    shippingCost = 0;
  } else if (isFreeShippingEligible) {
    shippingCost = shippingOption === 'express' ? STORE_CONFIG.shipping.defaultExpressShipping - 10 : 0;
  } else {
    shippingCost =
      shippingOption === 'express'
        ? STORE_CONFIG.shipping.defaultExpressShipping
        : STORE_CONFIG.shipping.defaultStandardShipping;
  }

  // Discounts and coupons removed
  const discount = 0;

  const applyCoupon = (_code: string): boolean => {
    return false;
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    setCouponCode('');
    setCouponError(null);
  };

  const finalTotal = Math.max(0, subtotal + (items.length > 0 ? shippingCost : 0));

  return (
    <CartContext.Provider
      value={{
        items,
        isOpen,
        setIsOpen,
        addItem,
        removeItem,
        updateQuantity,
        clearCart,
        totalItemsCount,
        subtotal,
        discount,
        couponCode,
        appliedCoupon,
        applyCoupon,
        removeCoupon,
        couponError,
        shippingCost,
        shippingOption,
        setShippingOption,
        cep,
        setCep,
        calculateShippingByCep,
        finalTotal,
        notification,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
