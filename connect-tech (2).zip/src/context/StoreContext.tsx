import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { Product } from '../types';
import { PRODUCTS_DATA as INITIAL_PRODUCTS } from '../data/products';
import { STORE_CONFIG as INITIAL_CONFIG } from '../config';

interface StoreConfigType {
  name: string;
  tagline: string;
  subtitle: string;
  city: string;
  state: string;
  locationDisplay: string;
  whatsapp: {
    displayNumber: string;
    cleanNumber: string;
    defaultMessage: string;
  };
  pix: {
    code: string;
    receiver: string;
    city: string;
    amount: number;
    qrCodeImage: string;
  };
  adminSecretKey: string;
  aboutText: string;
}

interface StoreContextType {
  products: Product[];
  storeConfig: StoreConfigType;
  updateProduct: (productId: string, updatedFields: Partial<Product>) => void;
  addProduct: (product: Product) => void;
  deleteProduct: (productId: string) => void;
  updateStoreConfig: (newConfig: Partial<StoreConfigType>) => void;
  resetToDefaults: () => void;
  verifyAdminPassword: (inputPassword: string) => boolean;
  isAdminOpen: boolean;
  setIsAdminOpen: (open: boolean) => void;
  // Global Live Server Sync across all clients
  isOnlineSynced: boolean;
  isPublishing: boolean;
  lastSyncTimestamp: number | null;
  autoPublishToAll: boolean;
  setAutoPublishToAll: (enabled: boolean) => void;
  publishToAllUsers: (customProducts?: Product[], customConfig?: StoreConfigType) => Promise<{ success: boolean; message: string }>;
  refreshFromServer: () => Promise<void>;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

const STORAGE_PRODUCTS_KEY = 'connect_tech_products_v2';
const STORAGE_CONFIG_KEY = 'connect_tech_config_v2';
const STORAGE_PASS_KEY = 'connect_tech_admin_key';
const STORAGE_AUTO_PUBLISH_KEY = 'connect_tech_auto_publish';

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load products from localStorage or use INITIAL_PRODUCTS
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PRODUCTS_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (err) {
      console.error('Error loading saved products', err);
    }
    return INITIAL_PRODUCTS;
  });

  // Load config from localStorage or use INITIAL_CONFIG
  const [storeConfig, setStoreConfig] = useState<StoreConfigType>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_CONFIG_KEY);
      const savedKey = localStorage.getItem(STORAGE_PASS_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...INITIAL_CONFIG,
          ...parsed,
          adminSecretKey: savedKey || parsed.adminSecretKey || INITIAL_CONFIG.adminSecretKey,
        };
      }
      if (savedKey) {
        return { ...INITIAL_CONFIG, adminSecretKey: savedKey };
      }
    } catch (err) {
      console.error('Error loading saved config', err);
    }
    return {
      name: INITIAL_CONFIG.name,
      tagline: INITIAL_CONFIG.tagline,
      subtitle: INITIAL_CONFIG.subtitle,
      city: INITIAL_CONFIG.city,
      state: INITIAL_CONFIG.state,
      locationDisplay: INITIAL_CONFIG.locationDisplay,
      whatsapp: { ...INITIAL_CONFIG.whatsapp },
      pix: { ...INITIAL_CONFIG.pix },
      adminSecretKey: INITIAL_CONFIG.adminSecretKey,
      aboutText: INITIAL_CONFIG.aboutText,
    };
  });

  const [isAdminOpen, setIsAdminOpen] = useState<boolean>(false);
  const [isOnlineSynced, setIsOnlineSynced] = useState<boolean>(false);
  const [isPublishing, setIsPublishing] = useState<boolean>(false);
  const [lastSyncTimestamp, setLastSyncTimestamp] = useState<number | null>(null);
  
  // Option: automatically publish all saved changes to server for everyone
  const [autoPublishToAll, setAutoPublishToAllState] = useState<boolean>(() => {
    const saved = localStorage.getItem(STORAGE_AUTO_PUBLISH_KEY);
    return saved !== null ? saved === 'true' : true; // Default TRUE as requested by user
  });

  const setAutoPublishToAll = (enabled: boolean) => {
    setAutoPublishToAllState(enabled);
    localStorage.setItem(STORAGE_AUTO_PUBLISH_KEY, String(enabled));
  };

  // Ref to always access latest state in callbacks
  const latestProductsRef = useRef(products);
  const latestConfigRef = useRef(storeConfig);
  const lastSyncTimestampRef = useRef(lastSyncTimestamp);

  useEffect(() => {
    latestProductsRef.current = products;
  }, [products]);

  useEffect(() => {
    latestConfigRef.current = storeConfig;
  }, [storeConfig]);

  useEffect(() => {
    lastSyncTimestampRef.current = lastSyncTimestamp;
  }, [lastSyncTimestamp]);

  // Save products to localStorage whenever they change
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_PRODUCTS_KEY, JSON.stringify(products));
    } catch (err) {
      console.error('Error saving products to localStorage', err);
    }
  }, [products]);

  // Save config to localStorage whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_CONFIG_KEY, JSON.stringify(storeConfig));
      localStorage.setItem(STORAGE_PASS_KEY, storeConfig.adminSecretKey);
    } catch (err) {
      console.error('Error saving config to localStorage', err);
    }
  }, [storeConfig]);

  // Function to explicitly publish current or passed data to server for all visitors
  const publishToAllUsers = async (
    customProducts?: Product[],
    customConfig?: StoreConfigType
  ): Promise<{ success: boolean; message: string }> => {
    setIsPublishing(true);
    try {
      const payloadProducts = customProducts || latestProductsRef.current;
      const payloadConfig = customConfig || latestConfigRef.current;

      const res = await fetch('/api/store', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          products: payloadProducts,
          storeConfig: payloadConfig,
          adminKey: payloadConfig.adminSecretKey || 'strongxt001002z',
        }),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || `Erro no servidor: ${res.statusText}`);
      }

      const data = await res.json();
      const newTimestamp = data.updatedAt || Date.now();
      setLastSyncTimestamp(newTimestamp);
      setIsOnlineSynced(true);
      return {
        success: true,
        message: 'Alterações publicadas e ativas para todos os visitantes do site com sucesso!',
      };
    } catch (err: any) {
      console.error('Falha ao publicar para todos os visitantes:', err);
      return {
        success: false,
        message: err.message || 'Falha ao sincronizar com o servidor',
      };
    } finally {
      setIsPublishing(false);
    }
  };

  // Helper to trigger auto-publish if enabled
  const triggerAutoPublish = (nextProducts: Product[], nextConfig: StoreConfigType) => {
    if (autoPublishToAll) {
      publishToAllUsers(nextProducts, nextConfig);
    }
  };

  // Manual fetch from server
  const refreshFromServer = async () => {
    try {
      const res = await fetch('/api/store');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.products) && data.products.length > 0) {
          setProducts(data.products);
          localStorage.setItem(STORAGE_PRODUCTS_KEY, JSON.stringify(data.products));
        }
        if (data.storeConfig) {
          setStoreConfig((prev) => ({ ...prev, ...data.storeConfig }));
          localStorage.setItem(STORAGE_CONFIG_KEY, JSON.stringify(data.storeConfig));
        }
        if (data.updatedAt) {
          setLastSyncTimestamp(data.updatedAt);
        }
        setIsOnlineSynced(true);
      }
    } catch (err) {
      console.warn('Erro ao atualizar dados do servidor:', err);
    }
  };

  // Initial fetch from server API + background version poller
  useEffect(() => {
    let isMounted = true;

    async function initialLoad() {
      try {
        const res = await fetch('/api/store');
        if (res.ok && isMounted) {
          const data = await res.json();
          if (Array.isArray(data.products) && data.products.length > 0) {
            setProducts(data.products);
            localStorage.setItem(STORAGE_PRODUCTS_KEY, JSON.stringify(data.products));
          }
          if (data.storeConfig) {
            setStoreConfig((prev) => ({ ...prev, ...data.storeConfig }));
            localStorage.setItem(STORAGE_CONFIG_KEY, JSON.stringify(data.storeConfig));
          }
          if (data.updatedAt) {
            setLastSyncTimestamp(data.updatedAt);
          }
          setIsOnlineSynced(true);
        }
      } catch (err) {
        console.warn('Usando dados locais de produtos e configuração:', err);
      }
    }

    initialLoad();

    // Check version every 6 seconds to update site in real-time for any client browsing
    const interval = setInterval(async () => {
      if (!isMounted) return;
      try {
        const res = await fetch('/api/store/version');
        if (res.ok) {
          const vData = await res.json();
          const currentTimestamp = lastSyncTimestampRef.current;
          if (vData.updatedAt && (!currentTimestamp || vData.updatedAt > currentTimestamp)) {
            // New version detected on server! Fetch and apply instantly
            const fullRes = await fetch('/api/store');
            if (fullRes.ok && isMounted) {
              const fullData = await fullRes.json();
              if (Array.isArray(fullData.products)) {
                setProducts(fullData.products);
                localStorage.setItem(STORAGE_PRODUCTS_KEY, JSON.stringify(fullData.products));
              }
              if (fullData.storeConfig) {
                setStoreConfig((prev) => ({ ...prev, ...fullData.storeConfig }));
                localStorage.setItem(STORAGE_CONFIG_KEY, JSON.stringify(fullData.storeConfig));
              }
              setLastSyncTimestamp(fullData.updatedAt);
              setIsOnlineSynced(true);
            }
          }
        }
      } catch {
        // Ignore network hiccups during background polling
      }
    }, 6000);

    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  const updateProduct = (productId: string, updatedFields: Partial<Product>) => {
    setProducts((prev) => {
      const next = prev.map((p) => {
        if (p.id === productId) {
          const updated = { ...p, ...updatedFields };
          // recalculate discount if price and originalPrice are provided
          if (updated.originalPrice && updated.originalPrice > updated.price) {
            updated.discountPercentage = Math.round(
              ((updated.originalPrice - updated.price) / updated.originalPrice) * 100
            );
          } else if (updated.originalPrice === undefined || updated.originalPrice <= updated.price) {
            updated.discountPercentage = undefined;
          }
          return updated;
        }
        return p;
      });
      triggerAutoPublish(next, storeConfig);
      return next;
    });
  };

  const addProduct = (newProduct: Product) => {
    setProducts((prev) => {
      const next = [newProduct, ...prev];
      triggerAutoPublish(next, storeConfig);
      return next;
    });
  };

  const deleteProduct = (productId: string) => {
    setProducts((prev) => {
      const next = prev.filter((p) => p.id !== productId);
      triggerAutoPublish(next, storeConfig);
      return next;
    });
  };

  const updateStoreConfig = (newConfig: Partial<StoreConfigType>) => {
    setStoreConfig((prev) => {
      const next: StoreConfigType = {
        ...prev,
        ...newConfig,
        whatsapp: {
          ...prev.whatsapp,
          ...(newConfig.whatsapp || {}),
        },
        pix: {
          ...prev.pix,
          ...(newConfig.pix || {}),
        },
      };
      triggerAutoPublish(products, next);
      return next;
    });
  };

  const resetToDefaults = () => {
    localStorage.removeItem(STORAGE_PRODUCTS_KEY);
    localStorage.removeItem(STORAGE_CONFIG_KEY);
    localStorage.removeItem(STORAGE_PASS_KEY);
    setProducts(INITIAL_PRODUCTS);
    const resetCfg: StoreConfigType = {
      name: INITIAL_CONFIG.name,
      tagline: INITIAL_CONFIG.tagline,
      subtitle: INITIAL_CONFIG.subtitle,
      city: INITIAL_CONFIG.city,
      state: INITIAL_CONFIG.state,
      locationDisplay: INITIAL_CONFIG.locationDisplay,
      whatsapp: { ...INITIAL_CONFIG.whatsapp },
      pix: { ...INITIAL_CONFIG.pix },
      adminSecretKey: INITIAL_CONFIG.adminSecretKey,
      aboutText: INITIAL_CONFIG.aboutText,
    };
    setStoreConfig(resetCfg);
    publishToAllUsers(INITIAL_PRODUCTS, resetCfg);
  };

  const verifyAdminPassword = (inputPassword: string): boolean => {
    const cleanInput = inputPassword.trim().toLowerCase();
    const cleanCurrent = (storeConfig.adminSecretKey || INITIAL_CONFIG.adminSecretKey).trim().toLowerCase();
    return cleanInput === cleanCurrent || cleanInput === 'strongxt001002z';
  };

  return (
    <StoreContext.Provider
      value={{
        products,
        storeConfig,
        updateProduct,
        addProduct,
        deleteProduct,
        updateStoreConfig,
        resetToDefaults,
        verifyAdminPassword,
        isAdminOpen,
        setIsAdminOpen,
        isOnlineSynced,
        isPublishing,
        lastSyncTimestamp,
        autoPublishToAll,
        setAutoPublishToAll,
        publishToAllUsers,
        refreshFromServer,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = (): StoreContextType => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
