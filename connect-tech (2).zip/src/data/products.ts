import { Product, CategoryInfo } from '../types';

export const CATEGORIES_DATA: CategoryInfo[] = [
  {
    id: 'carregadores',
    name: 'Carregadores & Power Banks',
    iconName: 'Zap',
    description: 'Carregadores Turbo Power Delivery e Power Banks Sem Fio',
    itemCount: 2,
    image: '/assets/basike_power_bank.jpg',
  },
  {
    id: 'celular',
    name: 'Acessórios para Celular',
    iconName: 'Smartphone',
    description: 'Acessórios compatíveis com iPhone, Samsung e outros',
    itemCount: 2,
    image: '/assets/iphone_charger_box.jpg',
  },
];

export const PRODUCTS_DATA: Product[] = [
  {
    id: 'power-bank-carregador-sem-fio-basike',
    name: 'Power Bank Carregador Sem Fio Basike – Carregamento por Indução',
    slug: 'power-bank-carregador-sem-fio-basike',
    category: 'carregadores',
    categoryName: 'Carregadores & Power Banks',
    price: 80.0,
    originalPrice: 120.0,
    discountPercentage: 33,
    shortDescription:
      'Power Bank e Carregador Sem Fio Basike com suporte, carregamento rápido por indução, proteção inteligente e design compacto. Promoção: de R$ 120 por R$ 80!',
    description:
      'Carregador Sem Fio Basike (Power Bank). Mais praticidade e tecnologia no seu dia a dia! Carregue sem fios com máxima velocidade e total segurança. Equipado com chip de proteção inteligente que previne superaquecimento e sobrecarga, design compacto leve e fácil de transportar, e ampla compatibilidade com qualquer smartphone habilitado para indução Qi (Apple iPhone, Samsung Galaxy, Xiaomi e outros). Aproveite a super promoção: de R$ 120,00 por apenas R$ 80,00 com pronta entrega exclusiva em Santana do Livramento - RS.',
    image: '/assets/basike_power_bank.jpg',
    gallery: [
      '/assets/basike_power_bank.jpg',
      '/assets/basike_power_bank_close.jpg',
    ],
    inStock: true,
    stockCount: 6,
    badge: '🔥 PROMOÇÃO: DE R$ 120 POR R$ 80',
    isFeatured: true,
    isOfferOfTheWeek: true,
    rating: 4.9,
    reviewCount: 38,
    colors: ['Preto Fosco com Dourado'],
    specs: [
      { label: 'Marca', value: 'Basike (Original)' },
      { label: 'Modelo', value: 'Power Bank / Carregador Sem Fio Stand' },
      { label: 'Preço Promocional', value: 'De R$ 120,00 por apenas R$ 80,00 (Economize R$ 40)' },
      { label: 'Tecnologia', value: 'Carregamento Sem Fio por Indução (Qi Fast Charging)' },
      { label: 'Proteção', value: 'Inteligente: evita superaquecimento, sobretensão e sobrecarga' },
      { label: 'Design', value: 'Compacto, leve, com ranhuras de apoio antiderrapantes' },
      { label: 'Compatibilidade', value: 'Compatível com diversos aparelhos com tecnologia Qi (iPhone, Samsung, Xiaomi)' },
      { label: 'Garantia', value: '12 meses Connect Tech' },
      { label: 'Disponibilidade', value: 'Pronta entrega exclusiva em Santana do Livramento - RS' },
    ],
    features: [
      'Carregue sem fios: basta apoiar o celular na base/suporte',
      'Carregamento rápido com distribuição inteligente de energia',
      'Proteção inteligente avançada contra sobrecarga e aquecimento',
      'Design compacto e ergonômico, ideal para mesa de trabalho, cabeceira ou viagens',
      'Compatível com a maioria dos dispositivos com carregamento sem fio',
      'Qualidade original Basike com garantia de 1 ano Connect Tech',
    ],
  },
  {
    id: 'carregador-iphone-turbo-20w',
    name: 'Carregador Turbo para iPhone 20W USB-C Power Delivery',
    slug: 'carregador-iphone-turbo-20w',
    category: 'carregadores',
    categoryName: 'Carregadores de iPhone',
    price: 45.0,
    shortDescription:
      'Carregador Turbo para iPhone com saída USB-C e chip inteligente. Compatível com 14 pra baixo. Apenas 4 unidades restantes em estoque!',
    description:
      'Carregador Turbo de alta velocidade para iPhone com tecnologia Power Delivery (PD) de 20W. Carrega de 0 a 50% em apenas 30 minutos com total segurança contra sobreaquecimento, sobretensão e curto-circuito. Homologado e compatível com 14 pra baixo (iPhone 14, 13, 12, 11, X, XR, XS, 8 e SE). Atenção: restam apenas 4 unidades disponíveis para pronta entrega!',
    image: '/assets/iphone_charger_box.jpg',
    gallery: [
      '/assets/iphone_charger_box.jpg',
      'https://images.unsplash.com/photo-1608156639585-b3a032ef9689?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1625842268584-8f3296236761?w=800&auto=format&fit=crop&q=80',
    ],
    inStock: true,
    stockCount: 4, // Exatamente 4 em estoque conforme solicitado
    badge: '⚡ APENAS 4 EM ESTOQUE',
    isFeatured: true,
    isOfferOfTheWeek: false,
    rating: 4.9,
    reviewCount: 48,
    colors: ['Branco Apple'],
    specs: [
      { label: 'Disponibilidade', value: '4 em estoque (últimas unidades)' },
      { label: 'Compatibilidade', value: 'Compatível com 14 pra baixo (iPhone 14, 13, 12, 11, X, 8)' },
      { label: 'Potência Real', value: '20W Power Delivery (PD 3.0)' },
      { label: 'Entrada', value: 'Bivolt Automático 100-240V' },
      { label: 'Saída', value: 'USB-C Ultra Rápida (5V/3A, 9V/2.22A)' },
      { label: 'Proteção', value: 'Contra sobretensão, superaquecimento e curto' },
      { label: 'Garantia', value: '12 meses Connect Tech' },
    ],
    features: [
      'Compatível com 14 pra baixo (iPhone 14, 13, 12, 11, X, XR, 8)',
      'Carregamento ultra veloz: 0% a 50% em 30 minutos',
      'Chip inteligente com controle térmico avançado',
      'Design compacto e resistente',
      'Garantia de 1 ano e pronta entrega imediata',
    ],
  },
];
