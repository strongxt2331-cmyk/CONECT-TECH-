import React from 'react';
import { ArrowRight, Sparkles, CheckCircle } from 'lucide-react';

interface PromoBannerProps {
  onCheckProducts: () => void;
}

export const PromoBanner: React.FC<PromoBannerProps> = ({ onCheckProducts }) => {
  return (
    <section id="promo-banner-section" className="py-12 bg-[#030712]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-[#071330] via-[#0b1d47] to-[#081228] border border-blue-500/40 shadow-2xl p-8 sm:p-12 lg:p-16">
          {/* Subtle electric blue ambient glows */}
          <div className="absolute top-0 right-1/4 w-80 h-80 bg-cyan-500/20 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute -bottom-10 left-10 w-96 h-96 bg-blue-600/20 rounded-full blur-[100px] pointer-events-none"></div>

          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-8 flex flex-col items-start">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs font-bold tracking-wider uppercase mb-4">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                CONECTE-SE COM A TECNOLOGIA
              </div>

              <h2 className="font-tech text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-tight mb-4">
                EXPERIMENTE A MÁXIMA VELOCIDADE E CONECTIVIDADE NO SEU DIA A DIA
              </h2>

              <p className="text-slate-300 text-base sm:text-lg max-w-2xl leading-relaxed mb-8">
                Os acessórios que você precisa para deixar sua rotina ainda mais prática. Cabos ultra resistentes, carregadores de alta potência, hubs inteligentes e muito mais.
              </p>

              <div className="flex flex-wrap items-center gap-4 sm:gap-6 mb-8 text-xs sm:text-sm text-slate-300">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-cyan-400" />
                  <span>Compatível com iOS & Android</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-cyan-400" />
                  <span>Garantia de 6 a 12 meses</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-cyan-400" />
                  <span>Envio expresso para todo o Brasil</span>
                </div>
              </div>

              <button
                id="btn-promo-banner-cta"
                onClick={onCheckProducts}
                className="inline-flex items-center gap-3 px-8 py-4 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-400 text-slate-950 font-black text-sm sm:text-base tracking-wide uppercase hover:from-blue-400 hover:to-cyan-300 transition-all shadow-xl shadow-cyan-500/20 active:scale-95 cursor-pointer"
              >
                <span>CONFERIR PRODUTOS</span>
                <ArrowRight className="w-5 h-5 text-slate-950 font-bold" />
              </button>
            </div>

            <div className="lg:col-span-4 hidden lg:flex justify-center">
              <div className="relative w-64 h-64 rounded-2xl overflow-hidden border border-blue-400/30 shadow-2xl group">
                <img
                  src="https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=600&auto=format&fit=crop&q=80"
                  alt="Hubs e Acessórios Connect Tech"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
                <div className="absolute bottom-3 left-3 right-3 text-center">
                  <span className="text-xs font-bold text-white uppercase tracking-widest bg-blue-900/80 px-2 py-1 rounded backdrop-blur-sm border border-blue-500/40">
                    Qualidade Premium
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
