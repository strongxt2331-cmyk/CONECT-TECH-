import React, { useState } from 'react';
import { X, User, Package, MapPin } from 'lucide-react';

interface AccountModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AccountModal: React.FC<AccountModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'orders' | 'addresses'>('profile');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="fixed inset-0" onClick={onClose} />
      <div className="relative w-full max-w-lg rounded-2xl bg-[#070D1F] border border-blue-500/40 shadow-2xl z-10 overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 bg-[#09132d] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-cyan-400">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-tech font-bold text-white text-base">Minha Conta Connect Tech</h3>
              <span className="text-xs text-slate-400">Gerencie seus pedidos e preferências</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white bg-slate-800 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-800 bg-[#050B1B] text-xs font-semibold text-slate-400">
          <button
            onClick={() => setActiveTab('profile')}
            className={`flex-1 py-3 border-b-2 text-center transition-colors cursor-pointer ${
              activeTab === 'profile'
                ? 'border-cyan-400 text-cyan-300 bg-blue-950/30'
                : 'border-transparent hover:text-white'
            }`}
          >
            Perfil
          </button>
          <button
            onClick={() => setActiveTab('orders')}
            className={`flex-1 py-3 border-b-2 text-center transition-colors cursor-pointer ${
              activeTab === 'orders'
                ? 'border-cyan-400 text-cyan-300 bg-blue-950/30'
                : 'border-transparent hover:text-white'
            }`}
          >
            Meus Pedidos
          </button>
          <button
            onClick={() => setActiveTab('addresses')}
            className={`flex-1 py-3 border-b-2 text-center transition-colors cursor-pointer ${
              activeTab === 'addresses'
                ? 'border-cyan-400 text-cyan-300 bg-blue-950/30'
                : 'border-transparent hover:text-white'
            }`}
          >
            Endereço
          </button>
        </div>

        {/* Content */}
        <div className="p-6 text-xs text-slate-300 space-y-4 max-h-96 overflow-y-auto">
          {activeTab === 'profile' && (
            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase block font-semibold">Cliente Visitante</span>
                <span className="text-white font-semibold text-sm">cliente@connecttech.com.br</span>
                <span className="text-[11px] text-emerald-400 block mt-1">Conta verificada nível Connect Pro</span>
              </div>
              <div className="p-4 rounded-xl bg-blue-950/30 border border-blue-900/50 space-y-2">
                <span className="font-bold text-white block">Benefícios da sua conta:</span>
                <p className="text-slate-400">
                  • Histórico detalhado de compras e faturamento.<br />
                  • Acesso antecipado aos lançamentos de carregadores GaN.<br />
                  • Suporte prioritário via WhatsApp cadastrado.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'orders' && (
            <div className="text-center py-6">
              <div className="w-12 h-12 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center mx-auto mb-3 text-slate-500">
                <Package className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-white mb-1">Nenhum pedido anterior em aberto</h4>
              <p className="text-slate-400 text-[11px] max-w-xs mx-auto">
                Seus pedidos futuros aparecerão aqui com código de rastreio em tempo real.
              </p>
            </div>
          )}

          {activeTab === 'addresses' && (
            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-start gap-3">
                <MapPin className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-white block">Endereço Padrão (Simulação)</span>
                  <span className="text-slate-400 block text-[11px]">Av. Paulista, 1000 - Bela Vista</span>
                  <span className="text-slate-400 block text-[11px]">São Paulo - SP, 01310-100</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#050B1B] border-t border-slate-800 flex items-center justify-between text-xs">
          <span className="text-slate-500">Connect Tech v2.6</span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 text-white font-semibold hover:bg-slate-700 cursor-pointer"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
