import React, { useState, useEffect } from 'react';
import {
  CheckCircle2,
  MessageCircle,
  Home,
  Copy,
  Check,
  QrCode,
  ExternalLink,
} from 'lucide-react';
import QRCode from 'qrcode';
import { Order } from '../types';
import { useStore } from '../context/StoreContext';
import { getWhatsAppUrl, STORE_CONFIG } from '../config';

interface OrderSuccessModalProps {
  order: Order;
  onContinueShopping: () => void;
}

export const OrderSuccessModal: React.FC<OrderSuccessModalProps> = ({
  order,
  onContinueShopping,
}) => {
  const { products, storeConfig } = useStore();
  const [copied, setCopied] = useState(false);
  const [copiedPix, setCopiedPix] = useState(false);

  // Find ordered product configuration
  const firstOrderedItem = order.items[0]?.product;
  const liveProduct = products.find((p) => p.id === firstOrderedItem?.id) || firstOrderedItem;

  const hasCustomPayment = Boolean(
    liveProduct?.customQrCodeImage ||
    liveProduct?.customPixCode ||
    liveProduct?.paymentLink ||
    (liveProduct?.customPaymentValue !== undefined && liveProduct.customPaymentValue > 0)
  );

  const activePixCode = liveProduct?.customPixCode || storeConfig.pix.code;
  const activeReceiver = storeConfig.pix.receiver;
  const activePaymentLink = liveProduct?.paymentLink;
  const customChargeValue = liveProduct?.customPaymentValue;

  const [qrCodeUrl, setQrCodeUrl] = useState<string>(
    liveProduct?.customQrCodeImage || storeConfig.pix.qrCodeImage
  );

  useEffect(() => {
    if (liveProduct?.customQrCodeImage) {
      setQrCodeUrl(liveProduct.customQrCodeImage);
      return;
    }

    const textToEncode = liveProduct?.customPixCode || liveProduct?.paymentLink || storeConfig.pix.code;
    QRCode.toDataURL(textToEncode, {
      width: 300,
      margin: 2,
      color: {
        dark: '#000000',
        light: '#ffffff',
      },
    })
      .then((url) => setQrCodeUrl(url))
      .catch(() => setQrCodeUrl(storeConfig.pix.qrCodeImage));
  }, [liveProduct, storeConfig]);

  const copyOrderCode = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(order.orderId);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const copyPixCode = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(activePixCode);
      setCopiedPix(true);
      setTimeout(() => setCopiedPix(false), 2500);
    }
  };

  const displayTotal = customChargeValue !== undefined && customChargeValue > 0 ? customChargeValue : order.total;
  const formattedTotal = displayTotal.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });

  const whatsappMessage =
    `*COMPROVANTE DE PAGAMENTO PIX - CONNECT TECH*\n` +
    `📦 *Pedido:* #${order.orderId}\n` +
    `👤 *Cliente:* ${order.customer.fullName}\n` +
    `💰 *Valor:* ${formattedTotal}\n` +
    `🏦 *Beneficiário:* ${activeReceiver}\n` +
    (activePaymentLink ? `🔗 *Link Usado:* ${activePaymentLink}\n` : '') +
    `\nOlá! Segue o comprovante de pagamento do meu pedido para conferência e despacho imediato em Santana do Livramento!`;

  return (
    <div className="py-12 bg-[#030712] min-h-screen">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-6 sm:p-10 rounded-3xl bg-[#060C1D] border border-blue-500/40 shadow-2xl text-center">
          {/* Animated Success Icon */}
          <div className="relative w-20 h-20 rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center mx-auto mb-6">
            <span className="absolute inset-0 rounded-full bg-emerald-400/20 animate-ping"></span>
            <CheckCircle2 className="w-10 h-10 text-emerald-400" />
          </div>

          <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest block mb-2">
            Pedido Realizado com Sucesso
          </span>
          <h1 className="font-tech text-3xl sm:text-4xl font-extrabold text-white mb-2">
            OBRIGADO PELA SUA COMPRA!
          </h1>
          <p className="text-slate-300 text-sm max-w-lg mx-auto mb-6">
            Recebemos seu pedido com sucesso. Agora envie o comprovante de pagamento para nosso WhatsApp para despacho imediato!
          </p>

          {/* Order Code Highlight */}
          <div className="inline-flex items-center gap-3 px-5 py-3 rounded-2xl bg-slate-900 border border-slate-700 mb-6">
            <div className="text-left">
              <span className="text-[10px] text-slate-400 block uppercase font-semibold">Código do Pedido</span>
              <span className="font-tech font-bold text-white text-base text-cyan-300">#{order.orderId}</span>
            </div>
            <button
              onClick={copyOrderCode}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Copiar código do pedido"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>

          {/* Direct Payment Link (if product has custom link configured) */}
          {activePaymentLink && (
            <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-blue-950/80 via-[#071b30] to-cyan-950/80 border-2 border-cyan-400/50 mb-6 text-left space-y-2.5 shadow-xl">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-cyan-300 flex items-center gap-1.5 uppercase tracking-wide">
                  <ExternalLink className="w-4 h-4 text-cyan-400" />
                  Link de Cobrança Direto Deste Produto
                </span>
                <span className="text-sm font-black text-emerald-400 font-tech">
                  {formattedTotal}
                </span>
              </div>
              <a
                href={activePaymentLink.startsWith('http') ? activePaymentLink : `https://${activePaymentLink}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-blue-600 via-cyan-600 to-emerald-600 hover:from-blue-500 hover:to-emerald-500 text-white font-tech font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-cyan-950/60 transition-all text-center cursor-pointer"
              >
                <ExternalLink className="w-4 h-4 shrink-0" />
                <span>Abrir Link de Pagamento (Mercado Pago / Banco)</span>
              </a>
            </div>
          )}

          {/* PIX Quick Box */}
          <div className="p-4 sm:p-5 rounded-2xl bg-[#081226] border border-emerald-500/40 mb-6 text-left space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5 uppercase tracking-wide">
                <QrCode className="w-4 h-4" />
                {hasCustomPayment ? 'QR Code do Produto' : 'Dados do PIX para Pagamento'}
              </span>
              <span className="text-xs font-bold text-cyan-300">
                {activeReceiver}
              </span>
            </div>

            {hasCustomPayment && liveProduct && (
              <div className="p-2 rounded-lg bg-cyan-950/40 border border-cyan-500/30 text-[11px] text-cyan-300 flex items-center justify-between">
                <span>Cobrança configurada para: <strong>{liveProduct.name}</strong></span>
                {liveProduct.paymentInstructions && (
                  <span className="italic text-slate-300 text-[10px]">{liveProduct.paymentInstructions}</span>
                )}
              </div>
            )}

            <div className="flex flex-col sm:flex-row items-center gap-4 pt-1">
              <div className="bg-white p-2 rounded-xl shrink-0">
                <img
                  src={qrCodeUrl}
                  alt={`QR Code - ${activeReceiver}`}
                  className="w-28 h-28 object-contain"
                />
              </div>

              <div className="flex-1 w-full space-y-2 text-xs">
                <div className="flex items-center justify-between text-slate-300">
                  <span>Valor a pagar:</span>
                  <span className="font-tech font-bold text-emerald-400 text-base">{formattedTotal}</span>
                </div>
                <div className="p-2 rounded-lg bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-400 truncate">
                  {activePixCode}
                </div>
                <button
                  type="button"
                  onClick={copyPixCode}
                  className={`w-full py-2 px-3 rounded-lg font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                    copiedPix ? 'bg-emerald-500 text-white' : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                  }`}
                >
                  {copiedPix ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedPix ? 'Chave PIX Copiada!' : 'Copiar Código Pix Copia e Cola'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Delivery & Summary Card */}
          <div className="p-5 rounded-2xl bg-[#08122B] border border-slate-800/80 text-left mb-8 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <span className="text-slate-400 font-semibold">Endereço de Entrega:</span>
              <span className="text-white font-medium text-right">
                {order.customer.street}, {order.customer.number} - {order.customer.city}/{order.customer.state}
              </span>
            </div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <span className="text-slate-400 font-semibold">Forma de Pagamento:</span>
              <span className="text-emerald-400 font-bold uppercase">
                PIX (Chave Oficial)
              </span>
            </div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <span className="text-slate-400 font-semibold">Previsão de Envio:</span>
              <span className="text-cyan-300 font-bold">Despacho em até 24 horas úteis</span>
            </div>
            <div className="flex items-center justify-between pt-1 text-sm font-bold">
              <span className="text-slate-300">Valor Total:</span>
              <span className="text-white font-tech text-base">{formattedTotal}</span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href={getWhatsAppUrl(whatsappMessage)}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-lg shadow-emerald-950/40"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Enviar Comprovante pelo WhatsApp</span>
            </a>
            <button
              onClick={onContinueShopping}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-slate-900 border border-slate-700 hover:border-cyan-400 text-slate-200 font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer"
            >
              <Home className="w-4 h-4" />
              <span>Voltar para a Página Inicial</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
