import React, { useState, useEffect } from 'react';
import {
  User,
  Phone,
  Mail,
  MapPin,
  Package,
  Calendar,
  CheckCircle2,
  Search,
  Trash2,
  ArrowLeft,
  Key,
  RefreshCw,
  MessageCircle,
} from 'lucide-react';
import { Order } from '../types';
import { STORE_CONFIG } from '../config';

interface BuyersDashboardProps {
  onBackToStore: () => void;
}

export const BuyersDashboard: React.FC<BuyersDashboardProps> = ({ onBackToStore }) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [searchFilter, setSearchFilter] = useState('');

  // Load orders from localStorage
  const loadOrders = () => {
    try {
      const stored = localStorage.getItem('connect_tech_orders');
      if (stored) {
        const parsed = JSON.parse(stored);
        setOrders(parsed);
      } else {
        // Provide sample seed order so the admin can immediately see the structure
        const sampleOrders: Order[] = [
          {
            orderId: 'CT-749201',
            createdAt: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
            customer: {
              fullName: 'Marcos Vinícius Silva',
              cpf: '342.981.402-88',
              phone: '559996244525',
              email: 'marcos.silva@gmail.com',
              cep: '65000-000',
              street: 'Rua das Palmeiras',
              number: '420',
              neighborhood: 'Centro',
              city: 'São Luís',
              state: 'MA',
            },
            items: [
              {
                product: {
                  id: 'carregador-iphone-turbo-20w',
                  name: 'Carregador Turbo para iPhone 20W USB-C Power Delivery',
                  slug: 'carregador-iphone-turbo-20w',
                  category: 'carregadores',
                  categoryName: 'Carregadores de iPhone',
                  price: 45.0,
                  shortDescription: 'Carregador Turbo para iPhone - Compatível com 14 pra baixo',
                  description: '',
                  image: '/assets/iphone_charger_box.jpg',
                  gallery: [],
                  inStock: true,
                  stockCount: 4,
                  rating: 4.9,
                  reviewCount: 48,
                  specs: [],
                  features: [],
                },
                quantity: 1,
                selectedColor: 'Branco Apple',
              },
            ],
            subtotal: 45.0,
            shipping: 0,
            discount: 0,
            total: 45.0,
            paymentMethod: 'pix',
            status: 'confirmed',
          },
        ];
        localStorage.setItem('connect_tech_orders', JSON.stringify(sampleOrders));
        setOrders(sampleOrders);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadOrders();
  }, []);

  const handleClearOrders = () => {
    if (window.confirm('Tem certeza que deseja limpar a lista de pedidos gravados no navegador?')) {
      localStorage.removeItem('connect_tech_orders');
      setOrders([]);
    }
  };

  const filteredOrders = orders.filter((order) => {
    const q = searchFilter.toLowerCase();
    const matchQuery =
      order.customer.fullName.toLowerCase().includes(q) ||
      order.customer.phone.includes(q) ||
      order.customer.email.toLowerCase().includes(q) ||
      order.orderId.toLowerCase().includes(q) ||
      order.customer.city.toLowerCase().includes(q);
    return matchQuery;
  });

  const getDirectBuyerWhatsApp = (phone: string, customerName: string, orderId: string) => {
    const clean = phone.replace(/\D/g, '');
    const num = clean.startsWith('55') ? clean : `55${clean}`;
    const text = encodeURIComponent(
      `Olá ${customerName}! Aqui é da Connect Tech referente ao seu pedido #${orderId}. Estamos aguardando o envio do seu comprovante de pagamento.`
    );
    return `https://wa.me/${num}?text=${text}`;
  };

  return (
    <div className="py-10 bg-[#02050E] min-h-screen text-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Header Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 mb-8 border-b border-blue-900/40">
          <div className="flex items-center gap-3">
            <button
              onClick={onBackToStore}
              className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-400 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Voltar para a loja"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-md bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 font-mono text-[11px] font-bold flex items-center gap-1">
                  <Key className="w-3 h-3" />
                  ACESSO AUTORIZADO (strongxt001002z)
                </span>
                <span className="text-xs text-slate-400">| Painel Exclusivo</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-tech tracking-tight mt-1">
                PAINEL DE VENDAS & COMPRADORES
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={loadOrders}
              className="px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Atualizar</span>
            </button>
            {orders.length > 0 && (
              <button
                onClick={handleClearOrders}
                className="px-4 py-2.5 rounded-xl bg-red-950/40 border border-red-800/40 hover:bg-red-900/40 text-red-300 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Limpar Histórico</span>
              </button>
            )}
          </div>
        </div>

        {/* Quick Stats Banner */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 mb-8">
          <div className="p-5 rounded-2xl bg-[#060C1D] border border-blue-500/30">
            <span className="text-xs text-slate-400 font-semibold block mb-1">Total de Compradores</span>
            <div className="flex items-baseline justify-between">
              <span className="text-3xl font-black text-white font-tech">{orders.length}</span>
              <span className="text-xs text-cyan-400 font-bold">Carregador iPhone 20W</span>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-[#060C1D] border border-emerald-500/30">
            <span className="text-xs text-slate-400 font-semibold block mb-1">Valor Total em Pedidos</span>
            <div className="flex items-baseline justify-between">
              <span className="text-3xl font-black text-emerald-400 font-tech">
                {orders.reduce((acc, o) => acc + o.total, 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
              </span>
              <span className="text-xs text-emerald-400/80 font-bold">100% PIX</span>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-[#060C1D] border border-purple-500/30">
            <span className="text-xs text-slate-400 font-semibold block mb-1">Número de Contato Oficial</span>
            <div className="flex items-baseline justify-between">
              <span className="text-xl font-bold text-white font-tech">{STORE_CONFIG.whatsapp.displayNumber}</span>
              <span className="text-xs text-purple-400 font-bold">WhatsApp Ativo</span>
            </div>
          </div>
        </div>

        {/* Search & Filter Bar */}
        <div className="p-4 rounded-2xl bg-[#060C1D] border border-slate-800 mb-6 flex flex-col sm:flex-row gap-4 justify-between items-center">
          <div className="relative w-full sm:w-96">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Buscar por nome, telefone, cidade ou ID..."
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
            />
          </div>
          <span className="text-xs text-slate-400 font-semibold">
            Mostrando <strong>{filteredOrders.length}</strong> de {orders.length} pedidos
          </span>
        </div>

        {/* Orders Table / Cards */}
        {filteredOrders.length === 0 ? (
          <div className="p-12 rounded-3xl bg-[#060C1D] border border-slate-800 text-center">
            <Package className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-white mb-1">Nenhum comprador encontrado</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              Quando alguém preencher o checkout e clicar para comprar o Carregador de iPhone, o pedido aparecerá instantaneamente nesta lista.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredOrders.map((order) => (
              <div
                key={order.orderId}
                className="p-6 rounded-2xl bg-[#060C1D] border border-slate-800 hover:border-blue-500/40 transition-all shadow-xl"
              >
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-800/80 mb-4">
                  <div className="flex items-center gap-3">
                    <span className="px-3 py-1 rounded-lg bg-blue-600/20 border border-blue-500/40 text-cyan-300 font-mono font-bold text-xs">
                      #{order.orderId}
                    </span>
                    <span className="text-xs text-slate-400 flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-slate-500" />
                      {new Date(order.createdAt).toLocaleString('pt-BR')}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-950/60 border border-emerald-500/40 text-emerald-400 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Pedido Registrado – Aguardando Comprovante
                    </span>
                    <span className="font-tech font-extrabold text-white text-lg">
                      {order.total.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
                  {/* Customer Info */}
                  <div className="space-y-2">
                    <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-wider block">
                      Dados do Comprador
                    </span>
                    <p className="text-white font-bold text-sm flex items-center gap-1.5">
                      <User className="w-4 h-4 text-cyan-400 shrink-0" />
                      {order.customer.fullName}
                    </p>
                    <p className="text-slate-300 flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{order.customer.phone}</span>
                    </p>
                    <p className="text-slate-300 flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{order.customer.email}</span>
                    </p>
                    <p className="text-slate-400">
                      CPF: <span className="text-slate-200 font-mono">{order.customer.cpf}</span>
                    </p>
                  </div>

                  {/* Delivery Address */}
                  <div className="space-y-2">
                    <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-wider block">
                      Endereço de Entrega
                    </span>
                    <p className="text-slate-200 flex items-start gap-1.5">
                      <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>
                        {order.customer.street}, {order.customer.number}
                        {order.customer.complement && ` (${order.customer.complement})`}
                      </span>
                    </p>
                    <p className="text-slate-400">
                      Bairro: <strong className="text-slate-300">{order.customer.neighborhood}</strong>
                    </p>
                    <p className="text-slate-400">
                      Cidade/UF: <strong className="text-slate-300">{order.customer.city} - {order.customer.state}</strong>
                    </p>
                    <p className="text-slate-400">
                      CEP: <strong className="text-slate-300">{order.customer.cep}</strong>
                    </p>
                  </div>

                  {/* Items & Direct WhatsApp Action */}
                  <div className="space-y-3 flex flex-col justify-between">
                    <div>
                      <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-wider block mb-1">
                        Item Comprado
                      </span>
                      {order.items.map((it, idx) => (
                        <div key={idx} className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                          <span className="font-semibold text-white block">{it.product.name}</span>
                          <span className="text-[11px] text-slate-400 block">
                            Qtd: <strong>{it.quantity}</strong> | Pagamento: <span className="uppercase text-emerald-400 font-bold">{order.paymentMethod}</span>
                          </span>
                        </div>
                      ))}
                    </div>

                    <a
                      href={getDirectBuyerWhatsApp(order.customer.phone, order.customer.fullName, order.orderId)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-emerald-600/20 border border-emerald-500/40 hover:bg-emerald-600/30 text-emerald-300 font-bold transition-all text-xs"
                    >
                      <MessageCircle className="w-4 h-4 text-emerald-400" />
                      <span>Falar com Comprador no WhatsApp</span>
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
