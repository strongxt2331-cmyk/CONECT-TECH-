import React, { useState, useEffect } from 'react';
import {
  X,
  Save,
  Upload,
  Image as ImageIcon,
  DollarSign,
  Package,
  CheckCircle2,
  Trash2,
  Plus,
  RotateCcw,
  Key,
  Phone,
  CreditCard,
  MapPin,
  Sparkles,
  Eye,
  AlertCircle,
  QrCode,
  ExternalLink,
  Link,
  Copy,
  Check,
  Globe,
  RefreshCw,
} from 'lucide-react';
import QRCode from 'qrcode';
import { useStore } from '../context/StoreContext';
import { Product } from '../types';

interface AdminSiteEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenBuyersReport?: () => void;
}

export const AdminSiteEditorModal: React.FC<AdminSiteEditorModalProps> = ({
  isOpen,
  onClose,
  onOpenBuyersReport,
}) => {
  const {
    products,
    storeConfig,
    updateProduct,
    addProduct,
    deleteProduct,
    updateStoreConfig,
    resetToDefaults,
    isOnlineSynced,
    isPublishing,
    lastSyncTimestamp,
    autoPublishToAll,
    setAutoPublishToAll,
    publishToAllUsers,
    refreshFromServer,
  } = useStore();

  const [activeTab, setActiveTab] = useState<'products' | 'new-product' | 'store' | 'reset'>('products');
  const [selectedProductId, setSelectedProductId] = useState<string>(products[0]?.id || '');
  const [saveSuccessMessage, setSaveSuccessMessage] = useState<string | null>(null);

  // Form states for currently selected product
  const currentProduct = products.find((p) => p.id === selectedProductId) || products[0];

  const [name, setName] = useState('');
  const [price, setPrice] = useState<number>(0);
  const [hasPromo, setHasPromo] = useState<boolean>(false);
  const [originalPrice, setOriginalPrice] = useState<number>(0);
  const [image, setImage] = useState('');
  const [galleryImage, setGalleryImage] = useState('');
  const [stockCount, setStockCount] = useState<number>(0);
  const [inStock, setInStock] = useState<boolean>(true);
  const [badge, setBadge] = useState('');
  const [shortDescription, setShortDescription] = useState('');
  const [description, setDescription] = useState('');

  // Custom QR Code & Payment Link state for selected product
  const [customQrCodeImage, setCustomQrCodeImage] = useState('');
  const [customPixCode, setCustomPixCode] = useState('');
  const [paymentLink, setPaymentLink] = useState('');
  const [customPaymentValue, setCustomPaymentValue] = useState<string>('');
  const [paymentInstructions, setPaymentInstructions] = useState('');
  const [isGeneratingQr, setIsGeneratingQr] = useState(false);
  const [copiedPixPreview, setCopiedPixPreview] = useState(false);

  // New product form states
  const [newProdName, setNewProdName] = useState('');
  const [newProdPrice, setNewProdPrice] = useState<number>(50);
  const [newProdOriginalPrice, setNewProdOriginalPrice] = useState<number>(0);
  const [newProdImage, setNewProdImage] = useState('');
  const [newProdStock, setNewProdStock] = useState<number>(5);
  const [newProdBadge, setNewProdBadge] = useState('');
  const [newProdDesc, setNewProdDesc] = useState('');
  // New product payment fields
  const [newProdPaymentLink, setNewProdPaymentLink] = useState('');
  const [newProdCustomPaymentValue, setNewProdCustomPaymentValue] = useState<string>('');
  const [newProdCustomPixCode, setNewProdCustomPixCode] = useState('');
  const [newProdCustomQrCode, setNewProdCustomQrCode] = useState('');
  const [newProdPaymentInstructions, setNewProdPaymentInstructions] = useState('');

  // Store Config form states
  const [cfgWhatsapp, setCfgWhatsapp] = useState(storeConfig.whatsapp.cleanNumber);
  const [cfgWhatsappDisplay, setCfgWhatsappDisplay] = useState(storeConfig.whatsapp.displayNumber);
  const [cfgPixReceiver, setCfgPixReceiver] = useState(storeConfig.pix.receiver);
  const [cfgPixCode, setCfgPixCode] = useState(storeConfig.pix.code);
  const [cfgCity, setCfgCity] = useState(storeConfig.locationDisplay);
  const [cfgAdminPassword, setCfgAdminPassword] = useState(storeConfig.adminSecretKey);

  // Sync selected product values to form
  useEffect(() => {
    if (currentProduct) {
      setName(currentProduct.name);
      setPrice(currentProduct.price);
      setHasPromo(!!currentProduct.originalPrice && currentProduct.originalPrice > currentProduct.price);
      setOriginalPrice(currentProduct.originalPrice || 0);
      setImage(currentProduct.image);
      setGalleryImage(currentProduct.gallery?.[1] || '');
      setStockCount(currentProduct.stockCount);
      setInStock(currentProduct.inStock);
      setBadge(currentProduct.badge || '');
      setShortDescription(currentProduct.shortDescription || '');
      setDescription(currentProduct.description || '');
      // Custom payment & QR code
      setCustomQrCodeImage(currentProduct.customQrCodeImage || '');
      setCustomPixCode(currentProduct.customPixCode || '');
      setPaymentLink(currentProduct.paymentLink || '');
      setCustomPaymentValue(
        currentProduct.customPaymentValue !== undefined ? String(currentProduct.customPaymentValue) : ''
      );
      setPaymentInstructions(currentProduct.paymentInstructions || '');
    }
  }, [currentProduct, selectedProductId]);

  // Sync config values
  useEffect(() => {
    setCfgWhatsapp(storeConfig.whatsapp.cleanNumber);
    setCfgWhatsappDisplay(storeConfig.whatsapp.displayNumber);
    setCfgPixReceiver(storeConfig.pix.receiver);
    setCfgPixCode(storeConfig.pix.code);
    setCfgCity(storeConfig.locationDisplay);
    setCfgAdminPassword(storeConfig.adminSecretKey);
  }, [storeConfig]);

  if (!isOpen) return null;

  const showNotification = (msg: string) => {
    setSaveSuccessMessage(msg);
    setTimeout(() => {
      setSaveSuccessMessage(null);
    }, 4000);
  };

  // Handle image upload via file reader for current product
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, isGallery = false) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check size limit (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert('A imagem é muito grande! Escolha uma foto de até 5MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      if (isGallery) {
        setGalleryImage(result);
      } else {
        setImage(result);
      }
      showNotification(isGallery ? 'Foto secundária carregada! Clique em Salvar.' : 'Nova foto principal carregada! Clique em Salvar.');
    };
    reader.readAsDataURL(file);
  };

  // Handle image upload for new product
  const handleNewProdFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      setNewProdImage(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Handle QR code image upload (screenshot from bank, file, etc.)
  const handleQrUpload = (e: React.ChangeEvent<HTMLInputElement>, isNew = false) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      alert('A imagem do QR Code é muito grande! Escolha uma imagem de até 5MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      if (isNew) {
        setNewProdCustomQrCode(result);
      } else {
        setCustomQrCodeImage(result);
        showNotification('✅ Imagem do QR Code do produto carregada com sucesso!');
      }
    };
    reader.readAsDataURL(file);
  };

  // Generate QR Code automatically from either PIX code or Payment Link
  const handleGenerateQr = async (isNew = false) => {
    const textToEncode = isNew
      ? newProdCustomPixCode.trim() || newProdPaymentLink.trim()
      : customPixCode.trim() || paymentLink.trim();

    if (!textToEncode) {
      alert('Por favor, informe primeiro o Link de Cobrança ou o Código PIX deste produto para gerar o QR Code correspondente.');
      return;
    }

    try {
      setIsGeneratingQr(true);
      const dataUrl = await QRCode.toDataURL(textToEncode, {
        width: 450,
        margin: 2,
        color: {
          dark: '#000000',
          light: '#ffffff',
        },
      });

      if (isNew) {
        setNewProdCustomQrCode(dataUrl);
      } else {
        setCustomQrCodeImage(dataUrl);
        showNotification('✅ QR Code exclusivo gerado a partir dos dados informados!');
      }
    } catch (err) {
      console.error('Erro gerando QR Code:', err);
      alert('Erro ao gerar QR Code a partir do código/link fornecido.');
    } finally {
      setIsGeneratingQr(false);
    }
  };

  // Save changes to current product
  const handleSaveProduct = async () => {
    if (!currentProduct) return;

    const effectiveOriginalPrice = hasPromo && originalPrice > price ? originalPrice : undefined;
    const parsedCustomValue = customPaymentValue.trim() !== '' ? Number(customPaymentValue) : undefined;

    const updatedData = {
      name,
      price: Number(price),
      originalPrice: effectiveOriginalPrice,
      image,
      gallery: galleryImage ? [image, galleryImage] : [image],
      stockCount: Number(stockCount),
      inStock,
      badge: badge.trim() || undefined,
      shortDescription,
      description,
      customQrCodeImage: customQrCodeImage.trim() || undefined,
      customPixCode: customPixCode.trim() || undefined,
      paymentLink: paymentLink.trim() || undefined,
      customPaymentValue: parsedCustomValue !== undefined && !isNaN(parsedCustomValue) ? parsedCustomValue : undefined,
      paymentInstructions: paymentInstructions.trim() || undefined,
    };

    updateProduct(currentProduct.id, updatedData);

    if (autoPublishToAll) {
      showNotification(`🌐 Salvando e atualizando o site para todos os visitantes...`);
      const nextProducts = products.map((p) => (p.id === currentProduct.id ? { ...p, ...updatedData } : p));
      const result = await publishToAllUsers(nextProducts, storeConfig);
      if (result.success) {
        showNotification(`✅ Produto "${name}" salvo e atualizado para TODO MUNDO no site em tempo real!`);
      } else {
        showNotification(`⚠️ Salvo localmente, mas houve erro ao publicar no servidor: ${result.message}`);
      }
    } else {
      showNotification(`✅ Produto "${name}" atualizado com sucesso no navegador!`);
    }
  };

  // Create new product
  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProdName.trim()) {
      alert('Por favor informe o nome do produto.');
      return;
    }

    const newId = `produto-${Date.now()}`;
    const parsedNewCustomValue = newProdCustomPaymentValue.trim() !== '' ? Number(newProdCustomPaymentValue) : undefined;

    const newProduct: Product = {
      id: newId,
      name: newProdName.trim(),
      slug: newId,
      category: 'carregadores',
      categoryName: 'Acessórios & Carregadores',
      price: Number(newProdPrice),
      originalPrice: newProdOriginalPrice > newProdPrice ? Number(newProdOriginalPrice) : undefined,
      shortDescription: newProdDesc || newProdName,
      description: newProdDesc || `${newProdName} disponível para pronta entrega exclusiva em Santana do Livramento - RS.`,
      image: newProdImage || '/assets/iphone_charger_box.jpg',
      gallery: [newProdImage || '/assets/iphone_charger_box.jpg'],
      inStock: true,
      stockCount: Number(newProdStock) || 5,
      badge: newProdBadge.trim() || undefined,
      isFeatured: true,
      rating: 5.0,
      reviewCount: 1,
      specs: [
        { label: 'Disponibilidade', value: `${newProdStock} em estoque` },
        { label: 'Garantia', value: '12 meses Connect Tech' },
      ],
      features: ['Pronta entrega em Santana do Livramento - RS', 'Garantia Connect Tech'],
      customQrCodeImage: newProdCustomQrCode.trim() || undefined,
      customPixCode: newProdCustomPixCode.trim() || undefined,
      paymentLink: newProdPaymentLink.trim() || undefined,
      customPaymentValue: parsedNewCustomValue !== undefined && !isNaN(parsedNewCustomValue) ? parsedNewCustomValue : undefined,
      paymentInstructions: newProdPaymentInstructions.trim() || undefined,
    };

    addProduct(newProduct);
    setSelectedProductId(newId);
    setActiveTab('products');
    setNewProdName('');
    setNewProdImage('');
    setNewProdBadge('');
    setNewProdDesc('');
    setNewProdPaymentLink('');
    setNewProdCustomPaymentValue('');
    setNewProdCustomPixCode('');
    setNewProdCustomQrCode('');
    setNewProdPaymentInstructions('');

    if (autoPublishToAll) {
      showNotification(`🌐 Adicionando e publicando produto para todos os visitantes...`);
      const nextProducts = [newProduct, ...products];
      const result = await publishToAllUsers(nextProducts, storeConfig);
      if (result.success) {
        showNotification(`✅ Novo produto "${newProduct.name}" criado e atualizado para TODO MUNDO no site!`);
      } else {
        showNotification(`✅ Produto criado localmente!`);
      }
    } else {
      showNotification(`✅ Novo produto "${newProduct.name}" adicionado com sucesso ao site!`);
    }
  };

  // Delete current product
  const handleDeleteCurrentProduct = async () => {
    if (!currentProduct) return;
    if (products.length <= 1) {
      alert('Você não pode excluir todos os produtos da loja! Deve haver pelo menos 1.');
      return;
    }
    if (confirm(`Tem certeza que deseja excluir o produto "${currentProduct.name}" do site?`)) {
      const remainingProducts = products.filter((p) => p.id !== currentProduct.id);
      deleteProduct(currentProduct.id);
      setSelectedProductId(remainingProducts[0].id);

      if (autoPublishToAll) {
        await publishToAllUsers(remainingProducts, storeConfig);
        showNotification(`🗑️ Produto removido e atualizado para todo mundo no site.`);
      } else {
        showNotification(`🗑️ Produto removido com sucesso.`);
      }
    }
  };

  // Save Store Configuration
  const handleSaveStoreConfig = async () => {
    const updatedConfig = {
      whatsapp: {
        ...storeConfig.whatsapp,
        cleanNumber: cfgWhatsapp.replace(/\D/g, ''),
        displayNumber: cfgWhatsappDisplay,
      },
      pix: {
        ...storeConfig.pix,
        receiver: cfgPixReceiver,
        code: cfgPixCode,
      },
      locationDisplay: cfgCity,
      adminSecretKey: cfgAdminPassword.trim() || 'strongxt001002z',
    };

    updateStoreConfig(updatedConfig);

    if (autoPublishToAll) {
      showNotification(`🌐 Salvando e publicando configurações para todos os visitantes...`);
      const mergedConfig = { ...storeConfig, ...updatedConfig };
      const result = await publishToAllUsers(products, mergedConfig);
      if (result.success) {
        showNotification('✅ Configurações da loja salvas e atualizadas para TODO MUNDO no site!');
      } else {
        showNotification('✅ Configurações salvas localmente.');
      }
    } else {
      showNotification('✅ Configurações da loja salvas com sucesso!');
    }
  };

  // Reset to original factory state
  const handleResetFactory = () => {
    if (confirm('Atenção: Isso irá restaurar todas as fotos, preços e produtos para os padrões originais de fábrica. Deseja continuar?')) {
      resetToDefaults();
      showNotification('🔄 O site foi restaurado para os padrões de fábrica!');
      setTimeout(() => {
        onClose();
      }, 1500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-150 overflow-y-auto">
      {/* Backdrop */}
      <div className="fixed inset-0" onClick={onClose} />

      {/* Main Modal Container */}
      <div className="relative w-full max-w-4xl rounded-3xl bg-[#070D1F] border border-cyan-500/40 shadow-2xl shadow-cyan-950/80 overflow-hidden z-10 flex flex-col max-h-[92vh] my-auto">
        {/* Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-[#081530] via-[#0b1b3d] to-[#081530] border-b border-cyan-500/30 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-400/50 flex items-center justify-center text-cyan-400 shrink-0 shadow-lg shadow-cyan-950/50">
              <Sparkles className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 text-[10px] font-black uppercase tracking-wider border border-emerald-500/40">
                  Acesso com Senha Liberado
                </span>
                <span className="text-xs text-slate-400">Modo Administrador</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white font-tech tracking-tight">
                PAINEL DE EDIÇÃO DO SITE
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {onOpenBuyersReport && (
              <button
                onClick={() => {
                  onClose();
                  onOpenBuyersReport();
                }}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 text-xs font-bold transition-all cursor-pointer"
                title="Ver lista de compradores e pedidos"
              >
                <Eye className="w-4 h-4" />
                <span>Ver Pedidos</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors cursor-pointer"
              title="Fechar painel"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Success Toast Banner */}
        {saveSuccessMessage && (
          <div className="bg-emerald-950/90 border-b border-emerald-500/60 px-5 py-3 flex items-center gap-3 text-emerald-200 text-sm font-bold animate-in slide-in-from-top duration-150">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>{saveSuccessMessage}</span>
          </div>
        )}

        {/* Global Live Publishing Status & Control Bar */}
        <div className="bg-gradient-to-r from-[#041226] via-[#071936] to-[#041226] border-b border-cyan-500/40 px-4 sm:px-6 py-3 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs shrink-0">
          <div className="flex items-center gap-3">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 shadow-md ${
              autoPublishToAll
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/50 shadow-emerald-950/50'
                : 'bg-slate-800 text-slate-400 border border-slate-700'
            }`}>
              <Globe className={`w-5 h-5 ${isPublishing ? 'animate-spin' : ''}`} />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-extrabold text-white text-xs sm:text-sm tracking-tight">
                  Atualizar Site para Todo Mundo
                </span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 ${
                  autoPublishToAll
                    ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/50'
                    : 'bg-slate-900 text-slate-400 border border-slate-700'
                }`}>
                  <span className={`w-2 h-2 rounded-full ${autoPublishToAll ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'}`} />
                  {autoPublishToAll ? 'Ativado para Todos' : 'Pausado'}
                </span>
                {lastSyncTimestamp && (
                  <span className="hidden lg:inline-block text-[10px] text-slate-400">
                    • Última sincronização: {new Date(lastSyncTimestamp).toLocaleTimeString('pt-BR')}
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-300 mt-0.5 leading-snug">
                {autoPublishToAll
                  ? 'Ao clicar em salvar alterações, as novidades vão direto para todos os clientes em tempo real.'
                  : 'Modo rascunho ativado: as alterações ficam apenas salvas neste navegador.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0 self-end md:self-auto">
            {/* Toggle switch */}
            <label className="flex items-center gap-2 cursor-pointer bg-slate-900/90 px-3 py-2 rounded-xl border border-slate-700 hover:border-cyan-500/50 transition-colors select-none">
              <input
                type="checkbox"
                checked={autoPublishToAll}
                onChange={(e) => {
                  setAutoPublishToAll(e.target.checked);
                  showNotification(
                    e.target.checked
                      ? '🌐 Publicação automática ativada: salvar alterações agora atualiza o site para todo mundo!'
                      : '⏸️ Publicação automática pausada.'
                  );
                }}
                className="w-4 h-4 accent-cyan-500 cursor-pointer"
              />
              <span className="text-[11px] text-slate-200 font-bold whitespace-nowrap">
                Atualizar ao Salvar
              </span>
            </label>

            {/* Force Sync / Publish Button */}
            <button
              type="button"
              disabled={isPublishing}
              onClick={async () => {
                showNotification('🌐 Publicando catálogo e configurações no servidor...');
                const res = await publishToAllUsers();
                if (res.success) {
                  showNotification('✅ SITE ATUALIZADO PARA TODOS OS VISITANTES COM SUCESSO!');
                } else {
                  showNotification(`❌ Erro ao publicar: ${res.message}`);
                }
              }}
              className={`px-3.5 py-2 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition-all shadow-md cursor-pointer ${
                isPublishing
                  ? 'bg-slate-800 text-slate-400 cursor-wait'
                  : 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-black shadow-cyan-950/50 hover:scale-[1.02]'
              }`}
              title="Publicar imediatamente para todos os visitantes do site"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isPublishing ? 'animate-spin' : ''}`} />
              <span className="whitespace-nowrap">{isPublishing ? 'Publicando...' : 'Publicar para Todos Agora'}</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 px-5 py-3 bg-[#050A17] border-b border-slate-800/80 overflow-x-auto text-xs shrink-0 scrollbar-none">
          <button
            onClick={() => setActiveTab('products')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'products'
                ? 'bg-cyan-500 text-black shadow-lg shadow-cyan-500/20'
                : 'bg-slate-900 text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>Editar Produtos, Fotos e Preços</span>
          </button>

          <button
            onClick={() => setActiveTab('new-product')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'new-product'
                ? 'bg-cyan-500 text-black shadow-lg shadow-cyan-500/20'
                : 'bg-slate-900 text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>+ Adicionar Produto</span>
          </button>

          <button
            onClick={() => setActiveTab('store')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'store'
                ? 'bg-cyan-500 text-black shadow-lg shadow-cyan-500/20'
                : 'bg-slate-900 text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <Key className="w-4 h-4" />
            <span>Configurações & Senha</span>
          </button>

          <button
            onClick={() => setActiveTab('reset')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold transition-all whitespace-nowrap ml-auto cursor-pointer ${
              activeTab === 'reset'
                ? 'bg-rose-500 text-white'
                : 'bg-slate-900 text-rose-300 hover:bg-rose-950/40'
            }`}
          >
            <RotateCcw className="w-4 h-4" />
            <span>Restaurar Fábrica</span>
          </button>
        </div>

        {/* Modal Body Content */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-6">
          {/* TAB 1: EDIT PRODUCTS */}
          {activeTab === 'products' && currentProduct && (
            <div className="space-y-6">
              {/* Product Selector Row */}
              <div className="p-4 rounded-2xl bg-[#091228] border border-blue-500/30 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider whitespace-nowrap">
                    Selecione o Produto:
                  </span>
                  <select
                    value={selectedProductId}
                    onChange={(e) => setSelectedProductId(e.target.value)}
                    className="flex-1 bg-slate-900 border border-slate-700 text-white font-tech font-bold text-sm rounded-xl px-4 py-2.5 focus:outline-none focus:border-cyan-400 cursor-pointer"
                  >
                    {products.map((p) => (
                      <option key={p.id} value={p.id} className="bg-slate-900 text-white">
                        {p.name} ({p.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })})
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  type="button"
                  onClick={handleDeleteCurrentProduct}
                  className="px-3.5 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer shrink-0"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Excluir Produto</span>
                </button>
              </div>

              {/* Main 2-Column Form: Photo & Pricing */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Left Column: Photo Uploader & Preview */}
                <div className="lg:col-span-5 space-y-4">
                  <div className="p-4 rounded-2xl bg-[#091228] border border-slate-800 space-y-4">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                        <ImageIcon className="w-4 h-4 text-cyan-400" />
                        Foto Principal do Produto
                      </label>
                      <span className="text-[10px] text-cyan-400 font-semibold">Atualiza no site</span>
                    </div>

                    {/* Image Preview Box */}
                    <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-slate-950 border-2 border-dashed border-cyan-500/40 flex items-center justify-center group shadow-inner">
                      {image ? (
                        <img
                          src={image}
                          alt="Prévia do produto"
                          className="w-full h-full object-contain p-2"
                        />
                      ) : (
                        <div className="text-center p-4 text-slate-500">
                          <ImageIcon className="w-12 h-12 mx-auto mb-2 opacity-50" />
                          <span className="text-xs">Nenhuma foto selecionada</span>
                        </div>
                      )}
                    </div>

                    {/* Upload Actions */}
                    <div className="space-y-3">
                      <label className="w-full flex items-center justify-center gap-2.5 px-4 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-tech font-bold text-xs uppercase tracking-wider cursor-pointer shadow-lg shadow-cyan-950/50 transition-all hover:scale-[1.01]">
                        <Upload className="w-4 h-4" />
                        <span>Carregar Foto do Celular / PC</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleFileUpload(e, false)}
                          className="hidden"
                        />
                      </label>

                      <div>
                        <span className="text-[11px] text-slate-400 block mb-1">Ou cole uma URL da imagem:</span>
                        <input
                          type="text"
                          value={image}
                          onChange={(e) => setImage(e.target.value)}
                          placeholder="https://exemplo.com/foto.jpg ou /assets/..."
                          className="w-full px-3 py-2 text-xs rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Secondary / Gallery Photo */}
                  <div className="p-4 rounded-2xl bg-[#091228] border border-slate-800 space-y-3">
                    <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                      <ImageIcon className="w-4 h-4 text-slate-400" />
                      Foto Secundária (Galeria)
                    </label>

                    <div className="flex items-center gap-3">
                      <div className="w-16 h-16 rounded-xl overflow-hidden bg-slate-950 border border-slate-700 shrink-0 flex items-center justify-center">
                        {galleryImage ? (
                          <img src={galleryImage} alt="Foto secundária" className="w-full h-full object-cover" />
                        ) : (
                          <span className="text-[9px] text-slate-600 text-center">Vazio</span>
                        )}
                      </div>

                      <div className="flex-1 space-y-2">
                        <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold cursor-pointer border border-slate-700">
                          <Upload className="w-3.5 h-3.5 text-cyan-400" />
                          <span>Mudar Foto Galeria</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleFileUpload(e, true)}
                            className="hidden"
                          />
                        </label>
                        <input
                          type="text"
                          value={galleryImage}
                          onChange={(e) => setGalleryImage(e.target.value)}
                          placeholder="URL da foto secundária..."
                          className="w-full px-2.5 py-1 text-[11px] rounded-lg bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Right Column: Pricing, Name, Stock, Text Details */}
                <div className="lg:col-span-7 space-y-5">
                  {/* Name Input */}
                  <div>
                    <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-1.5">
                      Nome / Título do Produto
                    </label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Ex: Power Bank Carregador Sem Fio Basike"
                      className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white font-tech font-bold text-sm sm:text-base focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  {/* PRICING BLOCK */}
                  <div className="p-4 rounded-2xl bg-[#091228] border border-blue-500/30 space-y-4">
                    <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                      <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                        <DollarSign className="w-4 h-4 text-emerald-400" />
                        Preços & Promoção
                      </span>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={hasPromo}
                          onChange={(e) => setHasPromo(e.target.checked)}
                          className="w-4 h-4 accent-emerald-400 rounded cursor-pointer"
                        />
                        <span className="text-xs font-bold text-rose-300">Ativar Promoção (De / Por)</span>
                      </label>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Current Sale Price */}
                      <div>
                        <label className="text-xs text-slate-400 block mb-1">
                          Preço de Venda Atual (R$)
                        </label>
                        <div className="relative">
                          <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-sm">
                            R$
                          </span>
                          <input
                            type="number"
                            step="0.01"
                            value={price}
                            onChange={(e) => setPrice(Number(e.target.value))}
                            className="w-full pl-11 pr-4 py-2.5 rounded-xl bg-slate-900 border border-emerald-500/50 text-emerald-400 font-tech font-black text-lg focus:outline-none focus:border-emerald-400"
                          />
                        </div>
                        <span className="text-[10px] text-slate-500 block mt-1">Valor cobrado no PIX</span>
                      </div>

                      {/* Original / Promo Price */}
                      {hasPromo && (
                        <div className="animate-in fade-in">
                          <label className="text-xs text-slate-400 block mb-1">
                            Preço Original Riscado (R$)
                          </label>
                          <div className="relative">
                            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-sm">
                              R$
                            </span>
                            <input
                              type="number"
                              step="0.01"
                              value={originalPrice}
                              onChange={(e) => setOriginalPrice(Number(e.target.value))}
                              placeholder="120.00"
                              className="w-full pl-11 pr-4 py-2.5 rounded-xl bg-slate-900 border border-rose-500/50 text-slate-300 font-tech font-bold text-base focus:outline-none focus:border-rose-400"
                            />
                          </div>
                          {originalPrice > price && (
                            <span className="text-[10px] text-emerald-400 font-bold block mt-1">
                              Economia de {(originalPrice - price).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })} (-{Math.round(((originalPrice - price) / originalPrice) * 100)}% OFF)
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* DEDICATED QR CODE & PAYMENT LINK WITH CUSTOM VALUE BLOCK */}
                  <div className="p-5 rounded-2xl bg-gradient-to-br from-[#0c1836] via-[#09152e] to-[#07191d] border-2 border-cyan-500/50 shadow-xl space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-cyan-900/60">
                      <div className="flex items-center gap-2.5">
                        <div className="p-2.5 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 shrink-0">
                          <QrCode className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="font-tech font-bold text-white text-sm sm:text-base flex items-center gap-2">
                            <span>QR Code & Link de Cobrança Individual</span>
                            <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 text-[10px] font-black uppercase tracking-wider border border-cyan-500/30">
                              Por Produto
                            </span>
                          </h4>
                          <p className="text-xs text-slate-300 mt-0.5">
                            Adicione um QR Code próprio, link de cobrança (Mercado Pago, InfinitePay, Nubank, etc.) com valor exclusivo para este produto.
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Link de Cobrança & Valor Diferente */}
                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-4">
                      {/* Link de Cobrança */}
                      <div className="sm:col-span-8">
                        <label className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5 mb-1.5">
                          <Link className="w-3.5 h-3.5 text-cyan-400" />
                          <span>Link de Cobrança / Pagamento Direto (URL)</span>
                        </label>
                        <div className="relative flex items-center">
                          <input
                            type="url"
                            value={paymentLink}
                            onChange={(e) => setPaymentLink(e.target.value)}
                            placeholder="https://link.mercadopago.com.br/... ou https://nubank.com.br/cobrar/..."
                            className="w-full pl-3 pr-24 py-2.5 rounded-xl bg-slate-900 border border-cyan-500/40 text-white font-mono text-xs focus:outline-none focus:border-cyan-400"
                          />
                          {paymentLink.trim() && (
                            <a
                              href={paymentLink.trim().startsWith('http') ? paymentLink.trim() : `https://${paymentLink.trim()}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="absolute right-2 px-2.5 py-1 rounded-lg bg-cyan-600/30 hover:bg-cyan-600/50 text-cyan-300 text-[11px] font-bold flex items-center gap-1 border border-cyan-500/30"
                            >
                              <ExternalLink className="w-3 h-3" />
                              <span>Testar</span>
                            </a>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-400 block mt-1">
                          Ex: Link do Mercado Pago, PagBank, InfinitePay, Nubank, PicPay, etc.
                        </span>
                      </div>

                      {/* Valor Diferente de Cobrança */}
                      <div className="sm:col-span-4">
                        <label className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5 mb-1.5">
                          <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Valor da Cobrança (R$)</span>
                        </label>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-xs">
                            R$
                          </span>
                          <input
                            type="number"
                            step="0.01"
                            value={customPaymentValue}
                            onChange={(e) => setCustomPaymentValue(e.target.value)}
                            placeholder={String(price)}
                            className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-emerald-500/50 text-emerald-400 font-tech font-black text-sm focus:outline-none focus:border-emerald-400"
                          />
                        </div>
                        <div className="flex items-center justify-between mt-1">
                          <button
                            type="button"
                            onClick={() => setCustomPaymentValue(String(price))}
                            className="text-[10px] text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
                          >
                            Usar Preço (R$ {price})
                          </button>
                          {customPaymentValue && (
                            <button
                              type="button"
                              onClick={() => setCustomPaymentValue('')}
                              className="text-[10px] text-slate-500 hover:text-rose-400 cursor-pointer"
                            >
                              Limpar
                            </button>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Código PIX Copia e Cola Específico */}
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <label className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                          <Copy className="w-3.5 h-3.5 text-cyan-400" />
                          <span>Código PIX Copia e Cola Deste Produto</span>
                        </label>
                        {customPixCode.trim() && (
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(customPixCode.trim());
                              setCopiedPixPreview(true);
                              setTimeout(() => setCopiedPixPreview(false), 2000);
                            }}
                            className="text-[10px] text-emerald-400 hover:text-emerald-300 flex items-center gap-1 cursor-pointer"
                          >
                            {copiedPixPreview ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                            <span>{copiedPixPreview ? 'Copiado!' : 'Copiar Código'}</span>
                          </button>
                        )}
                      </div>
                      <textarea
                        rows={2}
                        value={customPixCode}
                        onChange={(e) => setCustomPixCode(e.target.value)}
                        placeholder="Cole aqui o payload PIX Copia e Cola gerado pelo seu banco para este produto..."
                        className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-mono focus:outline-none focus:border-cyan-400"
                      />
                      <span className="text-[10px] text-slate-400 block mt-1">
                        Se preenchido, os clientes copiarão este PIX específico ao comprar este item.
                      </span>
                    </div>

                    {/* Upload / Preview do QR Code Específico */}
                    <div className="p-4 rounded-xl bg-slate-950/90 border border-slate-800 space-y-3">
                      <div className="flex items-center justify-between">
                        <label className="text-xs font-bold text-slate-200 uppercase tracking-wider block">
                          Imagem do QR Code Deste Produto
                        </label>
                        <span className="text-[10px] text-cyan-400 font-semibold">
                          {customQrCodeImage ? 'QR Code Exclusivo Ativo' : 'Usando QR Code Padrão da Loja'}
                        </span>
                      </div>

                      <div className="flex flex-col sm:flex-row items-center gap-4">
                        {/* QR Code Preview Box */}
                        <div className="w-36 h-36 bg-white p-2 rounded-xl shrink-0 flex items-center justify-center border-2 border-slate-700 shadow-inner relative group">
                          {customQrCodeImage ? (
                            <img
                              src={customQrCodeImage}
                              alt="QR Code deste produto"
                              className="w-full h-full object-contain"
                            />
                          ) : (
                            <div className="text-center text-slate-500 p-2">
                              <QrCode className="w-12 h-12 mx-auto text-slate-300 mb-1" />
                              <span className="text-[10px] text-slate-600 block leading-tight">
                                Usando QR Code padrão da loja
                              </span>
                            </div>
                          )}
                        </div>

                        {/* Action buttons for QR */}
                        <div className="flex-1 w-full space-y-2">
                          <label className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold border border-slate-700 cursor-pointer transition-colors">
                            <Upload className="w-4 h-4 text-cyan-400" />
                            <span>Carregar Foto / Print do QR Code</span>
                            <input
                              type="file"
                              accept="image/*"
                              onChange={(e) => handleQrUpload(e, false)}
                              className="hidden"
                            />
                          </label>

                          <button
                            type="button"
                            onClick={() => handleGenerateQr(false)}
                            disabled={isGeneratingQr || (!customPixCode.trim() && !paymentLink.trim())}
                            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 disabled:cursor-not-allowed text-white text-xs font-bold transition-colors cursor-pointer"
                          >
                            <QrCode className="w-4 h-4" />
                            <span>
                              {isGeneratingQr
                                ? 'Gerando QR Code...'
                                : 'Gerar QR Code a partir do Link ou PIX'}
                            </span>
                          </button>

                          {customQrCodeImage && (
                            <button
                              type="button"
                              onClick={() => {
                                setCustomQrCodeImage('');
                                showNotification('QR Code exclusivo removido. A loja usará o padrão.');
                              }}
                              className="w-full flex items-center justify-center gap-1.5 py-1.5 text-xs text-rose-400 hover:text-rose-300 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Remover QR Code Exclusivo</span>
                            </button>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Observações da Cobrança */}
                    <div>
                      <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-1">
                        Instruções ou Observação da Cobrança (Opcional)
                      </label>
                      <input
                        type="text"
                        value={paymentInstructions}
                        onChange={(e) => setPaymentInstructions(e.target.value)}
                        placeholder="Ex: Pague pelo Mercado Pago / InfinitePay em até 12x ou PIX direto"
                        className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
                      />
                    </div>
                  </div>

                  {/* Stock & Availability */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-1.5">
                        Quantidade em Estoque
                      </label>
                      <input
                        type="number"
                        min="0"
                        value={stockCount}
                        onChange={(e) => setStockCount(Number(e.target.value))}
                        className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-tech font-bold text-base focus:outline-none focus:border-cyan-400"
                      />
                      <span className="text-[10px] text-slate-500 block mt-1">Exibido na loja ("X em estoque")</span>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-1.5">
                        Selo / Badge Destaque
                      </label>
                      <input
                        type="text"
                        value={badge}
                        onChange={(e) => setBadge(e.target.value)}
                        placeholder="Ex: 🔥 PROMOÇÃO: DE R$ 120 POR R$ 80"
                        className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
                      />
                    </div>
                  </div>

                  {/* Descriptions */}
                  <div>
                    <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-1.5">
                      Descrição Resumida (Chamada rápida)
                    </label>
                    <textarea
                      rows={2}
                      value={shortDescription}
                      onChange={(e) => setShortDescription(e.target.value)}
                      placeholder="Breve resumo com destaque e promoção..."
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs leading-relaxed focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-1.5">
                      Descrição Completa do Produto
                    </label>
                    <textarea
                      rows={4}
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      placeholder="Detalhes completos sobre tecnologia, indução, garantia..."
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs leading-relaxed focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  {/* SAVE BUTTON */}
                  <div className="pt-2">
                    <button
                      type="button"
                      disabled={isPublishing}
                      onClick={handleSaveProduct}
                      className="w-full flex items-center justify-center gap-3 py-4 rounded-xl bg-gradient-to-r from-emerald-600 via-blue-600 to-cyan-500 hover:from-emerald-500 hover:to-cyan-400 text-white font-tech font-extrabold text-sm sm:text-base uppercase tracking-wider shadow-xl shadow-emerald-950/60 transition-all hover:scale-[1.01] active:scale-[0.99] cursor-pointer disabled:opacity-60"
                    >
                      <Save className={`w-5 h-5 ${isPublishing ? 'animate-spin' : ''}`} />
                      <span>
                        {autoPublishToAll
                          ? 'Salvar e Atualizar Site para Todo Mundo Agora'
                          : 'Salvar Alterações do Produto (Local)'}
                      </span>
                    </button>
                    <p className="text-center text-[11px] text-slate-400 mt-2 flex items-center justify-center gap-1.5">
                      <Globe className="w-3.5 h-3.5 text-cyan-400" />
                      {autoPublishToAll
                        ? '🟢 Sincronização global ativa: ao salvar, todos os visitantes verão as alterações imediatamente.'
                        : 'Modo local: ative "Atualizar ao Salvar" no topo para enviar para todos os clientes.'}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: ADD NEW PRODUCT */}
          {activeTab === 'new-product' && (
            <form onSubmit={handleCreateProduct} className="max-w-2xl mx-auto space-y-5">
              <div className="p-4 rounded-2xl bg-cyan-950/40 border border-cyan-500/40 text-cyan-200 text-xs flex items-center gap-3">
                <Plus className="w-5 h-5 text-cyan-400 shrink-0" />
                <span>Preencha os dados abaixo para cadastrar um novo acessório ou produto no catálogo.</span>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-1.5">
                  Nome do Novo Produto *
                </label>
                <input
                  type="text"
                  required
                  value={newProdName}
                  onChange={(e) => setNewProdName(e.target.value)}
                  placeholder="Ex: Fone Bluetooth TWS Turbo"
                  className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white font-tech font-bold text-sm focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-1.5">
                    Preço de Venda (R$) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={newProdPrice}
                    onChange={(e) => setNewProdPrice(Number(e.target.value))}
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-emerald-400 font-tech font-bold text-base focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-1.5">
                    Preço Original Riscado (Opcional R$)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={newProdOriginalPrice || ''}
                    onChange={(e) => setNewProdOriginalPrice(Number(e.target.value))}
                    placeholder="Ex: 90.00"
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 font-tech font-bold text-base focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-1.5">
                    Estoque Inicial (Unidades)
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={newProdStock}
                    onChange={(e) => setNewProdStock(Number(e.target.value))}
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-tech font-bold text-base focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-1.5">
                    Selo / Destaque (Opcional)
                  </label>
                  <input
                    type="text"
                    value={newProdBadge}
                    onChange={(e) => setNewProdBadge(e.target.value)}
                    placeholder="Ex: NOVIDADE"
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              {/* Photo Upload for new product */}
              <div className="p-4 rounded-2xl bg-[#091228] border border-slate-800 space-y-3">
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                  Foto do Produto
                </label>
                <div className="flex items-center gap-4">
                  {newProdImage && (
                    <div className="w-16 h-16 rounded-xl overflow-hidden bg-slate-950 border border-slate-700 shrink-0">
                      <img src={newProdImage} alt="Prévia" className="w-full h-full object-cover" />
                    </div>
                  )}
                  <label className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold cursor-pointer border border-slate-700 flex items-center gap-2">
                    <Upload className="w-4 h-4 text-cyan-400" />
                    <span>Escolher Foto do Arquivo</span>
                    <input type="file" accept="image/*" onChange={handleNewProdFileUpload} className="hidden" />
                  </label>
                </div>
                <input
                  type="text"
                  value={newProdImage}
                  onChange={(e) => setNewProdImage(e.target.value)}
                  placeholder="Ou cole a URL da foto..."
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 font-mono"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-1.5">
                  Descrição do Produto
                </label>
                <textarea
                  rows={3}
                  value={newProdDesc}
                  onChange={(e) => setNewProdDesc(e.target.value)}
                  placeholder="Detalhes sobre funcionamento, compatibilidade..."
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
                />
              </div>

              {/* DEDICATED QR CODE & PAYMENT LINK FOR NEW PRODUCT */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-[#0c1836] via-[#09152e] to-[#07191d] border border-cyan-500/40 space-y-4">
                <div className="flex items-center gap-2.5 pb-2 border-b border-cyan-900/50">
                  <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 shrink-0">
                    <QrCode className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-tech font-bold text-white text-sm">
                      QR Code & Link de Cobrança Deste Produto (Opcional)
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      Você pode deixar em branco para usar o PIX padrão da loja ou configurar cobrança própria.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
                  <div className="sm:col-span-8">
                    <label className="text-xs text-slate-300 block mb-1">
                      Link de Cobrança / Pagamento Direto (URL)
                    </label>
                    <input
                      type="url"
                      value={newProdPaymentLink}
                      onChange={(e) => setNewProdPaymentLink(e.target.value)}
                      placeholder="https://link.mercadopago.com.br/... ou https://nubank.com.br/cobrar/..."
                      className="w-full px-3 py-2 text-xs rounded-xl bg-slate-900 border border-slate-700 text-white font-mono focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div className="sm:col-span-4">
                    <label className="text-xs text-slate-300 block mb-1">
                      Valor da Cobrança (R$)
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={newProdCustomPaymentValue}
                      onChange={(e) => setNewProdCustomPaymentValue(e.target.value)}
                      placeholder={String(newProdPrice)}
                      className="w-full px-3 py-2 text-xs rounded-xl bg-slate-900 border border-slate-700 text-emerald-400 font-tech font-bold focus:outline-none focus:border-emerald-400"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs text-slate-300 block mb-1">
                    Código PIX Copia e Cola Específico
                  </label>
                  <textarea
                    rows={2}
                    value={newProdCustomPixCode}
                    onChange={(e) => setNewProdCustomPixCode(e.target.value)}
                    placeholder="Cole aqui o payload PIX se desejar um código específico..."
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-900 border border-slate-700 text-white font-mono focus:outline-none focus:border-cyan-400"
                  />
                </div>

                {/* QR Code Upload / Auto-generate for new product */}
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3">
                  <label className="text-xs text-slate-300 block">
                    Imagem do QR Code Exclusivo
                  </label>
                  <div className="flex items-center gap-3">
                    {newProdCustomQrCode && (
                      <div className="w-16 h-16 bg-white p-1 rounded-xl shrink-0 border border-slate-700">
                        <img src={newProdCustomQrCode} alt="QR Prévia" className="w-full h-full object-contain" />
                      </div>
                    )}
                    <label className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold cursor-pointer border border-slate-700 flex items-center gap-1.5">
                      <Upload className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Carregar Imagem do QR Code</span>
                      <input type="file" accept="image/*" onChange={(e) => handleQrUpload(e, true)} className="hidden" />
                    </label>
                    <button
                      type="button"
                      onClick={() => handleGenerateQr(true)}
                      disabled={isGeneratingQr || (!newProdCustomPixCode.trim() && !newProdPaymentLink.trim())}
                      className="px-3 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 disabled:cursor-not-allowed text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                    >
                      <QrCode className="w-3.5 h-3.5" />
                      <span>Gerar QR a partir do Link/PIX</span>
                    </button>
                  </div>
                </div>

                <div>
                  <label className="text-xs text-slate-300 block mb-1">
                    Instruções ou Observações da Cobrança
                  </label>
                  <input
                    type="text"
                    value={newProdPaymentInstructions}
                    onChange={(e) => setNewProdPaymentInstructions(e.target.value)}
                    placeholder="Ex: Pague pelo Mercado Pago / InfinitePay em até 12x"
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isPublishing}
                className="w-full py-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-tech font-extrabold text-sm uppercase tracking-wider shadow-xl shadow-emerald-950/60 cursor-pointer transition-all disabled:opacity-60 flex items-center justify-center gap-2"
              >
                <Plus className={`w-4 h-4 ${isPublishing ? 'animate-spin' : ''}`} />
                <span>
                  {autoPublishToAll
                    ? '+ Cadastrar e Publicar Produto para Todo Mundo'
                    : '+ Cadastrar Produto no Site'}
                </span>
              </button>
            </form>
          )}

          {/* TAB 3: STORE CONFIGURATION & PASSWORD */}
          {activeTab === 'store' && (
            <div className="max-w-2xl mx-auto space-y-6">
              <div className="p-4 rounded-2xl bg-blue-950/40 border border-blue-500/40 text-slate-300 text-xs leading-relaxed flex items-center gap-3">
                <Key className="w-5 h-5 text-cyan-400 shrink-0" />
                <span>Aqui você pode alterar o WhatsApp de atendimento da loja, os dados do PIX e a senha de acesso usada na lupa.</span>
              </div>

              {/* WhatsApp Config */}
              <div className="p-5 rounded-2xl bg-[#091228] border border-slate-800 space-y-4">
                <h4 className="text-sm font-bold text-white font-tech flex items-center gap-2">
                  <Phone className="w-4 h-4 text-emerald-400" />
                  WhatsApp para Pedidos & Comprovantes
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-slate-400 block mb-1">
                      Número Limpo (com DDI e DDD)
                    </label>
                    <input
                      type="text"
                      value={cfgWhatsapp}
                      onChange={(e) => setCfgWhatsapp(e.target.value)}
                      placeholder="55996244525"
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-mono focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-slate-400 block mb-1">
                      Texto de Exibição
                    </label>
                    <input
                      type="text"
                      value={cfgWhatsappDisplay}
                      onChange={(e) => setCfgWhatsappDisplay(e.target.value)}
                      placeholder="+55 99 9624-4525"
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>
              </div>

              {/* PIX Config */}
              <div className="p-5 rounded-2xl bg-[#091228] border border-slate-800 space-y-4">
                <h4 className="text-sm font-bold text-white font-tech flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-emerald-400" />
                  Dados do PIX (Pagamentos)
                </h4>

                <div>
                  <label className="text-xs text-slate-400 block mb-1">
                    Nome do Titular / Beneficiário PIX
                  </label>
                  <input
                    type="text"
                    value={cfgPixReceiver}
                    onChange={(e) => setCfgPixReceiver(e.target.value)}
                    placeholder="Valter Goncalves Ribeiro"
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-400 block mb-1">
                    Chave PIX Copia e Cola / Código
                  </label>
                  <textarea
                    rows={2}
                    value={cfgPixCode}
                    onChange={(e) => setCfgPixCode(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-900 border border-slate-700 text-white font-mono focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              {/* Admin Secret Password */}
              <div className="p-5 rounded-2xl bg-[#091228] border border-emerald-500/40 space-y-4">
                <h4 className="text-sm font-bold text-white font-tech flex items-center gap-2 text-emerald-300">
                  <Key className="w-4 h-4 text-emerald-400" />
                  Senha de Acesso do Administrador (Lupa)
                </h4>

                <div>
                  <label className="text-xs text-slate-300 block mb-1">
                    Sua Senha Atual de Acesso:
                  </label>
                  <input
                    type="text"
                    value={cfgAdminPassword}
                    onChange={(e) => setCfgAdminPassword(e.target.value)}
                    placeholder="Digite a nova senha para acessar pela lupa..."
                    className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-emerald-500/50 text-emerald-300 font-tech font-bold text-base focus:outline-none focus:border-emerald-400"
                  />
                  <span className="text-[11px] text-slate-400 block mt-1">
                    Dica: Ao digitar esta senha na barra de pesquisa da lupa, o painel do administrador é destravado instantaneamente.
                  </span>
                </div>
              </div>

              {/* City location */}
              <div className="p-5 rounded-2xl bg-[#091228] border border-slate-800 space-y-3">
                <h4 className="text-sm font-bold text-white font-tech flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-cyan-400" />
                  Localização da Loja
                </h4>
                <input
                  type="text"
                  value={cfgCity}
                  onChange={(e) => setCfgCity(e.target.value)}
                  placeholder="Santana do Livramento - RS"
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
                />
              </div>

              <button
                type="button"
                disabled={isPublishing}
                onClick={handleSaveStoreConfig}
                className="w-full py-4 rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-500 hover:from-emerald-500 hover:to-cyan-400 text-white font-tech font-extrabold text-sm uppercase tracking-wider shadow-xl shadow-emerald-950/60 cursor-pointer transition-all disabled:opacity-60 flex items-center justify-center gap-2"
              >
                <Save className={`w-4 h-4 ${isPublishing ? 'animate-spin' : ''}`} />
                <span>
                  {autoPublishToAll
                    ? 'Salvar e Publicar Configurações para Todo Mundo'
                    : 'Salvar Configurações da Loja'}
                </span>
              </button>
            </div>
          )}

          {/* TAB 4: RESET TO FACTORY */}
          {activeTab === 'reset' && (
            <div className="max-w-xl mx-auto text-center space-y-6 py-6">
              <div className="w-16 h-16 rounded-3xl bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center mx-auto">
                <AlertCircle className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-xl font-black text-white font-tech mb-2">
                  Restaurar Padrões Originais
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-md mx-auto">
                  Esta ação irá apagar todas as fotos, preços e produtos personalizados salvos neste navegador, voltando ao catálogo original de fábrica.
                </p>
              </div>

              <button
                type="button"
                onClick={handleResetFactory}
                className="px-8 py-4 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-tech font-bold text-xs uppercase tracking-wider shadow-xl shadow-rose-950/50 cursor-pointer transition-all hover:scale-105"
              >
                Sim, Restaurar Padrões de Fábrica
              </button>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-[#050A17] border-t border-slate-800 flex items-center justify-between shrink-0 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>Alterações são gravadas permanentemente e refletem em tempo real no site</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold transition-colors cursor-pointer"
          >
            Concluir / Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
