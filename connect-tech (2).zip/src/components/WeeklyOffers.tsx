import React, { useState, useEffect } from 'react';
import { Flame, Clock, ArrowRight } from 'lucide-react';
import { Product } from '../types';
import { ProductCard } from './ProductCard';
import { STORE_CONFIG } from '../config';

interface WeeklyOffersProps {
  products: Product[];
  onViewDetails: (product: Product) => void;
  onViewAllOffers: () => void;
}

export const WeeklyOffers: React.FC<WeeklyOffersProps> = ({
  products,
  onViewDetails,
  onViewAllOffers,
}) => {
  const offerProducts = products.filter((p) => p.isOfferOfTheWeek);

  // Real countdown timer calculation based on STORE_CONFIG.offersEndDate
  const [timeLeft, setTimeLeft] = useState<{
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
  }>({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const target = new Date(STORE_CONFIG.offersEndDate).getTime();

    const updateCountdown = () => {
      const now = new Date().getTime();
      const difference = target - now;

      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60),
        });
      } else {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      }
    };

    updateCountdown();
    const timer = setInterval(updateCountdown, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section id="weekly-offers-section" className="py-16 bg-[#040817] border-t border-b border-blue-900/30 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/2 left-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute top-1/2 right-0 w-80 h-80 bg-blue-600/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header with Title & Real Countdown */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 mb-10 p-6 rounded-2xl bg-gradient-to-r from-[#09132c] via-[#0b1836] to-[#0a1128] border border-blue-500/30 shadow-xl">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
              <Flame className="w-4 h-4 text-amber-400 fill-amber-400 animate-pulse" />
              Preços Especiais de Lançamento
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white font-tech tracking-tight">
              OFERTAS DA SEMANA
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-xl">
              Descontos reais em peças selecionadas com estoque limitado. Ofertas renovadas a cada ciclo semanal.
            </p>
          </div>

          {/* Real Countdown Display */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-xs text-slate-400 mr-1 hidden sm:flex">
              <Clock className="w-4 h-4 text-cyan-400" />
              <span>Termina em:</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex flex-col items-center justify-center w-14 h-14 rounded-xl bg-slate-950/90 border border-blue-500/40 shadow-inner">
                <span className="text-lg font-black text-cyan-300 font-tech">
                  {String(timeLeft.days).padStart(2, '0')}
                </span>
                <span className="text-[9px] text-slate-400 uppercase font-semibold">Dias</span>
              </div>
              <span className="text-cyan-400 font-bold">:</span>
              <div className="flex flex-col items-center justify-center w-14 h-14 rounded-xl bg-slate-950/90 border border-blue-500/40 shadow-inner">
                <span className="text-lg font-black text-cyan-300 font-tech">
                  {String(timeLeft.hours).padStart(2, '0')}
                </span>
                <span className="text-[9px] text-slate-400 uppercase font-semibold">Horas</span>
              </div>
              <span className="text-cyan-400 font-bold">:</span>
              <div className="flex flex-col items-center justify-center w-14 h-14 rounded-xl bg-slate-950/90 border border-blue-500/40 shadow-inner">
                <span className="text-lg font-black text-cyan-300 font-tech">
                  {String(timeLeft.minutes).padStart(2, '0')}
                </span>
                <span className="text-[9px] text-slate-400 uppercase font-semibold">Min</span>
              </div>
              <span className="text-cyan-400 font-bold">:</span>
              <div className="flex flex-col items-center justify-center w-14 h-14 rounded-xl bg-slate-950/90 border border-blue-500/40 shadow-inner">
                <span className="text-lg font-black text-cyan-300 font-tech">
                  {String(timeLeft.seconds).padStart(2, '0')}
                </span>
                <span className="text-[9px] text-slate-400 uppercase font-semibold">Seg</span>
              </div>
            </div>
          </div>
        </div>

        {/* Offers Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {offerProducts.slice(0, 4).map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onViewDetails={onViewDetails}
              showOfferStyle
            />
          ))}
        </div>

        {/* View All Offers Action */}
        <div className="flex justify-center">
          <button
            id="btn-view-all-offers"
            onClick={onViewAllOffers}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-slate-900 border border-blue-500/50 hover:bg-blue-900/30 text-cyan-300 font-semibold text-sm transition-all shadow-md group cursor-pointer"
          >
            <span>Ver Todas as Ofertas ({offerProducts.length})</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </section>
  );
};
