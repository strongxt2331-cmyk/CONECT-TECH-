import React from 'react';
import { MapPin, ShieldCheck, QrCode, Star } from 'lucide-react';

export const BenefitsBar: React.FC = () => {
  const benefits = [
    {
      icon: MapPin,
      title: 'Santana do Livramento',
      description: 'Entrega rápida via motoboy no mesmo dia ou retirada em mãos',
      highlight: 'Atendimento 100% local',
    },
    {
      icon: ShieldCheck,
      title: 'Compra 100% Segura',
      description: 'Criptografia de ponta a ponta e garantia de entrega local',
      highlight: 'Proteção total do cliente',
    },
    {
      icon: QrCode,
      title: 'Pagamento via PIX',
      description: 'QR Code instantâneo e Pix Copia e Cola com liberação rápida',
      highlight: 'Aprovação imediata',
    },
    {
      icon: Star,
      title: 'Pronta Entrega na Cidade',
      description: 'Garantia de 12 meses e teste de qualidade com suporte direto',
      highlight: 'Estoque disponível na cidade',
    },
  ];

  return (
    <section id="benefits-section" className="py-8 bg-[#040816] border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {benefits.map((b, idx) => {
            const Icon = b.icon;
            return (
              <div
                key={idx}
                className="group relative p-5 rounded-2xl bg-gradient-to-b from-[#081026] to-[#050B1A] border border-blue-900/40 hover:border-blue-500/60 transition-all duration-300 hover:-translate-y-1 shadow-lg shadow-blue-950/20"
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-blue-600/15 border border-blue-500/30 flex items-center justify-center shrink-0 group-hover:bg-blue-600/30 group-hover:border-cyan-400/50 transition-colors">
                    <Icon className="w-6 h-6 text-cyan-400 group-hover:scale-110 transition-transform" />
                  </div>
                  <div>
                    <h2 className="text-white font-tech font-bold text-base mb-1 group-hover:text-cyan-300 transition-colors">
                      {b.title}
                    </h2>
                    <p className="text-slate-400 text-xs leading-relaxed mb-2">
                      {b.description}
                    </p>
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-blue-400">
                      {b.highlight}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
