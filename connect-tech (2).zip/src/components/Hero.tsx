import React from 'react';
import { ArrowRight, ShieldCheck, Zap, Sparkles, CheckCircle2, MapPin } from 'lucide-react';
import { ProductCategory } from '../types';
import { useStore } from '../context/StoreContext';

interface HeroProps {
  onExploreProducts: () => void;
  onExploreOffers: () => void;
  onSelectCategory: (category: ProductCategory) => void;
}

export const Hero: React.FC<HeroProps> = ({
  onExploreProducts,
}) => {
  const { products } = useStore();
  const powerBank = products.find((p) => p.id === 'basike-power-bank') || products[0];
  const promoProduct = powerBank;
  return (
    <section
      id="hero-section"
      className="relative overflow-hidden bg-gradient-to-b from-[#030712] via-[#070D1F] to-[#030712] pt-8 pb-16 lg:pt-14 lg:pb-24 border-b border-blue-900/20"
    >
      {/* Background ambient neon glows */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/15 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-cyan-500/10 rounded-full blur-[140px] pointer-events-none"></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-blue-500/5 rounded-full blur-[100px] pointer-events-none"></div>

      {/* Subtle tech grid pattern overlay */}
      <div
        className="absolute inset-0 opacity-[0.03] pointer-events-none bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:24px_24px]"
      ></div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          {/* Left Column: Typography & CTAs */}
          <div className="lg:col-span-7 flex flex-col items-start text-left z-10">
            {/* Tech Badge with 4 in stock notification */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-xs font-semibold text-emerald-400 mb-6 shadow-sm shadow-emerald-500/20">
              <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-pulse"></span>
              ⚡ 4 EM ESTOQUE – SANTANA DO LIVRAMENTO - RS
              <span className="text-slate-500">|</span>
              <span className="text-cyan-300">Pronta Entrega Local</span>
            </div>

            {/* Main Headline */}
            <h1 className="font-tech text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.1] mb-6">
              CARREGADORES TURBO &{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-400 to-emerald-400 drop-shadow-sm">
                POWER BANK SEM FIO
              </span>
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg lg:text-xl text-slate-300 max-w-2xl font-normal leading-relaxed mb-8">
              Acessórios de alta tecnologia com estoque local e pronta entrega em <strong>Santana do Livramento - RS</strong>. Confira o novo <strong>Power Bank Basike por Indução em super promoção (de R$ 120 por R$ 80)</strong> e o <strong>Carregador Turbo iPhone 20W</strong>!
            </p>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto mb-10">
              <button
                id="hero-cta-buy"
                onClick={onExploreProducts}
                className="group relative inline-flex items-center justify-center gap-3 px-8 py-4 rounded-xl bg-gradient-to-r from-emerald-600 via-blue-600 to-cyan-500 text-white font-bold text-base shadow-xl shadow-emerald-950/40 hover:scale-[1.02] active:scale-[0.98] transition-all duration-200 cursor-pointer"
              >
                <span>VER PROMOÇÕES & PRODUTOS</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>

              <div className="flex items-center gap-2 px-5 py-3.5 rounded-xl bg-slate-900/90 border border-slate-700 text-slate-200 text-sm font-semibold">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
                <span>Pronta entrega em <strong>Santana do Livramento</strong></span>
              </div>
            </div>

            {/* Quick highlight points */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-4 border-t border-slate-800/80 w-full text-slate-400 text-xs">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>Exclusivo Santana do Livramento</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Pronta entrega imediata</span>
              </div>
              <div className="flex items-center gap-2 col-span-2 sm:col-span-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Garantia Connect Tech</span>
              </div>
            </div>
          </div>

          {/* Right Column: High-tech Visual Showcase */}
          <div className="lg:col-span-5 relative flex items-center justify-center">
            {/* Tech Circular Glow Frame */}
            <div className="relative w-full max-w-md aspect-square rounded-3xl bg-gradient-to-tr from-blue-900/40 via-slate-900 to-cyan-900/30 p-1 border border-blue-500/30 shadow-2xl shadow-blue-950/60 group">
              <div className="w-full h-full rounded-[22px] overflow-hidden relative bg-[#060B18]">
                {/* Tech Hero Image showing product */}
                <img
                  src={promoProduct?.image || "/assets/basike_power_bank.jpg"}
                  alt={promoProduct?.name || "Power Bank e Carregador Sem Fio"}
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 brightness-95 contrast-105"
                />

                {/* Gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#030712] via-[#030712]/30 to-transparent"></div>

                {/* Center Tech Tag */}
                <div className="absolute bottom-6 left-6 right-6 p-4 rounded-2xl bg-[#080E21]/90 backdrop-blur-md border border-emerald-500/40 shadow-xl">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-1 text-rose-400 text-xs font-bold uppercase tracking-wider mb-1">
                        <Sparkles className="w-3.5 h-3.5" />
                        {promoProduct?.badge || (promoProduct?.originalPrice ? `Super Promoção -${promoProduct.discountPercentage || 33}%` : 'Destaque')}
                      </div>
                      <div className="text-white font-tech font-bold text-sm sm:text-base line-clamp-1">
                        {promoProduct?.name || 'Power Bank Sem Fio Basike'}
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      {promoProduct?.originalPrice && (
                        <span className="text-[10px] text-slate-400 line-through block">
                          {promoProduct.originalPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        </span>
                      )}
                      <span className="text-emerald-400 font-black text-lg">
                        {promoProduct ? promoProduct.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : 'R$ 80,00'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Floating Tech Pill 1: Promo de 120 por 80 */}
              <div className="absolute -top-4 -left-4 sm:-left-6 px-4 py-2.5 rounded-xl bg-[#091124]/95 border border-rose-500/50 backdrop-blur-md shadow-xl flex items-center gap-2.5 text-xs text-white">
                <div className="w-7 h-7 rounded-lg bg-rose-600/30 border border-rose-400/40 flex items-center justify-center text-rose-400 font-bold">
                  🔥
                </div>
                <div>
                  <span className="font-bold block text-slate-100">
                    {promoProduct?.originalPrice
                      ? `De ${promoProduct.originalPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })} por ${promoProduct.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}`
                      : promoProduct?.name}
                  </span>
                  <span className="text-[10px] text-emerald-400">
                    {promoProduct?.stockCount ? `${promoProduct.stockCount} em estoque na cidade` : 'Pronta entrega'}
                  </span>
                </div>
              </div>

              {/* Floating Tech Pill 2: Carregamento sem fios */}
              <div className="absolute -bottom-4 -right-4 sm:-right-6 px-4 py-2.5 rounded-xl bg-[#091124]/95 border border-cyan-500/40 backdrop-blur-md shadow-xl flex items-center gap-2.5 text-xs text-white">
                <div className="w-7 h-7 rounded-lg bg-cyan-600/30 border border-cyan-400/40 flex items-center justify-center text-cyan-400">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold block text-slate-100">Indução Sem Fios</span>
                  <span className="text-[10px] text-cyan-300">Proteção Inteligente</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
