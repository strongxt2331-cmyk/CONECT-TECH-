import React from 'react';
import {
  Zap,
  PhoneCall,
  Mail,
  Clock,
  ShieldCheck,
  Lock,
  Instagram,
  Facebook,
  CheckCircle,
  MapPin,
} from 'lucide-react';
import { STORE_CONFIG, getWhatsAppUrl } from '../config';

interface FooterProps {
  onNavigate: (view: string, categoryId?: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer id="main-footer" className="bg-[#02050E] border-t border-blue-900/30 text-slate-400 text-sm">
      {/* Pre-footer tech trust highlights */}
      <div className="border-b border-slate-800/80 bg-[#040816] py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/15 border border-blue-500/30 flex items-center justify-center text-cyan-400 shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <span className="text-white font-bold text-xs block">Originais & Homologados</span>
              <span className="text-[11px] text-slate-500">Produtos testados com garantia</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/15 border border-blue-500/30 flex items-center justify-center text-cyan-400 shrink-0">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <span className="text-white font-bold text-xs block">Pagamento Seguro</span>
              <span className="text-[11px] text-slate-500">Criptografia SSL de 256 bits</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/15 border border-blue-500/30 flex items-center justify-center text-cyan-400 shrink-0">
              <PhoneCall className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <span className="text-white font-bold text-xs block">Suporte Dedicado</span>
              <span className="text-[11px] text-slate-500">Atendimento rápido via WhatsApp</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/15 border border-blue-500/30 flex items-center justify-center text-cyan-400 shrink-0">
              <CheckCircle className="w-5 h-5" />
            </div>
            <div>
              <span className="text-white font-bold text-xs block">Garantia Connect Tech</span>
              <span className="text-[11px] text-slate-500">Até 12 meses contra defeitos</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10">
          {/* Col 1: Brand info (4 cols) */}
          <div className="lg:col-span-4 flex flex-col items-start">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-blue-600/30">
                <Zap className="w-5 h-5 text-slate-950 fill-slate-950" />
              </div>
              <span className="font-tech text-xl font-extrabold tracking-tight text-white">
                CONNECT <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">TECH</span>
              </span>
            </div>
            <p className="text-slate-400 text-xs sm:text-sm leading-relaxed mb-4">
              Sua loja especializada em carregadores turbo e acessórios de alta performance. Atendimento ágil e entrega exclusiva para a cidade de <strong>Santana do Livramento - RS</strong>.
            </p>
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-cyan-950/40 border border-cyan-500/30 text-cyan-300 text-xs mb-5">
              <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span>Exclusivo para Santana do Livramento - RS</span>
            </div>
            {/* Configurable social channels */}
            <div className="flex items-center gap-2.5">
              <a
                href={STORE_CONFIG.social.instagram}
                target="_blank"
                rel="noopener noreferrer"
                title="Instagram Connect Tech"
                className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 hover:border-blue-500 text-slate-300 hover:text-white flex items-center justify-center transition-all hover:scale-105"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href={STORE_CONFIG.social.facebook}
                target="_blank"
                rel="noopener noreferrer"
                title="Facebook Connect Tech"
                className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 hover:border-blue-500 text-slate-300 hover:text-white flex items-center justify-center transition-all hover:scale-105"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href={STORE_CONFIG.social.tiktok}
                target="_blank"
                rel="noopener noreferrer"
                title="TikTok Connect Tech"
                className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 hover:border-blue-500 text-slate-300 hover:text-white flex items-center justify-center transition-all hover:scale-105 font-bold text-xs"
              >
                TT
              </a>
            </div>
          </div>

          {/* Col 2: Navegação (2 cols) */}
          <div className="lg:col-span-2">
            <h4 className="text-white font-tech font-bold text-sm tracking-wider uppercase mb-4 text-cyan-300">
              NAVEGAÇÃO
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm">
              <li>
                <button
                  onClick={() => onNavigate('home')}
                  className="hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  Início
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('products')}
                  className="hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  Produtos
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('about')}
                  className="hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  Sobre nós
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('contact')}
                  className="hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  Contato
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Categorias (3 cols) */}
          <div className="lg:col-span-3">
            <h4 className="text-white font-tech font-bold text-sm tracking-wider uppercase mb-4 text-cyan-300">
              CATEGORIAS
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm">
              <li>
                <button
                  onClick={() => onNavigate('products', 'celular')}
                  className="hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  Acessórios para Celular
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('products', 'carregadores')}
                  className="hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  Carregadores Turbo & GaN
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('products', 'cabos')}
                  className="hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  Cabos Blindados Reforçados
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('products', 'fones')}
                  className="hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  Fones Bluetooth & Áudio
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('products', 'adaptadores')}
                  className="hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  Adaptadores & Hubs USB-C
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Atendimento (3 cols) */}
          <div className="lg:col-span-3">
            <h4 className="text-white font-tech font-bold text-sm tracking-wider uppercase mb-4 text-cyan-300">
              ATENDIMENTO
            </h4>
            <div className="space-y-3 text-xs sm:text-sm">
              <a
                href={getWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-start gap-2.5 text-slate-300 hover:text-emerald-400 transition-colors group"
              >
                <PhoneCall className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <span className="block text-slate-400 text-xs">WhatsApp</span>
                  <span className="font-semibold text-white group-hover:text-emerald-300">
                    {STORE_CONFIG.whatsapp.displayNumber}
                  </span>
                </div>
              </a>

              <a
                href={`mailto:${STORE_CONFIG.contact.email}`}
                className="flex items-start gap-2.5 text-slate-300 hover:text-cyan-300 transition-colors group"
              >
                <Mail className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <div>
                  <span className="block text-slate-400 text-xs">E-mail</span>
                  <span className="font-semibold text-white group-hover:text-cyan-300">
                    {STORE_CONFIG.contact.email}
                  </span>
                </div>
              </a>

              <div className="flex items-start gap-2.5 text-slate-400">
                <Clock className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                <div>
                  <span className="block text-slate-400 text-xs">Horário de Funcionamento</span>
                  <span className="text-slate-300 text-xs leading-relaxed block">
                    {STORE_CONFIG.contact.hours}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Accepted Payment Methods and Security Badges */}
        <div className="mt-12 pt-8 border-t border-slate-800/80 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <span className="text-[11px] text-slate-500 block mb-2 font-semibold uppercase tracking-wider">
              Forma de pagamento aceita
            </span>
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1.5 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-xs text-emerald-300 font-bold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                PIX Exclusivo (Aprovação Imediata & Despacho Rápido)
              </span>
            </div>
          </div>
          <div className="text-center md:text-right">
            <span className="text-[11px] text-slate-500 block mb-2 font-semibold uppercase tracking-wider">
              Segurança e Proteção
            </span>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300">
              <Lock className="w-3.5 h-3.5 text-emerald-400" />
              <span>Compra 100% Protegida – SSL 256 Bits</span>
            </div>
          </div>
        </div>

        {/* Copyright notice */}
        <div className="mt-8 pt-6 border-t border-slate-800/50 text-center text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>© Connect Tech – Santana do Livramento - RS. Todos os direitos reservados.</p>
          <p className="text-[11px]">
            Atendimento exclusivo para Santana do Livramento - RS.
          </p>
        </div>
      </div>
    </footer>
  );
};
