import React, { useState } from 'react';
import { MessageCircle, X, Send } from 'lucide-react';
import { STORE_CONFIG, getWhatsAppUrl } from '../config';

export const WhatsAppFloating: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    const finalUrl = getWhatsAppUrl(message || undefined);
    window.open(finalUrl, '_blank');
    setIsOpen(false);
    setMessage('');
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      {/* Expandable chat popup box */}
      {isOpen && (
        <div
          id="whatsapp-chat-popup"
          className="mb-3 w-80 sm:w-88 rounded-2xl bg-[#081024] border border-emerald-500/40 shadow-2xl shadow-emerald-950/40 overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-200"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-emerald-700 to-teal-800 p-4 text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-full bg-emerald-900 border-2 border-emerald-300 flex items-center justify-center">
                  <MessageCircle className="w-5 h-5 text-white" />
                </div>
                <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-400 border-2 border-emerald-900"></span>
              </div>
              <div>
                <h4 className="font-bold text-sm leading-tight">Suporte Connect Tech</h4>
                <span className="text-[11px] text-emerald-200 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-300 animate-pulse"></span>
                  Online agora – Resposta rápida
                </span>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 rounded-lg hover:bg-emerald-800/60 text-white transition-colors cursor-pointer"
              aria-label="Fechar chat"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Body */}
          <div className="p-4 bg-[#050B1A]">
            <div className="p-3 rounded-xl bg-[#0B152E] border border-blue-900/40 text-xs text-slate-200 leading-relaxed mb-3">
              Olá! Bem-vindo à <strong>Connect Tech</strong>. Como podemos te ajudar hoje?
              <p className="mt-1 text-[11px] text-slate-400">
                Tire dúvidas sobre compatibilidade de cabos, carregadores, prazos de entrega ou pedidos.
              </p>
            </div>

            {/* Form */}
            <form onSubmit={handleSendMessage} className="flex flex-col gap-2">
              <input
                type="text"
                placeholder="Escreva sua mensagem..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-[#091226] border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-bold text-xs flex items-center justify-center gap-2 hover:from-emerald-500 hover:to-teal-500 transition-all shadow-md shadow-emerald-950/50 cursor-pointer"
              >
                <span>Iniciar conversa no WhatsApp</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>

          {/* Footer note */}
          <div className="px-4 py-2 bg-[#040816] border-t border-slate-800/80 text-[10px] text-slate-500 flex items-center justify-between">
            <span>Atendimento das 08h às 19h</span>
            <span className="text-emerald-400 font-semibold">{STORE_CONFIG.whatsapp.displayNumber}</span>
          </div>
        </div>
      )}

      {/* Main Floating Trigger Button */}
      <div className="relative group">
        {/* Tooltip on hover */}
        {!isOpen && (
          <div className="hidden sm:block absolute right-full mr-3 top-1/2 -translate-y-1/2 px-3 py-1.5 rounded-xl bg-[#091124] border border-emerald-500/40 text-emerald-300 text-xs font-semibold whitespace-nowrap shadow-xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
            Fale conosco no WhatsApp
          </div>
        )}
        <button
          id="btn-whatsapp-floating"
          onClick={() => setIsOpen(!isOpen)}
          className="relative flex items-center justify-center w-14 h-14 rounded-full bg-gradient-to-tr from-emerald-600 via-emerald-500 to-teal-400 text-white shadow-xl shadow-emerald-600/40 hover:scale-110 active:scale-95 transition-all duration-200 border-2 border-emerald-300/40 focus:outline-none cursor-pointer"
          aria-label="Fale conosco no WhatsApp"
        >
          {/* Pulsing ring */}
          <span className="absolute inset-0 rounded-full bg-emerald-500 opacity-30 animate-ping"></span>

          {isOpen ? (
            <X className="w-6 h-6" />
          ) : (
            <MessageCircle className="w-7 h-7 fill-white/20" />
          )}
        </button>
      </div>
    </div>
  );
};
