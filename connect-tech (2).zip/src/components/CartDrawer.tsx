import React from 'react';
import {
  X,
  Trash2,
  Plus,
  Minus,
  ShoppingBag,
  ArrowRight,
  Truck,
  ShieldCheck,
  MapPin,
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import { STORE_CONFIG } from '../config';

interface CartDrawerProps {
  onProceedToCheckout: () => void;
  onContinueShopping: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  onProceedToCheckout,
  onContinueShopping,
}) => {
  const {
    items,
    isOpen,
    setIsOpen,
    removeItem,
    updateQuantity,
    totalItemsCount,
    subtotal,
    shippingCost,
    finalTotal,
  } = useCart();

  if (!isOpen) return null;

  const freeShippingThreshold = STORE_CONFIG.shipping.freeShippingThreshold;
  const remainingForFreeShipping = Math.max(0, freeShippingThreshold - subtotal);
  const freeShippingProgress = Math.min(100, (subtotal / freeShippingThreshold) * 100);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm transition-opacity"
        onClick={() => setIsOpen(false)}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div
          id="cart-drawer-container"
          className="w-screen max-w-md bg-[#070D1E] border-l border-blue-900/40 shadow-2xl flex flex-col justify-between"
        >
          {/* Header */}
          <div className="p-5 border-b border-slate-800 bg-[#091228] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-blue-600/20 text-cyan-400 border border-blue-500/30">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-tech font-bold text-white text-lg">Meu Carrinho</h3>
                <span className="text-xs text-slate-400">
                  {totalItemsCount} {totalItemsCount === 1 ? 'item selecionado' : 'itens selecionados'}
                </span>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Local Shipping Notice */}
          <div className="px-5 py-3 bg-[#050B1A] border-b border-slate-800 text-xs">
            <div className="flex items-center gap-2 text-cyan-400 font-semibold mb-1">
              <MapPin className="w-4 h-4 text-cyan-400 shrink-0" />
              <span>Entrega Exclusiva em Santana do Livramento - RS</span>
            </div>
            <div className="flex items-center justify-between text-slate-300 text-[11px]">
              <span className="flex items-center gap-1 text-slate-400">
                <Truck className="w-3.5 h-3.5 text-emerald-400" />
                Motoboy no mesmo dia ou retirada local
              </span>
              <span className="text-emerald-400 font-bold uppercase">Grátis</span>
            </div>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-5 divide-y divide-slate-800/80">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6">
                <div className="w-16 h-16 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-500 mb-4">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h4 className="font-tech font-bold text-white text-lg mb-2">Seu carrinho está vazio</h4>
                <p className="text-slate-400 text-xs max-w-xs mb-6">
                  Explore nosso catálogo e encontre os melhores acessórios para potencializar seus aparelhos.
                </p>
                <button
                  onClick={() => {
                    setIsOpen(false);
                    onContinueShopping();
                  }}
                  className="px-6 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-bold text-xs uppercase tracking-wider hover:opacity-95 transition-opacity cursor-pointer"
                >
                  Explorar Produtos
                </button>
              </div>
            ) : (
              items.map((item) => (
                <div
                  key={`${item.product.id}-${item.selectedColor || ''}`}
                  className="py-4 flex gap-4 items-start"
                >
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-16 h-16 rounded-xl object-cover bg-slate-900 border border-slate-800 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm font-semibold text-white leading-snug line-clamp-2">
                      {item.product.name}
                    </h4>
                    {item.selectedColor && (
                      <span className="text-[11px] text-slate-400 block mt-0.5">
                        Cor: <span className="text-cyan-400">{item.selectedColor}</span>
                      </span>
                    )}
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-sm font-bold text-cyan-300 font-tech">
                        {(item.product.price * item.quantity).toLocaleString('pt-BR', {
                          style: 'currency',
                          currency: 'BRL',
                        })}
                      </span>
                      {item.quantity > 1 && (
                        <span className="text-[10px] text-slate-500">
                          ({item.product.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })} un)
                        </span>
                      )}
                    </div>

                    {/* Quantity controls */}
                    <div className="flex items-center justify-between mt-3">
                      <div className="flex items-center rounded-lg bg-slate-900 border border-slate-800">
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity - 1, item.selectedColor)}
                          className="p-1.5 text-slate-400 hover:text-white transition-colors cursor-pointer"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="px-2.5 text-xs font-bold text-white">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity + 1, item.selectedColor)}
                          className="p-1.5 text-slate-400 hover:text-white transition-colors cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <button
                        onClick={() => removeItem(item.product.id, item.selectedColor)}
                        className="text-slate-500 hover:text-red-400 p-1 transition-colors cursor-pointer"
                        title="Remover produto"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer with Calculations & Checkout */}
          {items.length > 0 && (
            <div className="p-5 border-t border-slate-800 bg-[#050A19] space-y-3">
              {/* Subtotal, Shipping lines */}
              <div className="space-y-1.5 pt-1 text-xs">
                <div className="flex justify-between text-slate-400">
                  <span>Subtotal</span>
                  <span className="text-slate-200 font-semibold">
                    {subtotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span className="flex items-center gap-1">
                    <Truck className="w-3 h-3 text-cyan-400" />
                    Frete
                  </span>
                  <span className="font-semibold text-slate-200">
                    {shippingCost === 0 ? (
                      <span className="text-emerald-400 font-bold uppercase text-[11px]">Grátis</span>
                    ) : (
                      shippingCost.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
                    )}
                  </span>
                </div>
                <div className="flex justify-between text-base font-bold text-white pt-2 border-t border-slate-800 font-tech">
                  <span>Total</span>
                  <span className="text-cyan-300 text-lg">
                    {finalTotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </span>
                </div>
              </div>

              {/* Checkout Button */}
              <button
                id="btn-cart-checkout"
                onClick={() => {
                  setIsOpen(false);
                  onProceedToCheckout();
                }}
                className="w-full py-4 rounded-xl bg-gradient-to-r from-blue-600 via-blue-500 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-extrabold text-sm uppercase tracking-wider shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 active:scale-98 transition-all cursor-pointer"
              >
                <span>FINALIZAR COMPRA</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-center gap-2 text-[10px] text-slate-500 pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Ambiente Seguro com Criptografia SSL 256-bit</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
