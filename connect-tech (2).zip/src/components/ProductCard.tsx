import React from 'react';
import { Star, ShoppingCart, Eye } from 'lucide-react';
import { Product } from '../types';
import { useCart } from '../context/CartContext';

interface ProductCardProps {
  product: Product;
  onViewDetails: (product: Product) => void;
  showOfferStyle?: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onViewDetails,
}) => {
  const { addItem } = useCart();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addItem(product, 1);
  };

  const formattedPrice = product.price.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });

  return (
    <div
      id={`product-card-${product.id}`}
      onClick={() => onViewDetails(product)}
      className="group relative flex flex-col justify-between rounded-2xl bg-gradient-to-b from-[#081026] via-[#050B1A] to-[#040816] border border-slate-800/80 hover:border-blue-500/60 p-4 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-xl hover:shadow-blue-950/30 cursor-pointer"
    >
      <div>
        {/* Image Container with Badges */}
        <div className="relative aspect-square w-full rounded-xl overflow-hidden bg-[#0a1128] mb-4 flex items-center justify-center border border-slate-800/60">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover object-center group-hover:scale-108 transition-transform duration-500 brightness-95"
            loading="lazy"
          />

          {/* Badges on image */}
          <div className="absolute top-2.5 left-2.5 flex flex-col gap-1.5 z-10">
            {product.badge && (
              <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-blue-600/90 text-white rounded-md backdrop-blur-sm border border-blue-400/40">
                {product.badge}
              </span>
            )}
          </div>

          {/* Stock Tag */}
          <div className="absolute bottom-2 left-2 z-10">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-bold bg-slate-950/90 text-emerald-400 border border-emerald-500/50 backdrop-blur-sm shadow-md">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              {product.stockCount ? `${product.stockCount} em estoque` : '4 em estoque'}
            </span>
          </div>

          {/* Quick Details Hover Trigger */}
          <div className="absolute inset-0 bg-blue-950/40 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center gap-2">
            <span className="px-3.5 py-2 rounded-xl bg-slate-900/95 border border-cyan-400/50 text-cyan-300 font-semibold text-xs flex items-center gap-1.5 shadow-lg transform translate-y-2 group-hover:translate-y-0 transition-transform">
              <Eye className="w-3.5 h-3.5" />
              Ver Detalhes
            </span>
          </div>
        </div>

        {/* Category Label */}
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[11px] font-semibold text-blue-400 uppercase tracking-wider">
            {product.categoryName}
          </span>

          {/* Star Rating */}
          <div
            className="flex items-center gap-1 text-xs text-amber-400"
            title="Classificação dos clientes"
          >
            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span className="font-bold text-slate-200">{product.rating}</span>
            <span className="text-[10px] text-slate-500">({product.reviewCount})</span>
          </div>
        </div>

        {/* Product Title */}
        <h3 className="text-white font-tech font-bold text-sm sm:text-base leading-snug line-clamp-2 mb-2 group-hover:text-cyan-300 transition-colors">
          {product.name}
        </h3>

        {/* Short Description */}
        <p className="text-slate-400 text-xs line-clamp-2 mb-4">
          {product.shortDescription}
        </p>
      </div>

      {/* Pricing and Actions */}
      <div className="pt-3 border-t border-slate-800/80">
        {product.originalPrice && (
          <div className="flex items-center gap-2 text-xs mb-1">
            <span className="text-slate-400 line-through">
              {product.originalPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
            </span>
            <span className="text-[10px] font-extrabold text-rose-400 bg-rose-950/70 border border-rose-500/40 px-1.5 py-0.5 rounded">
              {product.discountPercentage ? `-${product.discountPercentage}% OFF` : 'OFERTA'}
            </span>
          </div>
        )}
        <div className="flex items-baseline gap-2 mb-1">
          <span className="text-lg sm:text-xl font-extrabold text-white font-tech text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-cyan-300">
            {formattedPrice}
          </span>
        </div>

        {/* PIX payment note */}
        <p className="text-[11px] text-emerald-400 font-semibold mb-3 flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
          Pagamento rápido via PIX
        </p>

        {/* Action Buttons */}
        <div className="grid grid-cols-5 gap-2">
          <button
            type="button"
            id={`btn-add-cart-${product.id}`}
            onClick={handleAddToCart}
            className="col-span-4 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white text-xs sm:text-sm font-bold shadow-md shadow-blue-600/30 active:scale-95 transition-all cursor-pointer"
          >
            <ShoppingCart className="w-4 h-4" />
            <span>Adicionar</span>
          </button>
          <button
            type="button"
            id={`btn-view-${product.id}`}
            onClick={(e) => {
              e.stopPropagation();
              onViewDetails(product);
            }}
            title="Ver especificações e detalhes"
            className="col-span-1 flex items-center justify-center p-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-blue-400 text-slate-300 hover:text-white transition-all cursor-pointer"
          >
            <Eye className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
