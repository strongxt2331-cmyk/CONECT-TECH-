import React, { useState, useEffect } from 'react';
import {
  Search,
  ShoppingCart,
  User,
  Menu,
  X,
  Zap,
  ChevronRight,
  HelpCircle,
  PhoneCall,
  MapPin,
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import { STORE_CONFIG, getWhatsAppUrl } from '../config';

interface HeaderProps {
  currentView: string;
  onNavigate: (view: string, categoryId?: string, productId?: string) => void;
  onOpenSearch: () => void;
  onOpenAccount: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onNavigate,
  onOpenSearch,
  onOpenAccount,
}) => {
  const { totalItemsCount, setIsOpen } = useCart();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems: { label: string; view: string; badge?: string }[] = [
    { label: 'Início', view: 'home' },
    { label: 'Carregador iPhone', view: 'products' },
    { label: 'Sobre nós', view: 'about' },
    { label: 'Contato & Comprovante', view: 'contact' },
  ];

  const handleNavClick = (view: string) => {
    setMobileMenuOpen(false);
    onNavigate(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      {/* Top micro-bar for shipping & contact notice */}
      <aside aria-label="Avisos da loja" className="bg-[#050B17] border-b border-blue-900/30 text-xs py-1.5 px-4 text-slate-400">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1 text-cyan-400 font-semibold">
              <MapPin className="w-3.5 h-3.5 text-cyan-400" />
              Exclusivo para Santana do Livramento - RS
            </span>
            <span className="hidden sm:inline text-slate-500">|</span>
            <span className="hidden sm:inline text-slate-300">Entrega rápida local (motoboy) no mesmo dia ou retirada em mãos</span>
          </div>
          <div className="flex items-center gap-4">
            <a
              href={getWhatsAppUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-slate-300 hover:text-emerald-400 transition-colors"
            >
              <PhoneCall className="w-3 h-3 text-emerald-400" />
              <span className="hidden md:inline">Atendimento WhatsApp:</span>
              <span className="font-semibold text-emerald-400">{STORE_CONFIG.whatsapp.displayNumber}</span>
            </a>
            <button
              onClick={() => handleNavClick('about')}
              className="hidden lg:flex items-center gap-1 text-slate-400 hover:text-white transition-colors"
            >
              <HelpCircle className="w-3 h-3" />
              Ajuda & Garantia
            </button>
          </div>
        </div>
      </aside>

      {/* Main Sticky Header */}
      <header
        id="main-header"
        className={`sticky top-0 z-40 w-full transition-all duration-300 ${
          isScrolled
            ? 'bg-[#030712]/95 backdrop-blur-md border-b border-blue-500/20 shadow-xl shadow-blue-950/20 py-3'
            : 'bg-[#030712]/90 backdrop-blur-sm border-b border-slate-800/80 py-4'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4">
          {/* Brand Logo */}
          <button
            id="brand-logo-btn"
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-2.5 text-left group focus:outline-none"
          >
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-500 p-0.5 shadow-lg shadow-blue-600/30 group-hover:shadow-blue-500/50 transition-all duration-300">
              <div className="w-full h-full bg-[#070D1D] rounded-[10px] flex items-center justify-center">
                <Zap className="w-5 h-5 text-cyan-400 fill-cyan-400/30 group-hover:scale-110 transition-transform duration-300" />
              </div>
              <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-blue-500"></span>
              </span>
            </div>

            <div className="flex flex-col">
              <span className="font-tech text-xl sm:text-2xl font-extrabold tracking-tight text-white flex items-center gap-1.5">
                CONNECT <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">TECH</span>
              </span>
              <span className="text-[10px] tracking-widest text-slate-400 uppercase -mt-1 font-semibold">
                Digital Accessories
              </span>
            </div>
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            {navItems.map((item) => {
              const isActive = currentView === item.view;
              return (
                <button
                  key={item.view}
                  id={`nav-${item.view}`}
                  onClick={() => handleNavClick(item.view)}
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 flex items-center gap-1.5 relative ${
                    isActive
                      ? 'text-white bg-blue-950/60 border border-blue-500/40 shadow-sm shadow-blue-500/20'
                      : 'text-slate-300 hover:text-white hover:bg-slate-900/60'
                  }`}
                >
                  {item.label}
                  {item.badge && (
                    <span className="text-xs">{item.badge}</span>
                  )}
                  {isActive && (
                    <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-4 h-0.5 bg-cyan-400 rounded-full"></span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Action Icons: Search, User, Cart */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Search Button (Triggers interactive modal) */}
            <button
              id="header-search-btn"
              onClick={onOpenSearch}
              title="Pesquisar acessórios"
              className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-300 hover:text-white hover:border-blue-500/50 hover:bg-slate-800/80 transition-all text-sm group"
            >
              <Search className="w-4 h-4 text-blue-400 group-hover:scale-110 transition-transform" />
              <span className="hidden xl:inline text-xs text-slate-400">Buscar produtos...</span>
              <kbd className="hidden xl:inline-block px-1.5 py-0.5 text-[10px] text-slate-500 bg-slate-800 border border-slate-700 rounded font-mono">
                ⌘K
              </kbd>
            </button>

            {/* User Account Button */}
            <button
              id="header-account-btn"
              onClick={onOpenAccount}
              title="Minha Conta"
              aria-label="Minha Conta"
              className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-300 hover:text-white hover:border-blue-500/50 hover:bg-slate-800/80 transition-all relative group"
            >
              <User className="w-4 h-4 group-hover:text-cyan-400 transition-colors" />
            </button>

            {/* Cart Button */}
            <button
              id="header-cart-btn"
              onClick={() => setIsOpen(true)}
              title="Ver Carrinho de Compras"
              aria-label={`Ver Carrinho de Compras (${totalItemsCount} itens)`}
              className="relative flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-blue-700 text-white font-medium hover:from-blue-500 hover:to-blue-600 transition-all shadow-md shadow-blue-600/30 active:scale-95"
            >
              <ShoppingCart className="w-4 h-4" />
              <span className="hidden sm:inline text-xs font-semibold">Carrinho</span>
              <span
                id="cart-badge-count"
                className="flex items-center justify-center min-w-[20px] h-5 px-1.5 text-[11px] font-bold bg-cyan-400 text-slate-950 rounded-full shadow-sm"
              >
                {totalItemsCount}
              </span>
            </button>

            {/* Mobile Hamburger Toggle */}
            <button
              id="mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2.5 md:hidden rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white focus:outline-none"
              aria-label="Abrir Menu de Navegação"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div
            id="mobile-drawer"
            className="md:hidden border-t border-slate-800 bg-[#070D1D]/98 backdrop-blur-xl px-4 pt-3 pb-6 mt-3 shadow-2xl animate-in slide-in-from-top duration-200"
          >
            <div className="flex flex-col gap-1.5 mb-4">
              {navItems.map((item) => {
                const isActive = currentView === item.view;
                return (
                  <button
                    key={item.view}
                    id={`mobile-nav-${item.view}`}
                    onClick={() => handleNavClick(item.view)}
                    className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-left text-sm font-semibold transition-all ${
                      isActive
                        ? 'bg-blue-600/20 text-cyan-300 border border-blue-500/40'
                        : 'text-slate-300 hover:bg-slate-800/60'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      {item.label}
                      {item.badge && <span>{item.badge}</span>}
                    </span>
                    <ChevronRight className="w-4 h-4 text-slate-500" />
                  </button>
                );
              })}
            </div>

            {/* Mobile quick actions */}
            <div className="pt-3 border-t border-slate-800 flex flex-col gap-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenSearch();
                }}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-slate-900 border border-slate-800 text-slate-200 font-medium text-sm hover:border-blue-500"
              >
                <Search className="w-4 h-4 text-blue-400" />
                Buscar no Catálogo
              </button>

              <a
                href={getWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-emerald-600/20 border border-emerald-500/40 text-emerald-300 font-medium text-sm hover:bg-emerald-600/30"
              >
                <PhoneCall className="w-4 h-4" />
                Falar no WhatsApp ({STORE_CONFIG.whatsapp.displayNumber})
              </a>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
