import React from 'react';
import {
  Smartphone,
  Zap,
  Cable,
  Headphones,
  Cpu,
  Watch,
  Laptop,
  Flame,
  ArrowRight,
} from 'lucide-react';
import { CATEGORIES_DATA } from '../data/products';
import { ProductCategory } from '../types';

interface CategoriesSectionProps {
  onSelectCategory: (category: ProductCategory) => void;
}

export const CategoriesSection: React.FC<CategoriesSectionProps> = ({ onSelectCategory }) => {
  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'Smartphone':
        return Smartphone;
      case 'Zap':
        return Zap;
      case 'Cable':
        return Cable;
      case 'Headphones':
        return Headphones;
      case 'Cpu':
        return Cpu;
      case 'Watch':
        return Watch;
      case 'Laptop':
        return Laptop;
      case 'Flame':
        return Flame;
      default:
        return Zap;
    }
  };

  return (
    <section id="categories-section" className="py-16 bg-[#030712] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-10 gap-4">
          <div>
            <div className="flex items-center gap-2 text-cyan-400 text-xs font-bold uppercase tracking-widest mb-2">
              <span className="w-6 h-0.5 bg-cyan-400"></span>
              Navegação Rápida
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white font-tech tracking-tight">
              ENCONTRE O QUE VOCÊ PRECISA
            </h2>
          </div>
          <p className="text-slate-400 text-sm max-w-md">
            Explore as principais linhas de tecnologia, peças homologadas e acessórios com garantia exclusiva Connect Tech.
          </p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {CATEGORIES_DATA.map((cat) => {
            const Icon = getCategoryIcon(cat.iconName);
            const isOffer = cat.id === 'ofertas';

            return (
              <button
                key={cat.id}
                id={`category-card-${cat.id}`}
                onClick={() => onSelectCategory(cat.id)}
                className={`group relative text-left rounded-2xl p-5 border transition-all duration-300 overflow-hidden flex flex-col justify-between h-44 sm:h-48 hover:-translate-y-1.5 focus:outline-none cursor-pointer ${
                  isOffer
                    ? 'bg-gradient-to-br from-amber-950/40 via-[#0a0715] to-[#12071a] border-amber-500/40 hover:border-amber-400 shadow-lg shadow-amber-950/20'
                    : 'bg-gradient-to-br from-[#081026] via-[#050B1A] to-[#040816] border-slate-800/80 hover:border-blue-500/60 shadow-md hover:shadow-blue-950/40'
                }`}
              >
                {/* Background image subtle preview */}
                <div
                  className="absolute inset-0 opacity-10 group-hover:opacity-20 transition-opacity bg-cover bg-center pointer-events-none"
                  style={{ backgroundImage: `url(${cat.image})` }}
                />

                {/* Glow accent */}
                <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/10 group-hover:bg-blue-500/25 rounded-full blur-2xl transition-all pointer-events-none"></div>

                {/* Top bar: Icon & Item Count */}
                <div className="relative z-10 flex items-center justify-between w-full">
                  <div
                    className={`w-11 h-11 rounded-xl flex items-center justify-center border transition-all ${
                      isOffer
                        ? 'bg-amber-500/20 border-amber-400/40 text-amber-400 group-hover:scale-110'
                        : 'bg-blue-600/20 border-blue-400/30 text-cyan-400 group-hover:bg-blue-600/30 group-hover:scale-110'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <span
                    className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${
                      isOffer
                        ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                        : 'bg-slate-800/80 border-slate-700 text-slate-300'
                    }`}
                  >
                    {cat.itemCount} itens
                  </span>
                </div>

                {/* Bottom info */}
                <div className="relative z-10">
                  <h3 className="text-white font-tech font-bold text-base sm:text-lg mb-1 group-hover:text-cyan-300 transition-colors flex items-center justify-between">
                    <span>{cat.name}</span>
                    <ArrowRight className="w-4 h-4 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all text-cyan-400 shrink-0" />
                  </h3>
                  <p className="text-slate-400 text-xs line-clamp-1">
                    {cat.description}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
};
