import React, { useState, useEffect, useRef } from 'react';
import { Search, X, ArrowRight, ShoppingCart, Key, Users, Settings, Lock, Sparkles } from 'lucide-react';
import { Product } from '../types';
import { useCart } from '../context/CartContext';
import { useStore } from '../context/StoreContext';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectProduct: (product: Product) => void;
  onViewAllResults: (query: string) => void;
  onOpenBuyersDashboard?: () => void;
  onOpenAdminEditor?: () => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectProduct,
  onViewAllResults,
  onOpenBuyersDashboard,
  onOpenAdminEditor,
}) => {
  const [query, setQuery] = useState('');
  const [showPasswordPrompt, setShowPasswordPrompt] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [passwordError, setPasswordError] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const passwordInputRef = useRef<HTMLInputElement>(null);
  const { addItem } = useCart();
  const { products, verifyAdminPassword, setIsAdminOpen } = useStore();

  useEffect(() => {
    if (isOpen) {
      setShowPasswordPrompt(false);
      setPasswordInput('');
      setPasswordError(false);
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
    }
  }, [isOpen]);

  // Keyboard shortcut listener (ESC to close)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const trimmed = query.trim();
  // Directly recognize password typed in the search bar or validated through the password prompt
  const isAdminDirectlyTyped = verifyAdminPassword(trimmed);
  const isAdminFromPrompt = verifyAdminPassword(passwordInput);
  const isAdminKey = isAdminDirectlyTyped || isAdminFromPrompt;

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (verifyAdminPassword(passwordInput)) {
      setPasswordError(false);
    } else {
      setPasswordError(true);
    }
  };

  const handleTriggerAdminEditor = () => {
    onClose();
    if (onOpenAdminEditor) {
      onOpenAdminEditor();
    } else {
      setIsAdminOpen(true);
    }
  };

  const handleTriggerBuyersDashboard = () => {
    onClose();
    if (onOpenBuyersDashboard) {
      onOpenBuyersDashboard();
    }
  };

  const filteredProducts = trimmed && !isAdminKey
    ? products.filter((p) => {
        return (
          p.name.toLowerCase().includes(trimmed.toLowerCase()) ||
          p.shortDescription.toLowerCase().includes(trimmed.toLowerCase()) ||
          p.categoryName.toLowerCase().includes(trimmed.toLowerCase()) ||
          p.category.toLowerCase().includes(trimmed.toLowerCase()) ||
          p.features.some((f) => f.toLowerCase().includes(trimmed.toLowerCase()))
        );
      })
    : products;

  const quickSearchTags = [
    'Carregador iPhone',
    'Power Bank Basike',
    'Carregador 20W',
    'Indução Sem Fio',
    'Santana do Livramento',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-150">
      {/* Click outside backdrop to close */}
      <div className="fixed inset-0" onClick={onClose} />

      {/* Modal Card */}
      <div
        id="search-modal-container"
        className="relative w-full max-w-2xl rounded-2xl bg-[#070D1F] border border-blue-500/40 shadow-2xl shadow-blue-950/60 overflow-hidden z-10 flex flex-col max-h-[80vh]"
      >
        {/* Search Header Input */}
        <div className="flex items-center gap-3 px-5 py-4 border-b border-slate-800 bg-[#09122a]">
          <Search className="w-5 h-5 text-cyan-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Pesquisar produtos (ou digite a senha de admin)..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                if (isAdminKey) {
                  handleTriggerAdminEditor();
                } else if (query.trim()) {
                  onViewAllResults(query.trim());
                  onClose();
                }
              }
            }}
            className="w-full bg-transparent text-white placeholder-slate-400 text-sm sm:text-base focus:outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 rounded-md text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}

          {/* Discreet lock button to open password prompt */}
          <button
            type="button"
            onClick={() => {
              setShowPasswordPrompt(!showPasswordPrompt);
              setTimeout(() => passwordInputRef.current?.focus(), 100);
            }}
            className={`p-2 rounded-xl border transition-all text-xs flex items-center gap-1 cursor-pointer ${
              showPasswordPrompt || isAdminKey
                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400/50'
                : 'bg-slate-900 text-slate-400 hover:text-cyan-300 border-slate-800'
            }`}
            title="Acesso com senha (Modo Administrador)"
          >
            <Lock className="w-3.5 h-3.5" />
            <span className="hidden sm:inline text-[11px] font-semibold">Senha</span>
          </button>

          <button
            onClick={onClose}
            className="px-2.5 py-1 text-xs rounded-lg bg-slate-800 text-slate-300 hover:text-white border border-slate-700 cursor-pointer"
          >
            ESC
          </button>
        </div>

        {/* PASSWORD PROMPT DRAWER */}
        {showPasswordPrompt && !isAdminKey && (
          <form
            onSubmit={handlePasswordSubmit}
            className="p-4 bg-gradient-to-r from-[#071329] via-[#091b3b] to-[#071329] border-b border-cyan-500/40 animate-in slide-in-from-top-2 duration-150 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3"
          >
            <div className="flex items-center gap-2.5 text-xs text-slate-200">
              <Key className="w-4 h-4 text-cyan-400 shrink-0" />
              <span>Digite a senha para desbloquear o painel de edição do site:</span>
            </div>
            <div className="flex items-center gap-2">
              <input
                ref={passwordInputRef}
                type="password"
                value={passwordInput}
                onChange={(e) => {
                  setPasswordInput(e.target.value);
                  setPasswordError(false);
                }}
                placeholder="Digite a senha..."
                className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white text-xs font-mono focus:outline-none focus:border-cyan-400"
              />
              <button
                type="submit"
                className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs cursor-pointer"
              >
                Entrar
              </button>
            </div>
            {passwordError && (
              <span className="text-[11px] text-rose-400 font-bold block sm:w-full">
                Senha incorreta. Tente novamente ou use a senha padrão da loja.
              </span>
            )}
          </form>
        )}

        {/* SECRET ACCESS BANNER RECOGNIZED WITH PASSWORD */}
        {isAdminKey && (
          <div className="p-5 bg-gradient-to-r from-emerald-950/90 via-[#061f18] to-[#08182b] border-b-2 border-emerald-500/80 animate-in fade-in slide-in-from-top-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-start gap-3">
                <div className="w-11 h-11 rounded-2xl bg-emerald-500/20 border border-emerald-400/50 flex items-center justify-center text-emerald-400 shrink-0 shadow-lg shadow-emerald-950/60">
                  <Sparkles className="w-6 h-6 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-500/30 text-emerald-300 border border-emerald-400/40">
                      Senha Reconhecida
                    </span>
                    <span className="text-xs font-bold text-white">Modo Administrador Ativado</span>
                  </div>
                  <h3 className="font-tech font-bold text-white text-sm sm:text-base mt-0.5">
                    ALTERAR FOTOS, PREÇOS E CONFIGURAÇÕES DO SITE
                  </h3>
                  <p className="text-xs text-slate-300 mt-0.5">
                    Você pode trocar as fotos dos produtos, ajustar preços (R$ 80, R$ 120, etc.), alterar o WhatsApp e editar tudo na loja.
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 shrink-0">
                <button
                  type="button"
                  onClick={handleTriggerAdminEditor}
                  className="px-5 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-tech font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl shadow-emerald-950/60 transition-all hover:scale-105 active:scale-95 cursor-pointer"
                >
                  <Settings className="w-4 h-4" />
                  <span>Mudar Fotos & Preços</span>
                </button>

                <button
                  type="button"
                  onClick={handleTriggerBuyersDashboard}
                  className="px-4 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 font-tech font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <Users className="w-4 h-4 text-cyan-400" />
                  <span>Ver Pedidos</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Quick Suggestion Tags */}
        <div className="px-5 py-3 bg-[#050A17] border-b border-slate-800/80 flex items-center gap-2 overflow-x-auto text-xs scrollbar-none">
          <span className="text-slate-500 text-[11px] font-semibold whitespace-nowrap">Sugestões:</span>
          {quickSearchTags.map((tag) => (
            <button
              key={tag}
              onClick={() => setQuery(tag)}
              className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-blue-900/40 border border-slate-800 hover:border-blue-500/40 text-slate-300 hover:text-cyan-300 whitespace-nowrap transition-colors cursor-pointer"
            >
              {tag}
            </button>
          ))}
        </div>

        {/* Search Results List */}
        <div className="p-4 overflow-y-auto flex-1 divide-y divide-slate-800/60">
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 px-2 flex items-center justify-between">
            <span>
              {isAdminKey ? 'Produtos no Catálogo (Clique para editar ou comprar)' : trimmed ? `Resultados encontrados (${filteredProducts.length})` : 'Produtos Disponíveis'}
            </span>
            {isAdminKey && (
              <span className="text-[11px] text-emerald-400 font-bold">
                ● Acesso liberado
              </span>
            )}
          </div>

          {filteredProducts.map((prod) => (
            <div
              key={prod.id}
              onClick={() => {
                if (isAdminKey) {
                  handleTriggerAdminEditor();
                } else {
                  onSelectProduct(prod);
                  onClose();
                }
              }}
              className="flex items-center justify-between p-3 rounded-xl hover:bg-blue-950/40 transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-3">
                <img
                  src={prod.image}
                  alt={prod.name}
                  className="w-12 h-12 rounded-lg object-contain bg-slate-950 border border-slate-800 shrink-0 p-1"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider">
                      {prod.categoryName}
                    </span>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold border border-emerald-500/30">
                      {prod.stockCount} em estoque
                    </span>
                    {prod.badge && (
                      <span className="text-[9px] text-rose-300 font-extrabold bg-rose-950/60 px-1.5 py-0.5 rounded border border-rose-500/40">
                        {prod.badge}
                      </span>
                    )}
                  </div>
                  <h4 className="text-sm font-semibold text-white group-hover:text-cyan-300 transition-colors line-clamp-1">
                    {prod.name}
                  </h4>
                  <div className="flex items-center gap-2 mt-0.5">
                    {prod.originalPrice && (
                      <span className="text-xs text-slate-500 line-through">
                        {prod.originalPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </span>
                    )}
                    <span className="text-xs font-black text-emerald-400 font-tech">
                      {prod.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {isAdminKey ? (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleTriggerAdminEditor();
                    }}
                    className="p-2 rounded-lg bg-emerald-600/30 hover:bg-emerald-600 text-emerald-300 hover:text-white transition-all text-xs flex items-center gap-1 cursor-pointer"
                    title="Editar produto"
                  >
                    <Settings className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline text-[11px] font-bold">Editar</span>
                  </button>
                ) : (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      addItem(prod, 1);
                    }}
                    className="p-2 rounded-lg bg-blue-600/20 hover:bg-blue-600 text-cyan-300 hover:text-white transition-all text-xs flex items-center gap-1 cursor-pointer"
                    title="Adicionar ao carrinho"
                  >
                    <ShoppingCart className="w-3.5 h-3.5" />
                  </button>
                )}
                <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-cyan-400 group-hover:translate-x-0.5 transition-all" />
              </div>
            </div>
          ))}
        </div>

        {/* Modal Footer */}
        <div className="p-3 bg-[#050A17] border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span className="flex items-center gap-1.5">
            <Lock className="w-3 h-3 text-slate-500" />
            <span>Dica do Dono: digite a senha na busca para gerenciar fotos e preços</span>
          </span>
          {trimmed && !isAdminKey && (
            <button
              onClick={() => {
                onViewAllResults(query.trim());
                onClose();
              }}
              className="px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <span>Ver no catálogo</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

