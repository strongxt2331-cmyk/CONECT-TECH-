// Store configuration for Connect Tech
// Customized for exclusive local service in Santana do Livramento - RS
export const STORE_CONFIG = {
  name: 'CONNECT TECH',
  tagline: 'TECNOLOGIA QUE CONECTA VOCÊ AO QUE IMPORTA',
  subtitle: 'Especialista em carregadores e acessórios turbo de alta performance para iPhone. Atendimento e entrega exclusiva em Santana do Livramento - RS.',

  // City Exclusivity
  city: 'Santana do Livramento',
  state: 'RS',
  locationDisplay: 'Santana do Livramento - RS',

  // WhatsApp Configuration (Customized to 55996244525)
  whatsapp: {
    displayNumber: '+55 99 9624-4525',
    cleanNumber: '55996244525', // Format: CountryCode + AreaCode + Number
    defaultMessage: 'Olá! Vim pela loja Connect Tech em Santana do Livramento e gostaria de informações sobre o carregador de iPhone.',
  },

  // PIX Configuration (Chave e QR Code)
  pix: {
    code: '00020126580014BR.GOV.BCB.PIX01360b5b1de6-b358-46e9-9451-f2ae662e95ca520400005303986540545.005802BR5924Valter Goncalves Ribeiro6009SAO PAULO62140510GomMhHApN863049AC4',
    receiver: 'Valter Goncalves Ribeiro',
    city: 'São Paulo',
    amount: 45.00,
    qrCodeImage: '/assets/pix_qrcode.png',
  },

  // Admin secret password to unlock buyers dashboard
  adminSecretKey: 'strongxt001002z',

  // Contact Information
  contact: {
    email: 'contato@connecttech.com.br',
    supportEmail: 'suporte@connecttech.com.br',
    hours: 'Segunda a Sexta: 08h às 19h | Sábado: 09h às 14h',
    responseTarget: 'Atendimento e entrega local exclusiva em Santana do Livramento - RS',
  },

  // Social Media Links
  social: {
    instagram: 'https://instagram.com/connecttech.oficial',
    facebook: 'https://facebook.com/connecttech.loja',
    tiktok: 'https://tiktok.com/@connecttech.br',
  },

  // Shipping & Policies (Exclusivo para Santana do Livramento - RS)
  shipping: {
    targetCity: 'Santana do Livramento',
    targetState: 'RS',
    coverage: 'Exclusivo para Santana do Livramento - RS',
    freeShippingThreshold: 0, // Entrega local grátis em Santana do Livramento
    defaultStandardShipping: 0,
    defaultExpressShipping: 0,
    deliveryNotice: 'Entrega expressa no mesmo dia ou retirada local em Santana do Livramento - RS',
  },

  // Brand Story text
  aboutText:
    'A Connect Tech nasceu com o objetivo de oferecer acessórios digitais e produtos de tecnologia que unem praticidade, qualidade e acessibilidade, com atendimento e pronta entrega exclusiva para a cidade de Santana do Livramento - RS. Nossa missão é aproximar as pessoas da tecnologia através de produtos úteis para o dia a dia e de um atendimento próximo, rápido e confiável.',

  offersEndDate: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString(),
};

// Helper function to build WhatsApp link for orders and proofs
export function getWhatsAppUrl(customText?: string): string {
  const text = encodeURIComponent(customText || STORE_CONFIG.whatsapp.defaultMessage);
  return `https://wa.me/${STORE_CONFIG.whatsapp.cleanNumber}?text=${text}`;
}

export function getProductWhatsAppUrl(productName: string, price: number): string {
  const formattedPrice = price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  const text = `Olá Connect Tech! Tenho interesse no *${productName}* (${formattedPrice}) em Santana do Livramento (4 em estoque). Como faço para combinar a entrega local e mandar o comprovante?`;
  return getWhatsAppUrl(text);
}

export function getOrderProofWhatsAppUrl(orderSummary: string): string {
  return getWhatsAppUrl(orderSummary);
}
