import React, { useState } from 'react';
import { CartProvider, useCart } from './context/CartContext';
import { StoreProvider, useStore } from './context/StoreContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { ProductsPage } from './pages/ProductsPage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { CartDrawer } from './components/CartDrawer';
import { SearchModal } from './components/SearchModal';
import { AccountModal } from './components/AccountModal';
import { WhatsAppFloating } from './components/WhatsAppFloating';
import { OrderSuccessModal } from './components/OrderSuccessModal';
import { BuyersDashboard } from './components/BuyersDashboard';
import { AdminSiteEditorModal } from './components/AdminSiteEditorModal';
import { Product, ProductCategory, Order } from './types';
import { CheckCircle } from 'lucide-react';

type AppView =
  | 'home'
  | 'products'
  | 'offers'
  | 'categories'
  | 'product-detail'
  | 'checkout'
  | 'about'
  | 'contact'
  | 'order-success'
  | 'admin-buyers';

const MainAppContent: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>('home');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory>('todos');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);

  // Store context for live products and admin state
  const { products, isAdminOpen, setIsAdminOpen } = useStore();

  // Modals state
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [accountModalOpen, setAccountModalOpen] = useState(false);
  const { notification, setIsOpen: setCartOpen } = useCart();

  const handleNavigate = (view: string, categoryId?: string, productId?: string) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });

    if (view === 'categories') {
      if (categoryId) {
        setSelectedCategory(categoryId as ProductCategory);
        setCurrentView('products');
      } else {
        setSelectedCategory('todos');
        setCurrentView('products');
      }
      return;
    }

    if (view === 'offers') {
      setSelectedCategory('todos');
      setCurrentView('products');
      return;
    }

    if (view === 'products') {
      if (categoryId) {
        setSelectedCategory(categoryId as ProductCategory);
      }
      setCurrentView('products');
      return;
    }

    if (view === 'product-detail' && productId) {
      const found = products.find((p) => p.id === productId);
      if (found) {
        setSelectedProduct(found);
        setCurrentView('product-detail');
      }
      return;
    }

    setCurrentView(view as AppView);
  };

  const handleViewProductDetails = (product: Product) => {
    // Look up newest version of product in store
    const liveProduct = products.find((p) => p.id === product.id) || product;
    setSelectedProduct(liveProduct);
    setCurrentView('product-detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectCategoryFromHero = (category: ProductCategory) => {
    setSelectedCategory(category);
    setCurrentView('products');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSearchResultsAll = (query: string) => {
    setSearchQuery(query);
    setSelectedCategory('todos');
    setCurrentView('products');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOrderSuccess = (order: Order) => {
    setCompletedOrder(order);
    setCurrentView('order-success');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#030712] text-slate-100">
      {/* Toast Notification for Cart Actions */}
      {notification && (
        <div className="fixed top-20 right-6 z-50 animate-in fade-in slide-in-from-top-3 duration-200">
          <div className="flex items-center gap-2.5 px-4 py-3 rounded-2xl bg-[#08132d] border border-cyan-400 text-white shadow-2xl shadow-cyan-950/60 text-xs font-semibold">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{notification}</span>
          </div>
        </div>
      )}

      {/* Main Header */}
      <Header
        currentView={currentView}
        onNavigate={handleNavigate}
        onOpenSearch={() => setSearchModalOpen(true)}
        onOpenAccount={() => setAccountModalOpen(true)}
      />

      {/* Dynamic View Router */}
      <main className="flex-1">
        {currentView === 'home' && (
          <HomePage
            onViewProductDetails={handleViewProductDetails}
            onNavigate={handleNavigate}
            onSelectCategory={handleSelectCategoryFromHero}
          />
        )}

        {currentView === 'products' && (
          <ProductsPage
            initialCategory={selectedCategory}
            initialSearchQuery={searchQuery}
            onViewProductDetails={handleViewProductDetails}
            onOpenBuyersDashboard={() => setCurrentView('admin-buyers')}
            onOpenAdminEditor={() => setIsAdminOpen(true)}
          />
        )}

        {currentView === 'admin-buyers' && (
          <BuyersDashboard onBackToStore={() => setCurrentView('home')} />
        )}

        {currentView === 'product-detail' && selectedProduct && (
          <ProductDetailPage
            product={selectedProduct}
            onBack={() => handleNavigate('products')}
            onSelectRelatedProduct={handleViewProductDetails}
            onProceedToCheckout={() => setCurrentView('checkout')}
          />
        )}

        {currentView === 'checkout' && (
          <CheckoutPage
            onBackToCart={() => setCartOpen(true)}
            onOrderSuccess={handleOrderSuccess}
          />
        )}

        {currentView === 'order-success' && completedOrder && (
          <OrderSuccessModal
            order={completedOrder}
            onContinueShopping={() => handleNavigate('home')}
          />
        )}

        {currentView === 'about' && (
          <AboutPage
            onExploreProducts={() => handleNavigate('products')}
            onContact={() => handleNavigate('contact')}
          />
        )}

        {currentView === 'contact' && <ContactPage />}
      </main>

      {/* Footer */}
      <Footer onNavigate={handleNavigate} />

      {/* Cart Drawer */}
      <CartDrawer
        onProceedToCheckout={() => setCurrentView('checkout')}
        onContinueShopping={() => handleNavigate('products')}
      />

      {/* Search Modal */}
      <SearchModal
        isOpen={searchModalOpen}
        onClose={() => setSearchModalOpen(false)}
        onSelectProduct={handleViewProductDetails}
        onViewAllResults={handleSearchResultsAll}
        onOpenBuyersDashboard={() => {
          setCurrentView('admin-buyers');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenAdminEditor={() => {
          setIsAdminOpen(true);
        }}
      />

      {/* Admin Site Editor Modal (accessible via search modal with password) */}
      <AdminSiteEditorModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        onOpenBuyersReport={() => {
          setCurrentView('admin-buyers');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Account Modal */}
      <AccountModal
        isOpen={accountModalOpen}
        onClose={() => setAccountModalOpen(false)}
      />

      {/* Floating WhatsApp Button */}
      <WhatsAppFloating />
    </div>
  );
};

export default function App() {
  return (
    <StoreProvider>
      <CartProvider>
        <MainAppContent />
      </CartProvider>
    </StoreProvider>
  );
}

